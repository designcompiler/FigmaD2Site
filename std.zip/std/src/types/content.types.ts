/**
 * Content Type Definitions
 *
 * Types for page content, FAQs, use cases, guides, and customer stories
 * based on scraped portal data
 */

export interface PageSection {
  type: string;
  class: string;
  html: string;
}

export interface PageContent {
  url: string;
  title: string;
  timestamp: string;
  sections: PageSection[];
}

export interface FAQItem {
  question: string;
  answer: string;
  category?: string;
}

export interface FAQCategory {
  id: string;
  title: string;
  items: FAQItem[];
}

export interface FAQPage {
  categories: FAQCategory[];
}

export interface UseCase {
  id: string;
  title: string;
  description: string;
  benefits: string[];
  features: string[];
  image?: string;
  cta?: {
    label: string;
    href: string;
  };
}

export interface Guide {
  id: string;
  title: string;
  description: string;
  steps: GuideStep[];
  prerequisites?: string[];
  nextSteps?: string[];
}

export interface GuideStep {
  stepNumber: number;
  title: string;
  description: string;
  codeExample?: CodeExample;
  image?: string;
  tips?: string[];
}

export interface CodeExample {
  language: string;
  code: string;
  filename?: string;
  description?: string;
}

export interface CustomerStory {
  id: string;
  companyName: string;
  industry: string;
  title: string;
  summary: string;
  challenge: string;
  solution: string;
  results: string[];
  quote?: Quote;
  metrics?: Metric[];
  logo?: string;
  image?: string;
}

export interface Quote {
  text: string;
  author: string;
  position: string;
  company: string;
}

export interface Metric {
  label: string;
  value: string;
  description?: string;
}

export interface ContactForm {
  firstName: string;
  lastName: string;
  email: string;
  company?: string;
  subject: string;
  message: string;
}

export interface HeroSection {
  headline: string;
  subheadline?: string;
  description: string;
  primaryCTA?: CTAButton;
  secondaryCTA?: CTAButton;
  backgroundImage?: string;
}

export interface CTAButton {
  label: string;
  href: string;
  variant?: 'primary' | 'secondary' | 'tertiary';
  size?: 'large' | 'small' | 'micro';
}

export interface FeatureCard {
  id: string;
  icon?: string;
  title: string;
  description: string;
  link?: {
    label: string;
    href: string;
  };
}

export interface Testimonial {
  quote: string;
  author: string;
  position: string;
  company: string;
  avatar?: string;
}

export interface ContentBlock {
  type: 'text' | 'image' | 'video' | 'code' | 'table' | 'list' | 'callout';
  content: any;
  className?: string;
}

export interface Page {
  id: string;
  title: string;
  description?: string;
  metaTitle?: string;
  metaDescription?: string;
  breadcrumbs?: BreadcrumbItem[];
  hero?: HeroSection;
  content: ContentBlock[];
  sidebar?: SidebarContent;
}

export interface BreadcrumbItem {
  label: string;
  href?: string;
}

export interface SidebarContent {
  navigation?: SidebarNavItem[];
  widgets?: SidebarWidget[];
}

export interface SidebarNavItem {
  id: string;
  label: string;
  href: string;
  children?: SidebarNavItem[];
}

export interface SidebarWidget {
  id: string;
  type: 'cta' | 'related' | 'help' | 'info';
  title: string;
  content: any;
}
