/**
 * Navigation Type Definitions
 *
 * Types for navigation structures, menus, and breadcrumbs
 * based on scraped portal data
 */

export interface NavLink {
  text: string;
  href: string;
  title: string;
}

export interface NavSection {
  class: string;
  links: NavLink[];
}

export interface NavItem {
  label: string;
  href: string;
  children?: NavItem[];
}

export interface BreadcrumbItem {
  label: string;
  href?: string;
  isActive?: boolean;
}

export interface MenuItem {
  id: string;
  label: string;
  href?: string;
  icon?: string;
  badge?: string;
  children?: MenuItem[];
  isExternal?: boolean;
}

export interface FooterLink {
  label: string;
  href: string;
  isExternal?: boolean;
}

export interface FooterSection {
  title: string;
  links: FooterLink[];
}

export interface Navigation {
  main: NavItem[];
  footer: FooterSection[];
  legal: FooterLink[];
}
