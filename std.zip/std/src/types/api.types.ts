/**
 * API Type Definitions
 *
 * Types for API documentation, OpenAPI specs, and code samples
 * based on scraped portal data
 */

export interface APIEndpoint {
  method: 'GET' | 'POST' | 'PUT' | 'DELETE' | 'PATCH';
  path: string;
  summary?: string;
  description?: string;
  operationId?: string;
  tags?: string[];
  parameters?: APIParameter[];
  requestBody?: APIRequestBody;
  responses?: Record<string, APIResponse>;
  security?: SecurityRequirement[];
}

export interface APIParameter {
  name: string;
  in: 'query' | 'header' | 'path' | 'cookie';
  description?: string;
  required?: boolean;
  schema?: SchemaObject;
  example?: any;
}

export interface APIRequestBody {
  description?: string;
  required?: boolean;
  content?: Record<string, MediaType>;
}

export interface APIResponse {
  description: string;
  content?: Record<string, MediaType>;
  headers?: Record<string, Header>;
}

export interface MediaType {
  schema?: SchemaObject;
  example?: any;
  examples?: Record<string, Example>;
}

export interface SchemaObject {
  type?: string;
  format?: string;
  properties?: Record<string, SchemaObject>;
  required?: string[];
  items?: SchemaObject;
  enum?: any[];
  description?: string;
  example?: any;
  $ref?: string;
}

export interface Header {
  description?: string;
  schema?: SchemaObject;
}

export interface Example {
  value: any;
  summary?: string;
  description?: string;
}

export interface SecurityRequirement {
  [key: string]: string[];
}

export interface CodeSample {
  language: 'ruby' | 'python' | 'curl' | 'php' | 'java' | 'node' | 'go' | 'swift' | 'c' | 'csharp';
  code: string;
  label?: string;
}

export interface APIDocumentation {
  id: string;
  name: string;
  version: string;
  title: string;
  description: string;
  category: 'payments' | 'account-reporting' | 'authorize' | 'encryption';
  baseUrl: string;
  endpoints: APIEndpoint[];
  codeSamples?: CodeSample[];
  faqs?: FAQ[];
  contact?: ContactInfo;
}

export interface ContactInfo {
  name?: string;
  email?: string;
  url?: string;
}

export interface FAQ {
  question: string;
  answer: string;
  category?: string;
}

export interface APICard {
  id: string;
  name: string;
  description: string;
  category: string;
  documentationUrl: string;
  tryItUrl?: string;
  status?: 'available' | 'coming-soon';
  icon?: string;
}

export interface APICatalog {
  payments: APICard[];
  accountReporting: APICard[];
  authorization: APICard[];
  encryption: APICard[];
}
