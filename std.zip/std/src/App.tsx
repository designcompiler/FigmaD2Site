import { HeroSection } from './components/features/HeroSection';
import { UseCaseTabs } from './components/features/UseCaseTabs';
import './App.css';

function App() {
  const useCases = [
    {
      id: 'embedded-payments',
      title: 'Embedded payments',
      description:
        'Automate vendor payments, optimize cash flow and gain real-time visibility—right from your ERP or TMS.',
      href: '/use-cases/embedded-payments',
      image: 'placeholder',
    },
    {
      id: 'real-time-financial',
      title: 'Real-time financial intelligence',
      description:
        'Gain instant cash insights, improve liquidity, and make faster financial decisions.',
      href: '/use-cases/real-time-financial',
      image: 'placeholder',
    },
    {
      id: 'compliance-first',
      title: 'Compliance-first automation',
      description:
        'Automate reconciliation, enhance reporting accuracy, and support regulatory compliance — without compromising control.',
      href: '/use-cases/compliance-first-automation',
      image: 'placeholder',
    },
    {
      id: 'account-validation',
      title: 'Account validation',
      description:
        'Instantly verify bank account ownership to reduce risk, stay compliant, and prevent costly payment errors — so every transaction hits the mark. U.S. accounts only.',
      href: '/use-cases/account-validation',
      image: 'placeholder',
    },
  ];

  return (
    <>
      <HeroSection
        preHeader="Developer Portal"
        headline="Banking,"
        highlightedText="rewired."
        description="Whether you're expanding into new markets or embedding finance into your platform, our APIs give you the freedom to innovate without limits."
        primaryCTA={{
          text: 'Get Started',
          href: '/getting-started',
        }}
        secondaryCTA={{
          text: 'View APIs',
          href: '/apis',
        }}
      />

      <section className="w-full py-16">
        <div className="container px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">
              Our APIs help your business{' '}
              <span className="text-primary">move as fast as your ambition.</span>
            </h2>
          </div>

          <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
            <div className="border rounded-lg p-6 hover:shadow-lg transition-shadow">
              <h3 className="text-xl font-semibold mb-3">Payment APIs</h3>
              <p className="text-sm text-muted-foreground mb-4">
                Send, collect and track domestic or international payments directly from
                your in-house system or platform — plus verify U.S. recipient accounts with
                precision.
              </p>
              <a href="/apis/payments" className="text-primary hover:underline text-sm font-medium">
                Explore Payment APIs →
              </a>
            </div>
            <div className="border rounded-lg p-6 hover:shadow-lg transition-shadow">
              <h3 className="text-xl font-semibold mb-3">Account Reporting APIs</h3>
              <p className="text-sm text-muted-foreground mb-4">
                Access real-time account data, transaction history and cheque images. Designed
                for seamless integration and day-to-day control over your financial operations.
              </p>
              <a href="/apis/account-reporting" className="text-primary hover:underline text-sm font-medium">
                Explore Account Reporting APIs →
              </a>
            </div>
            <div className="border rounded-lg p-6 hover:shadow-lg transition-shadow">
              <h3 className="text-xl font-semibold mb-3">Pre-built Connectors</h3>
              <p className="text-sm text-muted-foreground mb-4">
                Seamlessly embed banking into your ERP system with our pre-built connectors.
                Automate your payments, reconciliation, and reporting — no custom code required.
              </p>
              <a href="/connectors" className="text-primary hover:underline text-sm font-medium">
                Explore Pre-built Connectors →
              </a>
            </div>
          </div>
        </div>
      </section>

      <UseCaseTabs useCases={useCases} autoRotate={true} rotateInterval={5000} />
    </>
  );
}

export default App;
