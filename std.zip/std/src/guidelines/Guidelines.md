**Add your own guidelines here**
<!--

System Guidelines

Use this file to provide the AI with rules and guidelines you want it to follow.
This template outlines a few examples of things you can add. You can add your own sections and format it to suit your needs

TIP: More context isn't always better. It can confuse the LLM. Try and add the most important rules you need

# General guidelines

Any general rules you want the AI to follow.
For example:

* Only use absolute positioning when necessary. Opt for responsive and well structured layouts that use flexbox and grid by default
* Refactor code as you go to keep code clean
* Keep file sizes small and put helper functions and components in their own files.

--------------

# Design system guidelines
Rules for how the AI should make generations look like your company's design system

Additionally, if you select a design system to use in the prompt box, you can reference
your design system's components, tokens, variables and components.
For example:

* Use a base font-size of 14px
* Date formats should always be in the format “Jun 10”
* The bottom toolbar should only ever have a maximum of 4 items
* Never use the floating action button with the bottom toolbar
* Chips should always come in sets of 3 or more
* Don't use a dropdown if there are 2 or fewer options

You can also create sub sections and add more specific details
For example:


## Button

### Variants

**Primary**
* When to use: Main action in a section (e.g., "Save", "Submit", "Continue")
* Shape: Pill-shaped (border-radius: 9999px) for Large/Small sizes
* Background: var(--primary) - #0075be light / #51aef6 dark
* Text: var(--primary-foreground) - #ffffff light / #101518 dark
* Hover: Darker shade of primary color
* Focus: 2px outline using var(--ring), 2px offset, rounded rectangle appearance
* Rule: Only ONE primary button per section

**Secondary**
* When to use: Supporting actions that complement the primary action
* Shape: Pill-shaped (border-radius: 9999px) for Large/Small sizes
* Border: 1px solid var(--primary) - #0075be light / #51aef6 dark
* Text: var(--primary) - #0075be light / #51aef6 dark
* Background: transparent
* Hover: Light background tint with var(--secondary)
* Focus: 2px outline using var(--ring), 2px offset, rounded rectangle appearance
* Rule: Can have multiple secondary buttons in a section

**Tertiary**
* When to use: Less prominent actions, alternative paths, or cancel actions
* Shape: Pill-shaped (border-radius: 9999px) for Large/Small sizes
* Border: none
* Text: var(--primary) - #0075be light / #51aef6 dark
* Background: transparent
* Hover: Light background tint with var(--secondary)
* Focus: 2px outline using var(--ring), 2px offset, rounded rectangle appearance
* Rule: Use for lower-priority actions

**Micro**
* When to use: Space-constrained areas, toolbars, tables, or when space is limited
* Shape: Rounded rectangle with moderate border-radius (NOT pill-shaped)
* Style: Can be Primary (filled), Secondary (outlined), or Tertiary (text-only)
* Colors: Same as respective variant (Primary/Secondary/Tertiary)
* Size: 32px height, can include icon, text, or both
* Focus: 2px outline using var(--ring), 2px offset, squared corners with rounded edges
* Rule: Must have accessible label if icon-only (aria-label or tooltip)

### Sizes & Border Radius
* Large: 48px height, 20px padding, **pill-shaped** (border-radius: 9999px)
* Small: 40px height, 16px padding, **pill-shaped** (border-radius: 9999px)
* Micro: 32px height, 12px padding, **rounded rectangle** (border-radius: ~8px)

### Visual States
* Default: Base colors as specified per variant
* Hover: Darker/lighter shade depending on variant and theme
* Focus: 2px solid outline, 2px offset, rounded rectangle appearance
* Pressed/Active: Even darker shade than hover
* Disabled: 40% opacity, grey text, no hover effects, cursor: not-allowed

### Critical Rules
1. Large/Small buttons use pill shape - Micro buttons use rounded rectangle
2. Focus state always visible - 2px outline using var(--ring) with 2px offset for keyboard accessibility
3. One primary per section - Never place multiple primary buttons in the same context
4. Destructive actions - Use var(--destructive) for delete/remove actions (#f71f27 light / #ed6e6e dark)
5. Disabled state - Reduce opacity to 40%, use var(--muted-foreground) for text, disable pointer events
6. Minimum contrast - Text must meet 4.5:1 contrast ratio (WCAG AA)

### Interaction Patterns
* Loading state: Show spinner, disable interaction, keep button width
* Icon + text: Icon left of text, 8px gap, 16px icon size
* Button groups: 8px gap between buttons, primary on right (LTR layouts)
-->
