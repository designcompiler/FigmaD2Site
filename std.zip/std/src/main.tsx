import { StrictMode } from 'react';
import { createRoot } from 'react-dom/client';
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import { ThemeProvider } from './components/theme-provider';
import { Layout } from './components/layout/Layout';
import { HomePage } from './components/pages/HomePage';
import { SolutionsGalleryPage } from './components/pages/SolutionsGalleryPage';
import { SolutionDetailPage } from './components/pages/SolutionDetailPage';
import { RecipesGalleryPage } from './components/pages/RecipesGalleryPage';
import { RecipeDetailPage } from './components/pages/RecipeDetailPage';
import { APICatalogPage } from './components/pages/APICatalogPage';
import { APIProductPage } from './components/pages/APIProductPage';
import './styles/globals.css';

createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <ThemeProvider defaultTheme="system" storageKey="dev-portal-theme">
      <BrowserRouter>
        <Routes>
          <Route path="/" element={<Layout />}>
            <Route index element={<HomePage />} />
            <Route path="solutions" element={<SolutionsGalleryPage />} />
            <Route path="solutions/:slug" element={<SolutionDetailPage />} />
            <Route path="recipes" element={<RecipesGalleryPage />} />
            <Route path="recipes/:slug" element={<RecipeDetailPage />} />
            <Route path="apis" element={<APICatalogPage />} />
            <Route path="apis/:slug" element={<APIProductPage />} />
          </Route>
        </Routes>
      </BrowserRouter>
    </ThemeProvider>
  </StrictMode>,
);
