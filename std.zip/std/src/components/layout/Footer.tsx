const footerLinks = [
  {
    label: 'Privacy Canada',
    href: 'https://developer.xyz.com/legal/privacy-ca',
  },
  {
    label: 'Privacy US',
    href: 'https://developer.xyz.com/legal/privacy-us',
  },
  {
    label: 'Legal Canada',
    href: 'https://developer.xyz.com/legal/legal-ca',
  },
  {
    label: 'Legal US',
    href: 'https://developer.xyz.com/legal/legal-us',
  },
  {
    label: 'Security Canada',
    href: 'https://developer.xyz.com/legal/security-ca',
  },
  {
    label: 'Security US',
    href: 'https://developer.xyz.com/legal/security-us',
  },
  {
    label: 'Terms and Conditions',
    href: 'https://developer.xyz.com/legal/terms',
  },
];

export function Footer() {
  return (
    <footer className="w-full bg-background mt-auto">
      <div className="w-full border-t">
        <div className="container px-4 py-8">
          {/* Footer Links */}
          <nav aria-label="Footer navigation">
            <ul className="flex flex-wrap items-center justify-center gap-x-6 gap-y-3 text-sm">
              {footerLinks.map((link, index) => (
                <li key={index}>
                  <a
                    href={link.href}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-muted-foreground hover:text-foreground transition-colors"
                  >
                    {link.label}
                  </a>
                </li>
              ))}
            </ul>
          </nav>
        </div>
      </div>
    </footer>
  );
}
