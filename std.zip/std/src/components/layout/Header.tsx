import { useState, useEffect } from 'react';
import { MenuIcon, GlobeIcon, Search, Code2 } from 'lucide-react';
import {
  NavigationMenu,
  NavigationMenuList,
  NavigationMenuItem,
  NavigationMenuTrigger,
  NavigationMenuContent,
  NavigationMenuLink,
} from '@/components/ui/navigation-menu';
import { Button } from '@/components/ui/button';
import {
  Sheet,
  SheetContent,
  SheetTrigger,
  SheetHeader,
  SheetTitle,
} from '@/components/ui/sheet';
import {
  DropdownMenu,
  DropdownMenuTrigger,
  DropdownMenuContent,
  DropdownMenuItem,
} from '@/components/ui/dropdown-menu';
import { ModeToggle } from '@/components/mode-toggle';
import { SearchOverlay } from '../features/SearchOverlay';

export function Header() {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [searchOpen, setSearchOpen] = useState(false);

  // Handle cmd+k / ctrl+k keyboard shortcut
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key === 'k') {
        e.preventDefault();
        setSearchOpen(true);
      }
    };

    document.addEventListener('keydown', handleKeyDown);
    return () => document.removeEventListener('keydown', handleKeyDown);
  }, []);

  return (
    <header className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
      <div className="container flex h-16 items-center px-4">
        {/* Logo - Left */}
        <div className="flex items-center flex-1">
          <a href="/" className="flex items-center gap-2">
            <div className="w-8 h-8 rounded bg-primary flex items-center justify-center">
              <Code2 className="h-5 w-5 text-primary-foreground" />
            </div>
          </a>
        </div>

        {/* Desktop Navigation - Center */}
        <NavigationMenu className="hidden lg:flex">
          <NavigationMenuList>
            {/* Getting Started */}
            <NavigationMenuItem>
              <NavigationMenuTrigger>Getting Started</NavigationMenuTrigger>
              <NavigationMenuContent>
                <div className="grid gap-3 p-4 w-[400px]">
                  <NavigationMenuLink href="/getting-started" className="block">
                    <div className="font-medium">Quick Start Guide</div>
                    <div className="text-muted-foreground text-xs">
                      Get up and running with our APIs in minutes
                    </div>
                  </NavigationMenuLink>
                  <NavigationMenuLink href="/authentication" className="block">
                    <div className="font-medium">Authentication</div>
                    <div className="text-muted-foreground text-xs">
                      Learn about OAuth 2.0 and API credentials
                    </div>
                  </NavigationMenuLink>
                  <NavigationMenuLink href="/sandbox" className="block">
                    <div className="font-medium">Sandbox Environment</div>
                    <div className="text-muted-foreground text-xs">
                      Test your integration in our sandbox
                    </div>
                  </NavigationMenuLink>
                </div>
              </NavigationMenuContent>
            </NavigationMenuItem>

            {/* Our APIs */}
            <NavigationMenuItem>
              <NavigationMenuTrigger>Our APIs</NavigationMenuTrigger>
              <NavigationMenuContent>
                <div className="grid gap-3 p-4 w-[500px] md:grid-cols-2">
                  <NavigationMenuLink href="/apis" className="block">
                    <div className="font-medium">API Catalog</div>
                    <div className="text-muted-foreground text-xs">
                      Browse all available APIs
                    </div>
                  </NavigationMenuLink>
                  <NavigationMenuLink href="/apis/payments" className="block">
                    <div className="font-medium">Payment APIs</div>
                    <div className="text-muted-foreground text-xs">
                      ACH, Wire, EFT, and Instant Payments
                    </div>
                  </NavigationMenuLink>
                  <NavigationMenuLink href="/apis/account-reporting" className="block">
                    <div className="font-medium">Account Reporting</div>
                    <div className="text-muted-foreground text-xs">
                      Account information and image retrieval
                    </div>
                  </NavigationMenuLink>
                  <NavigationMenuLink href="/apis/authorize" className="block">
                    <div className="font-medium">Authorization</div>
                    <div className="text-muted-foreground text-xs">
                      OAuth 2.0 authorization services
                    </div>
                  </NavigationMenuLink>
                </div>
              </NavigationMenuContent>
            </NavigationMenuItem>

            {/* Solutions */}
            <NavigationMenuItem>
              <NavigationMenuLink href="/solutions" className="group inline-flex h-9 w-max items-center justify-center rounded-md bg-background px-4 py-2 text-sm font-medium transition-colors hover:bg-accent hover:text-accent-foreground focus:bg-accent focus:text-accent-foreground focus:outline-none disabled:pointer-events-none disabled:opacity-50 data-[active]:bg-accent/50 data-[state=open]:bg-accent/50">
                Solutions
              </NavigationMenuLink>
            </NavigationMenuItem>

            {/* Recipes */}
            <NavigationMenuItem>
              <NavigationMenuLink href="/recipes" className="group inline-flex h-9 w-max items-center justify-center rounded-md bg-background px-4 py-2 text-sm font-medium transition-colors hover:bg-accent hover:text-accent-foreground focus:bg-accent focus:text-accent-foreground focus:outline-none disabled:pointer-events-none disabled:opacity-50 data-[active]:bg-accent/50 data-[state=open]:bg-accent/50">
                Recipes
              </NavigationMenuLink>
            </NavigationMenuItem>

            {/* Help Center */}
            <NavigationMenuItem>
              <NavigationMenuTrigger>Help</NavigationMenuTrigger>
              <NavigationMenuContent>
                <div className="grid gap-3 p-4 w-[400px]">
                  <NavigationMenuLink href="/faqs" className="block">
                    <div className="font-medium">FAQs</div>
                    <div className="text-muted-foreground text-xs">
                      Frequently asked questions and answers
                    </div>
                  </NavigationMenuLink>
                  <NavigationMenuLink href="/support" className="block">
                    <div className="font-medium">Support</div>
                    <div className="text-muted-foreground text-xs">
                      Documentation and guides
                    </div>
                  </NavigationMenuLink>
                  <NavigationMenuLink href="/contact" className="block">
                    <div className="font-medium">Contact Us</div>
                    <div className="text-muted-foreground text-xs">
                      Get in touch with our support team
                    </div>
                  </NavigationMenuLink>
                </div>
              </NavigationMenuContent>
            </NavigationMenuItem>
          </NavigationMenuList>
        </NavigationMenu>

        {/* Right Side Actions - Right */}
        <div className="flex items-center justify-end gap-2 flex-1">
          {/* Global Search Button - Desktop */}
          <button
            onClick={() => setSearchOpen(true)}
            className="hidden md:flex items-center gap-2 px-3 h-9 text-sm text-muted-foreground bg-muted/50 hover:bg-muted rounded-md border transition-colors w-[200px]"
          >
            <Search className="h-4 w-4" />
            <span className="flex-1 text-left">Search...</span>
            <kbd className="hidden lg:inline-flex h-5 select-none items-center gap-1 rounded border bg-background px-1.5 font-mono text-[10px] font-medium opacity-100">
              <span className="text-xs">⌘</span>K
            </kbd>
          </button>

          {/* Theme Toggle */}
          <ModeToggle />

          {/* Language Switcher (Desktop) */}
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" size="sm" className="hidden md:flex gap-1">
                <GlobeIcon className="size-4" />
                <span>EN</span>
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              <DropdownMenuItem>English (EN)</DropdownMenuItem>
              <DropdownMenuItem>Français (FR)</DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>

          {/* Sign In Button (Desktop) */}
          <Button variant="default" size="sm" className="hidden md:flex">
            Sign In
          </Button>

          {/* Mobile Menu */}
          <Sheet open={mobileMenuOpen} onOpenChange={setMobileMenuOpen}>
            <SheetTrigger asChild>
              <Button variant="ghost" size="icon" className="lg:hidden">
                <MenuIcon className="size-5" />
                <span className="sr-only">Toggle menu</span>
              </Button>
            </SheetTrigger>
            <SheetContent side="right" className="w-[300px] sm:w-[400px] overflow-y-auto">
              <SheetHeader>
                <SheetTitle>Menu</SheetTitle>
              </SheetHeader>
              <div className="flex flex-col gap-4 mt-4">
                {/* Mobile Search Button */}
                <button
                  onClick={() => {
                    setSearchOpen(true);
                    setMobileMenuOpen(false);
                  }}
                  className="md:hidden flex items-center gap-2 px-3 h-10 text-sm text-muted-foreground bg-muted/50 hover:bg-muted rounded-md border transition-colors"
                >
                  <Search className="h-4 w-4" />
                  <span className="flex-1 text-left">Search...</span>
                </button>

                {/* Getting Started Links */}
                <div>
                  <h3 className="font-semibold mb-2">Getting Started</h3>
                  <div className="flex flex-col gap-2 ml-2">
                    <a href="/getting-started" className="text-sm hover:text-primary">
                      Quick Start Guide
                    </a>
                    <a href="/authentication" className="text-sm hover:text-primary">
                      Authentication
                    </a>
                    <a href="/sandbox" className="text-sm hover:text-primary">
                      Sandbox Environment
                    </a>
                  </div>
                </div>

                {/* Our APIs Links */}
                <div>
                  <h3 className="font-semibold mb-2">Our APIs</h3>
                  <div className="flex flex-col gap-2 ml-2">
                    <a href="/apis" className="text-sm hover:text-primary">
                      API Catalog
                    </a>
                    <a href="/apis/payments" className="text-sm hover:text-primary">
                      Payment APIs
                    </a>
                    <a href="/apis/account-reporting" className="text-sm hover:text-primary">
                      Account Reporting
                    </a>
                    <a href="/apis/authorize" className="text-sm hover:text-primary">
                      Authorization
                    </a>
                  </div>
                </div>

                {/* Solutions */}
                <div>
                  <a href="/solutions" className="font-semibold hover:text-primary">
                    Solutions
                  </a>
                </div>

                {/* Recipes */}
                <div>
                  <a href="/recipes" className="font-semibold hover:text-primary">
                    Recipes
                  </a>
                </div>

                {/* Help Center Links */}
                <div>
                  <h3 className="font-semibold mb-2">Help</h3>
                  <div className="flex flex-col gap-2 ml-2">
                    <a href="/faqs" className="text-sm hover:text-primary">
                      FAQs
                    </a>
                    <a href="/support" className="text-sm hover:text-primary">
                      Support
                    </a>
                    <a href="/contact" className="text-sm hover:text-primary">
                      Contact Us
                    </a>
                  </div>
                </div>

                {/* Mobile Language Switcher */}
                <div className="border-t pt-4 mt-4">
                  <h3 className="font-semibold mb-2">Language</h3>
                  <div className="flex gap-2">
                    <Button variant="outline" size="sm" className="flex-1">
                      English (EN)
                    </Button>
                    <Button variant="ghost" size="sm" className="flex-1">
                      Français (FR)
                    </Button>
                  </div>
                </div>

                {/* Mobile Sign In Button */}
                <Button variant="default" className="w-full">
                  Sign In
                </Button>
              </div>
            </SheetContent>
          </Sheet>
        </div>
      </div>

      {/* Search Overlay */}
      <SearchOverlay isOpen={searchOpen} onClose={() => setSearchOpen(false)} />
    </header>
  );
}
