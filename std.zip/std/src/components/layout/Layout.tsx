import { Outlet } from 'react-router-dom';
import { Header } from './Header';
import { Breadcrumbs } from './Breadcrumbs';
import { Footer } from './Footer';
import type { BreadcrumbItem } from '@/types/navigation.types';

interface LayoutProps {
  breadcrumbs?: BreadcrumbItem[];
}

export function Layout({ breadcrumbs }: LayoutProps) {
  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      {breadcrumbs && breadcrumbs.length > 0 && (
        <Breadcrumbs items={breadcrumbs} />
      )}
      <main className="flex-1">
        <Outlet />
      </main>
      <Footer />
    </div>
  );
}
