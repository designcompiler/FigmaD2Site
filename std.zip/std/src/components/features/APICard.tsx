import { Card, CardHeader, CardTitle, CardDescription, CardContent, CardFooter } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { ArrowRight } from 'lucide-react';

interface APICardProps {
  name: string;
  description: string;
  category?: string;
  href: string;
  icon?: React.ReactNode;
}

export function APICard({ name, description, category, href, icon }: APICardProps) {
  return (
    <Card className="hover:shadow-lg transition-shadow">
      <CardHeader>
        <div className="flex items-start justify-between">
          <div className="flex-1">
            {category && (
              <Badge variant="secondary" className="mb-2">
                {category}
              </Badge>
            )}
            <CardTitle className="text-xl">{name}</CardTitle>
          </div>
          {icon && <div className="ml-4 text-primary">{icon}</div>}
        </div>
        <CardDescription className="text-sm mt-2">{description}</CardDescription>
      </CardHeader>
      <CardFooter>
        <Button asChild variant="outline" size="sm">
          <a href={href}>
            Learn More
            <ArrowRight className="ml-2 h-4 w-4" />
          </a>
        </Button>
      </CardFooter>
    </Card>
  );
}
