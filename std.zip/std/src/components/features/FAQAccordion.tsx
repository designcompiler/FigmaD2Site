import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from '@/components/ui/accordion';

interface FAQItem {
  id: string;
  question: string;
  answer: string;
}

interface FAQCategory {
  category: string;
  items: FAQItem[];
}

interface FAQAccordionProps {
  faqs: FAQItem[] | FAQCategory[];
  type?: 'single' | 'multiple';
  categorized?: boolean;
}

export function FAQAccordion({ faqs, type = 'single', categorized = false }: FAQAccordionProps) {
  if (faqs.length === 0) {
    return null;
  }

  // Render categorized FAQs
  if (categorized) {
    const categories = faqs as FAQCategory[];
    return (
      <div className="w-full space-y-8">
        {categories.map((category, catIndex) => (
          <div key={catIndex}>
            <h3 className="text-xl font-semibold mb-4">{category.category}</h3>
            <Accordion type={type} className="w-full">
              {category.items.map((item) => (
                <AccordionItem key={item.id} value={item.id}>
                  <AccordionTrigger className="text-left">
                    {item.question}
                  </AccordionTrigger>
                  <AccordionContent>
                    <div className="text-muted-foreground">{item.answer}</div>
                  </AccordionContent>
                </AccordionItem>
              ))}
            </Accordion>
          </div>
        ))}
      </div>
    );
  }

  // Render simple FAQ list
  const items = faqs as FAQItem[];
  return (
    <Accordion type={type} className="w-full">
      {items.map((item) => (
        <AccordionItem key={item.id} value={item.id}>
          <AccordionTrigger className="text-left">{item.question}</AccordionTrigger>
          <AccordionContent>
            <div className="text-muted-foreground">{item.answer}</div>
          </AccordionContent>
        </AccordionItem>
      ))}
    </Accordion>
  );
}
