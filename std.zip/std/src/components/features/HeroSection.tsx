import { Button } from '@/components/ui/button';
import { ArrowRight } from 'lucide-react';

interface HeroSectionProps {
  preHeader?: string;
  headline: string;
  highlightedText?: string;
  description: string;
  primaryCTA: {
    text: string;
    href: string;
  };
  secondaryCTA?: {
    text: string;
    href: string;
  };
}

export function HeroSection({
  preHeader,
  headline,
  highlightedText,
  description,
  primaryCTA,
  secondaryCTA,
}: HeroSectionProps) {
  return (
    <section className="w-full bg-gradient-to-br from-primary/5 via-background to-accent/5">
      <div className="container px-4 py-16 md:py-24 lg:py-32">
        <div className="flex flex-col items-center text-center max-w-4xl mx-auto space-y-6">
          {/* Pre-header */}
          {preHeader && (
            <p className="text-sm font-medium text-muted-foreground uppercase tracking-wide">
              {preHeader}
            </p>
          )}

          {/* Headline */}
          <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold tracking-tight">
            {headline}
            {highlightedText && (
              <>
                {' '}
                <span className="text-primary">{highlightedText}</span>
              </>
            )}
          </h1>

          {/* Description */}
          <p className="text-lg md:text-xl text-muted-foreground max-w-3xl">
            {description}
          </p>

          {/* CTAs */}
          <div className="flex flex-col sm:flex-row gap-4 pt-4">
            <Button asChild variant="default" size="lg">
              <a href={primaryCTA.href}>
                {primaryCTA.text}
                <ArrowRight className="ml-2 h-4 w-4" />
              </a>
            </Button>

            {secondaryCTA && (
              <Button asChild variant="outline" size="lg">
                <a href={secondaryCTA.href}>{secondaryCTA.text}</a>
              </Button>
            )}
          </div>
        </div>
      </div>
    </section>
  );
}
