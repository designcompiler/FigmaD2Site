import { useEffect, useState } from 'react';
import { Search, X } from 'lucide-react';
import { Input } from '../ui/input';

interface SearchOverlayProps {
  isOpen: boolean;
  onClose: () => void;
}

export function SearchOverlay({ isOpen, onClose }: SearchOverlayProps) {
  const [searchQuery, setSearchQuery] = useState('');

  useEffect(() => {
    if (isOpen) {
      // Focus input when overlay opens
      setTimeout(() => {
        document.getElementById('search-overlay-input')?.focus();
      }, 100);
    } else {
      // Clear search when closing
      setSearchQuery('');
    }
  }, [isOpen]);

  useEffect(() => {
    const handleEscape = (e: KeyboardEvent) => {
      if (e.key === 'Escape' && isOpen) {
        onClose();
      }
    };

    document.addEventListener('keydown', handleEscape);
    return () => document.removeEventListener('keydown', handleEscape);
  }, [isOpen, onClose]);

  if (!isOpen) return null;

  return (
    <div
      className="fixed inset-0 z-[100] flex items-start justify-center pt-[10vh]"
      onClick={onClose}
    >
      {/* Glass morphism background */}
      <div className="absolute inset-0 bg-background/80 backdrop-blur-md" />

      {/* Search container */}
      <div
        className="relative w-full max-w-2xl mx-4"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Search input */}
        <div className="relative">
          <Search className="absolute left-4 top-1/2 -translate-y-1/2 h-5 w-5 text-muted-foreground" />
          <Input
            id="search-overlay-input"
            type="text"
            placeholder="Search APIs, solutions, recipes, and documentation..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="h-14 pl-12 pr-12 text-lg border-2 shadow-2xl bg-background"
          />
          <button
            onClick={onClose}
            className="absolute right-4 top-1/2 -translate-y-1/2 p-1 hover:bg-muted rounded"
          >
            <X className="h-5 w-5 text-muted-foreground" />
          </button>
        </div>

        {/* Search results placeholder */}
        {searchQuery && (
          <div className="mt-4 bg-background border-2 rounded-lg shadow-2xl max-h-[60vh] overflow-y-auto">
            <div className="p-8 text-center text-muted-foreground">
              <p className="text-sm">Search results for "{searchQuery}"</p>
              <p className="text-xs mt-2">Search functionality will be implemented soon.</p>
            </div>
          </div>
        )}

        {/* Quick links when no search */}
        {!searchQuery && (
          <div className="mt-4 bg-background border-2 rounded-lg shadow-2xl p-6">
            <h3 className="text-sm font-semibold mb-4">Quick Links</h3>
            <div className="grid gap-3">
              <a
                href="/getting-started"
                className="flex items-center gap-3 p-3 rounded hover:bg-muted transition-colors"
              >
                <div className="text-sm">
                  <div className="font-medium">Getting Started</div>
                  <div className="text-muted-foreground text-xs">Quick start guide</div>
                </div>
              </a>
              <a
                href="/apis"
                className="flex items-center gap-3 p-3 rounded hover:bg-muted transition-colors"
              >
                <div className="text-sm">
                  <div className="font-medium">API Catalog</div>
                  <div className="text-muted-foreground text-xs">Browse all APIs</div>
                </div>
              </a>
              <a
                href="/solutions"
                className="flex items-center gap-3 p-3 rounded hover:bg-muted transition-colors"
              >
                <div className="text-sm">
                  <div className="font-medium">Solutions</div>
                  <div className="text-muted-foreground text-xs">Business solutions</div>
                </div>
              </a>
              <a
                href="/recipes"
                className="flex items-center gap-3 p-3 rounded hover:bg-muted transition-colors"
              >
                <div className="text-sm">
                  <div className="font-medium">Recipes</div>
                  <div className="text-muted-foreground text-xs">Technical implementation guides</div>
                </div>
              </a>
            </div>
          </div>
        )}

        {/* Keyboard hint */}
        <div className="mt-4 text-center text-xs text-muted-foreground">
          Press <kbd className="px-2 py-1 bg-muted rounded border">ESC</kbd> to close
        </div>
      </div>
    </div>
  );
}
