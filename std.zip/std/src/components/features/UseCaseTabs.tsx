import { useState, useEffect } from 'react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Button } from '@/components/ui/button';
import { ArrowRight } from 'lucide-react';

interface UseCase {
  id: string;
  title: string;
  description: string;
  href: string;
  image?: string;
}

interface UseCaseTabsProps {
  useCases: UseCase[];
  autoRotate?: boolean;
  rotateInterval?: number; // in milliseconds
}

export function UseCaseTabs({
  useCases,
  autoRotate = true,
  rotateInterval = 5000,
}: UseCaseTabsProps) {
  const [activeTab, setActiveTab] = useState(useCases[0]?.id || '');

  useEffect(() => {
    if (!autoRotate || useCases.length === 0) return;

    const interval = setInterval(() => {
      setActiveTab((current) => {
        const currentIndex = useCases.findIndex((uc) => uc.id === current);
        const nextIndex = (currentIndex + 1) % useCases.length;
        return useCases[nextIndex].id;
      });
    }, rotateInterval);

    return () => clearInterval(interval);
  }, [autoRotate, rotateInterval, useCases]);

  if (useCases.length === 0) {
    return null;
  }

  return (
    <section className="w-full bg-muted/30 py-16">
      <div className="container px-4">
        <h2 className="text-3xl md:text-4xl font-bold text-center mb-12">
          See what's possible with our APIs.
        </h2>

        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          {/* Tabs List */}
          <TabsList className="w-full h-auto p-2 grid grid-cols-2 md:grid-cols-4 gap-2 bg-background border">
            {useCases.map((useCase) => (
              <TabsTrigger
                key={useCase.id}
                value={useCase.id}
                className="px-4 py-3 text-sm md:text-base whitespace-normal min-h-[60px]"
              >
                {useCase.title}
              </TabsTrigger>
            ))}
          </TabsList>

          {/* Tabs Content */}
          <div className="mt-8">
            {useCases.map((useCase) => (
              <TabsContent
                key={useCase.id}
                value={useCase.id}
                className="mt-0"
              >
                <div className="flex flex-col md:flex-row gap-8 items-center">
                  {/* Content */}
                  <div className="flex-1 space-y-4">
                    <h3 className="text-2xl md:text-3xl font-bold">
                      {useCase.title}
                    </h3>
                    <p className="text-lg text-muted-foreground">
                      {useCase.description}
                    </p>
                    <Button asChild variant="default" size="lg">
                      <a href={useCase.href}>
                        Learn More
                        <ArrowRight className="ml-2 h-4 w-4" />
                      </a>
                    </Button>
                  </div>

                  {/* Visual/Image Placeholder */}
                  {useCase.image && (
                    <div className="flex-1 flex items-center justify-center">
                      <div className="w-full aspect-video bg-gradient-to-br from-primary/10 to-accent/10 rounded-lg flex items-center justify-center">
                        <span className="text-muted-foreground text-sm">
                          {useCase.title} Illustration
                        </span>
                      </div>
                    </div>
                  )}
                </div>
              </TabsContent>
            ))}
          </div>
        </Tabs>
      </div>
    </section>
  );
}
