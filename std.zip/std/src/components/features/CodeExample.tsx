import { useState } from 'react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Button } from '@/components/ui/button';
import { Check, Copy } from 'lucide-react';

interface CodeSample {
  language: string;
  code: string;
  label?: string;
}

interface CodeExampleProps {
  samples: CodeSample[];
  title?: string;
}

export function CodeExample({ samples, title }: CodeExampleProps) {
  const [copiedIndex, setCopiedIndex] = useState<number | null>(null);

  const handleCopy = async (code: string, index: number) => {
    try {
      await navigator.clipboard.writeText(code);
      setCopiedIndex(index);
      setTimeout(() => setCopiedIndex(null), 2000);
    } catch (err) {
      console.error('Failed to copy code:', err);
    }
  };

  if (samples.length === 0) {
    return null;
  }

  return (
    <div className="w-full">
      {title && (
        <h3 className="text-lg font-semibold mb-4">{title}</h3>
      )}

      <Tabs defaultValue={samples[0].language} className="w-full">
        <div className="flex items-center justify-between mb-2">
          <TabsList>
            {samples.map((sample) => (
              <TabsTrigger key={sample.language} value={sample.language}>
                {sample.label || sample.language}
              </TabsTrigger>
            ))}
          </TabsList>
        </div>

        {samples.map((sample, index) => (
          <TabsContent key={sample.language} value={sample.language} className="mt-0">
            <div className="relative">
              <div className="absolute right-2 top-2 z-10">
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => handleCopy(sample.code, index)}
                  className="h-8 px-2"
                >
                  {copiedIndex === index ? (
                    <>
                      <Check className="h-4 w-4 mr-1" />
                      Copied
                    </>
                  ) : (
                    <>
                      <Copy className="h-4 w-4 mr-1" />
                      Copy
                    </>
                  )}
                </Button>
              </div>
              <pre className="overflow-x-auto rounded-lg border bg-muted/50 p-4 pr-20">
                <code className="text-sm font-mono">{sample.code}</code>
              </pre>
            </div>
          </TabsContent>
        ))}
      </Tabs>
    </div>
  );
}
