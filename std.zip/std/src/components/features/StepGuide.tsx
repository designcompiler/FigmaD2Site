import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';

interface Step {
  number: number;
  title: string;
  description: string;
  code?: string;
  language?: string;
}

interface StepGuideProps {
  steps: Step[];
  title?: string;
}

export function StepGuide({ steps, title }: StepGuideProps) {
  if (steps.length === 0) {
    return null;
  }

  return (
    <div className="w-full">
      {title && (
        <h2 className="text-2xl md:text-3xl font-bold mb-8 text-center">{title}</h2>
      )}

      <div className="space-y-8">
        {steps.map((step, index) => {
          const isLast = index === steps.length - 1;

          return (
            <div key={step.number}>
              <div className="flex gap-6">
                {/* Step Number Badge */}
                <div className="flex flex-col items-center">
                  <Badge
                    variant="default"
                    className="h-10 w-10 rounded-full flex items-center justify-center text-lg font-bold shrink-0"
                  >
                    {step.number}
                  </Badge>
                  {!isLast && (
                    <Separator
                      orientation="vertical"
                      className="h-full min-h-[80px] my-2"
                    />
                  )}
                </div>

                {/* Step Content */}
                <div className="flex-1 pb-8">
                  <h3 className="text-xl font-semibold mb-2">{step.title}</h3>
                  <p className="text-muted-foreground mb-4">{step.description}</p>

                  {/* Code Example */}
                  {step.code && (
                    <div className="mt-4">
                      <pre className="overflow-x-auto rounded-lg border bg-muted/50 p-4">
                        <code className="text-sm font-mono">{step.code}</code>
                      </pre>
                      {step.language && (
                        <p className="text-xs text-muted-foreground mt-2">
                          {step.language}
                        </p>
                      )}
                    </div>
                  )}
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
