import { useParams, useNavigate } from 'react-router-dom';
import { ArrowLeft, Code2, CheckCircle2, Database, Globe, ExternalLink, AlertCircle, Key, Copy, Check, ChevronRight } from 'lucide-react';
import { useState } from 'react';
import { Button } from '../ui/button';
import { Badge } from '../ui/badge';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../ui/tabs';

// Import recipe data
import recipe1 from '@/data/recipe-1-vendor-payment-ach-validation.json';
import recipe2 from '@/data/recipe-2-canadian-eft-batch.json';
import recipe3 from '@/data/recipe-3-instant-payout-interac.json';
import recipe4 from '@/data/recipe-4-treasury-dashboard.json';
import recipe5 from '@/data/recipe-5-cheque-image-access.json';
import recipe6 from '@/data/recipe-6-erp-pay-now-button.json';
import recipe7 from '@/data/recipe-7-oauth-authorization-flow.json';
import recipe8 from '@/data/recipe-8-payment-status-wallboard.json';
import recipe9 from '@/data/recipe-9-sandbox-qa-automation.json';
import recipe10 from '@/data/recipe-10-automated-reconciliation.json';

const allRecipes = [
  recipe1,
  recipe2,
  recipe3,
  recipe4,
  recipe5,
  recipe6,
  recipe7,
  recipe8,
  recipe9,
  recipe10,
];

export function RecipeDetailPage() {
  const { slug } = useParams<{ slug: string }>();
  const navigate = useNavigate();
  const [copiedStep, setCopiedStep] = useState<number | null>(null);

  const recipe = allRecipes.find((r) => r.slug === slug);

  const copyToClipboard = async (text: string, stepNumber: number) => {
    try {
      await navigator.clipboard.writeText(text);
      setCopiedStep(stepNumber);
      setTimeout(() => setCopiedStep(null), 2000);
    } catch (err) {
      console.error('Failed to copy:', err);
    }
  };

  if (!recipe) {
    return (
      <div className="w-full py-16">
        <div className="container px-4">
          <div className="max-w-3xl mx-auto text-center">
            <h1 className="text-3xl font-bold mb-4">Recipe Not Found</h1>
            <p className="text-muted-foreground mb-8">
              The recipe you're looking for doesn't exist.
            </p>
            <Button onClick={() => navigate('/recipes')}>
              Back to Recipes
            </Button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="w-full">
      {/* Hero Section - Compact */}
      <section className="w-full py-8 bg-gradient-to-br from-blue-600/5 via-cyan-500/5 to-background border-b">
        <div className="container px-4">
          <div className="max-w-5xl mx-auto">
            <button
              onClick={() => navigate('/recipes')}
              className="inline-flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground transition-colors -ml-2 mb-4"
            >
              <ArrowLeft className="h-4 w-4" />
              Back to Recipes
            </button>
            <h1 className="text-3xl md:text-4xl font-bold mb-3">
              {recipe.title}
            </h1>
            <p className="text-lg text-muted-foreground mb-4">
              {recipe.overview}
            </p>
            <div className="flex flex-wrap gap-2 items-center">
              <Badge variant="outline" className="gap-1.5 bg-primary/10 border-primary text-primary font-medium">
                <Code2 className="h-3.5 w-3.5" />
                {recipe.apis.length} APIs
              </Badge>
              <Badge variant="outline" className="gap-1.5 bg-primary/10 border-primary text-primary font-medium">
                <CheckCircle2 className="h-3.5 w-3.5" />
                {recipe.implementationSteps?.length || 0} Steps
              </Badge>
            </div>
          </div>
        </div>
      </section>

      <div className="container px-4 py-10">
        <div className="max-w-5xl mx-auto space-y-10">
          {/* Business Problem & Value - Side by side */}
          <section className="grid md:grid-cols-2 gap-8">
            {/* Business Problem */}
            <div>
              <div className="flex items-center gap-2 mb-3">
                <AlertCircle className="h-5 w-5 text-primary" />
                <h2 className="text-xl font-bold">Business Problem</h2>
              </div>
              <p className="text-muted-foreground leading-relaxed">
                {recipe.businessProblem}
              </p>
            </div>

            {/* Business Value */}
            <div>
              <div className="flex items-center gap-2 mb-3">
                <CheckCircle2 className="h-5 w-5 text-primary" />
                <h2 className="text-xl font-bold">Business Value</h2>
              </div>
              <p className="text-muted-foreground leading-relaxed">
                {recipe.businessValue}
              </p>
            </div>
          </section>

          {/* APIs Used */}
          <section>
            <h2 className="text-xl font-bold mb-4">APIs Used</h2>
            <div className="space-y-3">
              {recipe.apis.map((api, index) => (
                <div key={index} className="flex items-start gap-3 p-4 border rounded-lg hover:bg-muted/50 transition-colors">
                  <Database className="h-5 w-5 text-primary shrink-0 mt-0.5" />
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 mb-1 flex-wrap">
                      <code className="font-mono text-sm font-semibold">{api.endpoint}</code>
                      {api.isoMessage && api.isoMessage !== 'N/A' && (
                        <Badge variant="secondary" className="text-xs">
                          {api.isoMessage}
                        </Badge>
                      )}
                    </div>
                    <p className="text-sm text-muted-foreground mb-2">{api.purpose}</p>
                    <a
                      href={api.documentation_url}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-xs text-primary hover:underline inline-flex items-center gap-1"
                    >
                      View Documentation
                      <ExternalLink className="h-3 w-3" />
                    </a>
                  </div>
                </div>
              ))}
            </div>
          </section>

          {/* Prerequisites & Authentication */}
          {recipe.prerequisites && (
            <section>
              <h2 className="text-xl font-bold mb-4">Prerequisites & Authentication</h2>
              <Card>
                <CardContent className="pt-6 space-y-6">
                  {/* Requirements */}
                  {recipe.prerequisites.requirements && (
                    <div>
                      <h3 className="font-semibold mb-3 flex items-center gap-2">
                        <CheckCircle2 className="h-4 w-4 text-primary" />
                        Requirements
                      </h3>
                      <ul className="space-y-2">
                        {recipe.prerequisites.requirements.map((req, index) => (
                          <li key={index} className="text-sm text-muted-foreground flex items-start gap-2">
                            <ChevronRight className="h-4 w-4 mt-0.5 shrink-0 text-primary" />
                            <span>{req}</span>
                          </li>
                        ))}
                      </ul>
                    </div>
                  )}

                  {/* OAuth Scopes */}
                  {recipe.prerequisites.oauthScopes && (
                    <div>
                      <h3 className="font-semibold mb-3 flex items-center gap-2">
                        <Key className="h-4 w-4 text-primary" />
                        OAuth Scopes Required
                      </h3>
                      <div className="flex flex-wrap gap-2">
                        {recipe.prerequisites.oauthScopes.map((scope, index) => (
                          <Badge key={index} variant="secondary" className="font-mono text-xs">
                            {scope}
                          </Badge>
                        ))}
                      </div>
                    </div>
                  )}

                  {/* Authentication Details */}
                  {recipe.prerequisites.authenticationDetails && (
                    <div>
                      <h3 className="font-semibold mb-3">Authentication Flow</h3>
                      <div className="space-y-2 text-sm">
                        <div className="flex items-center gap-2">
                          <span className="text-muted-foreground">Flow:</span>
                          <Badge variant="outline">{recipe.prerequisites.authenticationDetails.flow}</Badge>
                        </div>
                        {recipe.prerequisites.authenticationDetails.tokenExpiry && (
                          <div className="flex items-start gap-2">
                            <span className="text-muted-foreground shrink-0">Token Expiry:</span>
                            <div className="space-y-1">
                              <div>Production: {recipe.prerequisites.authenticationDetails.tokenExpiry.production}</div>
                              {recipe.prerequisites.authenticationDetails.tokenExpiry.sandbox && (
                                <div>Sandbox: {recipe.prerequisites.authenticationDetails.tokenExpiry.sandbox}</div>
                              )}
                            </div>
                          </div>
                        )}
                      </div>
                    </div>
                  )}
                </CardContent>
              </Card>
            </section>
          )}

          {/* Implementation Steps */}
          {recipe.implementationSteps && recipe.implementationSteps.length > 0 && (
            <section>
              <h2 className="text-xl font-bold mb-6">Implementation Guide</h2>
              <div className="space-y-8">
                {recipe.implementationSteps.map((step, index) => (
                  <div key={step.step} className="flex gap-5">
                    <div className="flex flex-col items-center">
                      <div className="w-10 h-10 rounded-full bg-primary text-primary-foreground flex items-center justify-center text-sm font-bold shrink-0">
                        {step.step}
                      </div>
                      {index < recipe.implementationSteps.length - 1 && (
                        <div className="w-0.5 h-full bg-border mt-3" />
                      )}
                    </div>
                    <div className="flex-1 pb-4">
                      <h3 className="font-semibold text-base mb-3">{step.title}</h3>
                      <p className="text-sm text-muted-foreground leading-relaxed mb-4">
                        {step.description}
                      </p>

                      {/* Code Example */}
                      {step.codeExample && (
                        <div className="mb-4">
                          <div className="flex items-center justify-between mb-2">
                            <span className="text-xs font-semibold text-muted-foreground">Code Example</span>
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => copyToClipboard(step.codeExample, step.step)}
                              className="h-7 text-xs"
                            >
                              {copiedStep === step.step ? (
                                <Check className="h-3 w-3 mr-1" />
                              ) : (
                                <Copy className="h-3 w-3 mr-1" />
                              )}
                              {copiedStep === step.step ? 'Copied' : 'Copy'}
                            </Button>
                          </div>
                          <pre className="bg-slate-950 dark:bg-slate-900 p-4 rounded-lg overflow-x-auto border border-slate-800">
                            <code className="text-xs text-slate-100">{step.codeExample}</code>
                          </pre>
                        </div>
                      )}

                      {/* Request & Response Samples */}
                      {(step.requestSample || step.responseSample) && (
                        <Tabs defaultValue="request" className="w-full">
                          <TabsList className="grid w-full grid-cols-2">
                            <TabsTrigger value="request" disabled={!step.requestSample}>Request</TabsTrigger>
                            <TabsTrigger value="response" disabled={!step.responseSample}>Response</TabsTrigger>
                          </TabsList>
                          {step.requestSample && (
                            <TabsContent value="request">
                              <pre className="bg-slate-950 dark:bg-slate-900 p-4 rounded-lg overflow-x-auto border border-slate-800 mt-2">
                                <code className="text-xs text-slate-100">{step.requestSample}</code>
                              </pre>
                            </TabsContent>
                          )}
                          {step.responseSample && (
                            <TabsContent value="response">
                              <pre className="bg-slate-950 dark:bg-slate-900 p-4 rounded-lg overflow-x-auto border border-slate-800 mt-2">
                                <code className="text-xs text-slate-100">{step.responseSample}</code>
                              </pre>
                            </TabsContent>
                          )}
                        </Tabs>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </section>
          )}

          {/* Error Handling */}
          {recipe.errorHandling && recipe.errorHandling.length > 0 && (
            <section>
              <h2 className="text-xl font-bold mb-4">Error Handling & Edge Cases</h2>
              <Card>
                <CardContent className="pt-6 space-y-4">
                  {recipe.errorHandling.map((error, index) => (
                    <div key={index} className="pb-4 border-b last:border-b-0 last:pb-0">
                      <div className="flex items-start gap-3 mb-2">
                        <AlertCircle className="h-5 w-5 text-destructive shrink-0 mt-0.5" />
                        <div className="flex-1">
                          <h3 className="font-semibold mb-1">{error.errorType || error.scenario}</h3>
                          <p className="text-sm text-muted-foreground mb-2">{error.description}</p>
                          <div className="text-sm">
                            <span className="font-medium text-primary">Solution: </span>
                            <span className="text-muted-foreground">{error.solution || error.action}</span>
                          </div>
                        </div>
                      </div>
                    </div>
                  ))}
                </CardContent>
              </Card>
            </section>
          )}

          {/* Variants & Extensions */}
          {recipe.variants && recipe.variants.length > 0 && (
            <section>
              <h2 className="text-xl font-bold mb-4">Variants & Extensions</h2>
              <div className="grid gap-4">
                {recipe.variants.map((variant, index) => (
                  <Card key={index}>
                    <CardHeader>
                      <CardTitle className="text-base">{variant.title}</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <p className="text-sm text-muted-foreground">{variant.description}</p>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </section>
          )}

          {/* Industries & Personas - Side by side */}
          <section className="grid md:grid-cols-2 gap-8">
            <div>
              <h3 className="font-semibold mb-3">Target Industries</h3>
              <div className="flex flex-wrap gap-2">
                {recipe.industries.map((industry, index) => (
                  <Badge key={index} variant="outline">
                    {industry}
                  </Badge>
                ))}
              </div>
            </div>

            <div>
              <h3 className="font-semibold mb-3">Target Personas</h3>
              <div className="flex flex-wrap gap-2">
                {recipe.personas.map((persona, index) => (
                  <Badge key={index} variant="outline">
                    {persona}
                  </Badge>
                ))}
              </div>
            </div>
          </section>

          {/* CTA Section */}
          <section className="border-t pt-8">
            <div className="text-center space-y-4">
              <h3 className="text-2xl font-bold">Ready to Implement?</h3>
              <p className="text-muted-foreground">
                Explore our APIs and start building with this recipe today.
              </p>
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <Button size="lg" asChild>
                  <a href="/apis">Browse API Catalog</a>
                </Button>
                <Button size="lg" variant="outline" asChild>
                  <a href="/contact">Contact Developer Support</a>
                </Button>
              </div>
            </div>
          </section>
        </div>
      </div>
    </div>
  );
}
