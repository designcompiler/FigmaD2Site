import { useState } from 'react';
import { BookOpen, Filter, ChevronDown, Search, Check } from 'lucide-react';
import { Button } from '../ui/button';
import { Input } from '../ui/input';
import {
  DropdownMenu,
  DropdownMenuTrigger,
  DropdownMenuContent,
} from '../ui/dropdown-menu';
import { Command, CommandInput, CommandList, CommandEmpty, CommandGroup, CommandItem } from '../ui/command';

// Import solution data
import solution1 from '@/data/solution-1-automated-north-american-payables.json';
import solution2 from '@/data/solution-2-real-time-treasury-visibility.json';
import solution3 from '@/data/solution-3-instant-payouts-interac.json';
import solution4 from '@/data/solution-4-vendor-onboarding-validation.json';
import solution5 from '@/data/solution-5-embedded-erp-banking.json';
import solution6 from '@/data/solution-6-cross-border-payments.json';
import solution7 from '@/data/solution-7-cheque-image-access.json';
import solution8 from '@/data/solution-8-oauth-corporate-data-access.json';

const allSolutions = [
  solution1,
  solution2,
  solution3,
  solution4,
  solution5,
  solution6,
  solution7,
  solution8,
];

export function SolutionsGalleryPage() {
  const [selectedIndustry, setSelectedIndustry] = useState<string>('all');
  const [filterOpen, setFilterOpen] = useState(false);

  // Get all unique industries
  const allIndustries = Array.from(
    new Set(allSolutions.flatMap((solution) => solution.industries))
  ).sort();

  // Filter solutions by industry only
  const filteredSolutions = allSolutions.filter((solution) => {
    return selectedIndustry === 'all' || solution.industries.includes(selectedIndustry);
  });

  return (
    <div className="w-full">
      {/* Hero Section with Futuristic Blue Gradient */}
      <section className="relative w-full overflow-hidden py-16 pb-8">
        {/* Futuristic blue gradient background */}
        <div className="absolute inset-0 bg-gradient-to-br from-blue-600/20 via-cyan-500/10 to-blue-900/20" />
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-blue-400/20 via-transparent to-transparent" />
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_bottom_right,_var(--tw-gradient-stops))] from-cyan-400/15 via-transparent to-transparent" />

        <div className="container px-4 relative z-10">
          <div className="max-w-3xl mx-auto text-center">
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold mb-6">
              Business Solutions
            </h1>
            <p className="text-lg md:text-xl text-muted-foreground">
              Discover outcome-driven solutions designed for your specific business needs.
              Each solution combines multiple APIs to solve real-world business challenges.
            </p>
          </div>
        </div>
      </section>

      {/* Solutions Grid with Filter */}
      <section className="w-full pt-8 pb-16">
        <div className="container px-4">
          {/* Searchable Industry Filter - Aligned Left */}
          <div className="mb-8">
            <DropdownMenu open={filterOpen} onOpenChange={setFilterOpen}>
              <DropdownMenuTrigger asChild>
                <Button variant="outline" size="default" className="gap-2 min-w-[240px]">
                  <Filter className="h-4 w-4" />
                  <span className="flex-1 text-left truncate">
                    {selectedIndustry === 'all' ? 'Filter by Industry' : selectedIndustry}
                  </span>
                  <ChevronDown className="h-4 w-4" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="start" className="w-[300px] p-0">
                <Command>
                  <CommandInput placeholder="Search industries..." />
                  <CommandList>
                    <CommandEmpty>No industry found.</CommandEmpty>
                    <CommandGroup>
                      <CommandItem
                        onSelect={() => {
                          setSelectedIndustry('all');
                          setFilterOpen(false);
                        }}
                      >
                        <Check
                          className={`mr-2 h-4 w-4 ${
                            selectedIndustry === 'all' ? 'opacity-100' : 'opacity-0'
                          }`}
                        />
                        All Industries
                      </CommandItem>
                      {allIndustries.map((industry) => (
                        <CommandItem
                          key={industry}
                          onSelect={() => {
                            setSelectedIndustry(industry);
                            setFilterOpen(false);
                          }}
                        >
                          <Check
                            className={`mr-2 h-4 w-4 ${
                              selectedIndustry === industry ? 'opacity-100' : 'opacity-0'
                            }`}
                          />
                          {industry}
                        </CommandItem>
                      ))}
                    </CommandGroup>
                  </CommandList>
                </Command>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>

          {/* Grid */}
          <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
            {filteredSolutions.map((solution) => {
              return (
                <a
                  key={solution.id}
                  href={`/solutions/${solution.slug}`}
                  className="group relative border rounded-xl p-6 hover:shadow-2xl transition-all duration-300 hover:border-primary/50 bg-background overflow-hidden hover:-translate-y-1"
                >
                  {/* Subtle gradient background on hover */}
                  <div className="absolute inset-0 bg-gradient-to-br from-primary/5 to-accent/5 opacity-0 group-hover:opacity-100 transition-opacity duration-300" />

                  {/* Content */}
                  <div className="relative z-10">
                    {/* Icon with gradient */}
                    <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-primary/20 to-accent/20 flex items-center justify-center mb-4 group-hover:scale-110 transition-transform duration-300">
                      <BookOpen className="h-6 w-6 text-primary" />
                    </div>

                    {/* Title */}
                    <h3 className="text-lg font-semibold mb-2 group-hover:text-primary transition-colors">
                      {solution.title}
                    </h3>

                    {/* Summary */}
                    <p className="text-sm text-muted-foreground mb-4 line-clamp-3">
                      {solution.summary}
                    </p>

                    {/* Industries */}
                    <div className="flex flex-wrap gap-2 mb-4">
                      {solution.industries.slice(0, 2).map((industry) => (
                        <span
                          key={industry}
                          className="text-xs px-2 py-1 rounded-full bg-primary/10 text-primary border border-primary/20"
                        >
                          {industry}
                        </span>
                      ))}
                      {solution.industries.length > 2 && (
                        <span className="text-xs px-2 py-1 rounded-full bg-muted text-muted-foreground border">
                          +{solution.industries.length - 2}
                        </span>
                      )}
                    </div>

                    {/* APIs Used */}
                    <div className="text-xs font-medium text-muted-foreground mb-2">
                      {solution.apis.length} API{solution.apis.length !== 1 ? 's' : ''} used
                    </div>

                    {/* Hover Arrow */}
                    <div className="text-primary text-sm font-medium opacity-0 group-hover:opacity-100 transition-opacity flex items-center gap-1">
                      Learn More
                      <svg
                        className="w-4 h-4 group-hover:translate-x-1 transition-transform"
                        fill="none"
                        stroke="currentColor"
                        viewBox="0 0 24 24"
                      >
                        <path
                          strokeLinecap="round"
                          strokeLinejoin="round"
                          strokeWidth={2}
                          d="M9 5l7 7-7 7"
                        />
                      </svg>
                    </div>
                  </div>
                </a>
              );
            })}
          </div>

          {/* No Results */}
          {filteredSolutions.length === 0 && (
            <div className="text-center py-16">
              <p className="text-muted-foreground mb-4">
                No solutions found for {selectedIndustry}
              </p>
              <Button
                variant="outline"
                onClick={() => setSelectedIndustry('all')}
              >
                Clear Filter
              </Button>
            </div>
          )}
        </div>
      </section>

      {/* CTA Section */}
      <section className="w-full py-16 bg-muted/30">
        <div className="container px-4">
          <div className="max-w-3xl mx-auto text-center">
            <h2 className="text-3xl font-bold mb-4">
              Can't find what you're looking for?
            </h2>
            <p className="text-lg text-muted-foreground mb-8">
              Our solutions team can help you design a custom integration tailored to your specific business needs.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button asChild size="lg">
                <a href="/contact">
                  Contact Solutions Team
                </a>
              </Button>
              <Button asChild variant="outline" size="lg">
                <a href="/apis">
                  Browse All APIs
                </a>
              </Button>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
