import { useParams, useNavigate } from 'react-router-dom';
import { Code2, CheckCircle2, Globe, Lock, Zap, Book, ExternalLink, Copy, Check, Play, ChevronRight, Wallet, Shield, Layers, Plane, Key, ChevronDown, FileText } from 'lucide-react';
import { useState, useEffect, useRef } from 'react';
import { Button } from '../ui/button';
import { Badge } from '../ui/badge';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../ui/tabs';
import { Input } from '../ui/input';
import { Textarea } from '../ui/textarea';
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from '../ui/dropdown-menu';

import apisData from '@/data/apis.json';

interface API {
  id: string;
  name: string;
  slug: string;
  category: string;
  status: string;
  version: string;
  description: string;
  region: string;
  authentication: string;
  rateLimit: string;
  features: string[];
  useCases: string[];
}

const allAPIs: API[] = apisData;

interface NavSection {
  id: string;
  label: string;
  subsections?: { id: string; label: string }[];
}

const getNavSections = (apiName: string, endpoints: any[]): NavSection[] => {
  // Create subsections for individual endpoints
  const endpointSubsections = endpoints.map((endpoint, idx) => ({
    id: `endpoint-${idx}`,
    label: endpoint.description
  }));

  if (apiName === 'ACH Payments') {
    // Flat navigation structure for ACH Payments
    return [
      { id: 'overview', label: 'Overview' },
      { id: 'authentication-security', label: 'Authentication & Security' },
      { id: 'api-functions', label: 'API Functions' },
      { id: 'send-payments', label: 'Send Payments' },
      { id: 'collect-payments', label: 'Collect Payments' },
      { id: 'payment-status', label: 'Get Payment Status' },
      { id: 'use-cases', label: 'Common Use Cases' },
      { id: 'errors', label: 'Error Handling' },
    ];
  }

  // Default sections for other APIs
  return [
    { id: 'overview', label: 'Overview' },
    { id: 'authentication', label: 'Authentication' },
    { id: 'api-functions', label: 'API Functions', subsections: endpointSubsections },
    { id: 'quickstart', label: 'Quick Start' },
    { id: 'use-cases', label: 'Use Cases' },
    { id: 'errors', label: 'Error Handling' },
  ];
};

export function APIProductPage() {
  const { slug } = useParams<{ slug: string }>();
  const navigate = useNavigate();
  const [copiedEndpoint, setCopiedEndpoint] = useState<string | null>(null);
  const [activeSection, setActiveSection] = useState<string>('overview');
  const [selectedLanguage, setSelectedLanguage] = useState<string>('curl');
  const [selectedEndpoint, setSelectedEndpoint] = useState<number>(0);
  const [requestBody, setRequestBody] = useState<string>('{\n  "example": "payload"\n}');
  const [response, setResponse] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [endpointPositions, setEndpointPositions] = useState<number[]>([]);

  // Ref to track API Explorer block elements for height measurement
  const blockRefs = useRef<(HTMLDivElement | null)[]>([]);

  const api = allAPIs.find((a) => a.slug === slug);

  useEffect(() => {
    // Reset to overview when API changes
    setActiveSection('overview');

    // Small delay to ensure DOM is ready
    const timer = setTimeout(() => {
      // Set up intersection observer for section highlighting
      const observer = new IntersectionObserver(
        (entries) => {
          // Find all intersecting entries
          const intersectingEntries = entries.filter(entry => entry.isIntersecting);

          if (intersectingEntries.length === 0) return;

          // Sort by intersection ratio and vertical position
          intersectingEntries.sort((a, b) => {
            const aTop = a.boundingClientRect.top;
            const bTop = b.boundingClientRect.top;

            // Prioritize sections that are closest to the top of the viewport (but below the header)
            if (aTop >= 0 && bTop >= 0) {
              return aTop - bTop;
            }

            // If one is above viewport and one is below, choose the one below
            if (aTop < 0 && bTop >= 0) return 1;
            if (bTop < 0 && aTop >= 0) return -1;

            // Both above viewport, choose the one closest to 0
            return Math.abs(bTop) - Math.abs(aTop);
          });

          const topEntry = intersectingEntries[0];
          if (topEntry) {
            const sectionId = topEntry.target.id;
            setActiveSection(sectionId);
          }
        },
        {
          threshold: [0, 0.1, 0.25, 0.5, 0.75, 1],
          rootMargin: '-100px 0px -70% 0px'
        }
      );

      document.querySelectorAll('[data-section]').forEach((section) => {
        observer.observe(section);
      });

      return () => observer.disconnect();
    }, 100);

    return () => clearTimeout(timer);
  }, [api?.name]);

  // Calculate exact vertical positions of content sections for API Explorer alignment
  useEffect(() => {
    const calculatePositions = () => {
      const margins: number[] = [];
      const sectionIds = ['send-payments', 'collect-payments', 'payment-status'];

      // Get the main content container to use as reference point
      const mainContent = document.querySelector('main');
      if (!mainContent) return;

      const mainContentRect = mainContent.getBoundingClientRect();
      const mainContentTop = mainContentRect.top + window.pageYOffset;

      // Calculate absolute positions first
      const absolutePositions: number[] = [];
      sectionIds.forEach((sectionId) => {
        const section = document.getElementById(sectionId);
        if (section) {
          const rect = section.getBoundingClientRect();
          const absoluteTop = rect.top + window.pageYOffset;
          const relativePosition = absoluteTop - mainContentTop;
          absolutePositions.push(relativePosition);
        } else {
          absolutePositions.push(0);
        }
      });

      // Now calculate the margin needed for each block
      // considering that blocks are stacked in the DOM
      let cumulativeHeight = 0;
      absolutePositions.forEach((targetPosition, idx) => {
        if (idx === 0) {
          // First block: just use its target position as margin
          margins.push(targetPosition);
          cumulativeHeight = targetPosition;
        } else {
          // Subsequent blocks: target position minus cumulative height of all previous blocks
          // Measure the actual height of the previous block from the DOM
          const previousBlock = blockRefs.current[idx - 1];
          const actualBlockHeight = previousBlock ? previousBlock.offsetHeight : 600;
          cumulativeHeight += actualBlockHeight;
          const marginNeeded = targetPosition - cumulativeHeight;
          margins.push(Math.max(0, marginNeeded)); // Ensure non-negative
          cumulativeHeight += marginNeeded;
        }
      });

      setEndpointPositions(margins);
    };

    // Calculate on mount and after a small delay to ensure DOM is ready
    // Use longer delay when response changes to allow DOM to fully render
    const delay = response !== null ? 500 : 300;
    const timer = setTimeout(calculatePositions, delay);

    // Recalculate on window resize
    window.addEventListener('resize', calculatePositions);

    return () => {
      clearTimeout(timer);
      window.removeEventListener('resize', calculatePositions);
    };
  }, [api?.name, response, selectedEndpoint]);

  if (!api) {
    return (
      <div className="w-full py-16">
        <div className="container px-4">
          <div className="max-w-3xl mx-auto text-center">
            <h1 className="text-3xl font-bold mb-4">API Not Found</h1>
            <p className="text-muted-foreground mb-8">
              The API you're looking for doesn't exist.
            </p>
            <Button onClick={() => navigate('/apis')}>Back to API Catalog</Button>
          </div>
        </div>
      </div>
    );
  }

  const copyToClipboard = (text: string, endpoint: string) => {
    navigator.clipboard.writeText(text);
    setCopiedEndpoint(endpoint);
    setTimeout(() => setCopiedEndpoint(null), 2000);
  };

  const handleTryRequest = () => {
    setIsLoading(true);
    // Simulate API request
    setTimeout(() => {
      setResponse(JSON.stringify({
        success: true,
        message: "This is a simulated response",
        data: {
          id: "abc123",
          status: "completed",
          timestamp: new Date().toISOString()
        }
      }, null, 2));
      setIsLoading(false);
    }, 1000);
  };

  // Sample endpoints based on API type
  const getSampleEndpoints = (apiName: string) => {
    const baseUrl = 'https://api.example.com/v1';

    switch (apiName) {
      case 'Account Validation':
        return [
          { method: 'POST', path: '/validate/accounts', description: 'Validate up to 100 accounts' },
          { method: 'GET', path: '/validate/status/{requestId}', description: 'Get validation status' },
        ];
      case 'ACH Payments':
        return [
          {
            id: 'send-payments',
            method: 'POST',
            path: '/tpp/ach/payment-initiation/customer-credit-transfer-initiation',
            description: 'Send Payment Credit',
            summary: 'Initiate ACH credit transfer (PAIN.001)',
            fullDescription: 'TppACHExternalGenApi-SendPaymentCredit - receive PAIN001 (Credit) ISO JSON request as input and return PAIN002 ISO JSON as response after interacting with downstream Payment Rail System.'
          },
          {
            id: 'collect-payments',
            method: 'POST',
            path: '/tpp/ach/payment-initiation/customer-direct-debit-initiation',
            description: 'Send Payment Debit',
            summary: 'Initiate ACH debit transfer (PAIN.008)',
            fullDescription: 'TppACHExternalGenApi-SendPaymentDebit - send Payments. receive PAIN008 (Debit) ISO JSON request as input and return PAIN002 ISO JSON as response after interacting with downstream Payment Rail System.'
          },
          {
            id: 'payment-status',
            method: 'POST',
            path: '/tpp/ach/payment-initiation/get-transaction-status/get',
            description: 'Obtain Payment Status',
            summary: 'Get payment transaction status (CAMT.005)',
            fullDescription: 'TppACHExternalGenApi-ObtainPaymentStatus enquiry sends CAMT005 ISO JSON Request standard messages and enquires and responds back with PAIN002 ISO JSON message structure after querying matching backend.'
          },
        ];
      case 'EFT Payments':
        return [
          { method: 'POST', path: '/payments/credit', description: 'Initiate credit transfer' },
          { method: 'POST', path: '/payments/debit', description: 'Initiate debit transfer' },
          { method: 'GET', path: '/payments/{paymentId}', description: 'Get payment status' },
        ];
      case 'Wire Payments':
        return [
          { method: 'POST', path: '/payments/wire', description: 'Initiate wire transfer' },
          { method: 'GET', path: '/payments/wire/{paymentId}', description: 'Get wire status' },
        ];
      case 'Push Notifications':
        return [
          { method: 'POST', path: '/webhooks/register', description: 'Register webhook endpoint' },
          { method: 'GET', path: '/webhooks', description: 'List registered webhooks' },
          { method: 'DELETE', path: '/webhooks/{webhookId}', description: 'Delete webhook' },
        ];
      case 'Account Information':
        return [
          { method: 'GET', path: '/accounts/{accountId}/balance', description: 'Get account balance' },
          { method: 'GET', path: '/accounts/{accountId}/transactions', description: 'Get transaction history' },
        ];
      case 'Authorize & Token':
        return [
          { method: 'POST', path: '/oauth/authorize', description: 'Start OAuth flow' },
          { method: 'POST', path: '/oauth/token', description: 'Exchange code for token' },
          { method: 'POST', path: '/oauth/refresh', description: 'Refresh access token' },
        ];
      default:
        return [
          { method: 'GET', path: '/endpoint', description: 'Sample endpoint' },
        ];
    }
  };

  const sampleEndpoints = getSampleEndpoints(api.name);
  const navSections = getNavSections(api.name, sampleEndpoints);

  const getCodeSample = (language: string, endpointIdx: number) => {
    const endpoint = sampleEndpoints[endpointIdx];
    // Use correct base URL for ACH Payments API
    const baseUrl = api.name === 'ACH Payments'
      ? 'https://sandbox-open-api.bni.com/open-banking/commercial-sb'
      : 'https://api.example.com/v1';

    switch (language) {
      case 'curl':
        return `curl -X ${endpoint.method} ${baseUrl}${endpoint.path} \\
  -H "Authorization: Bearer YOUR_ACCESS_TOKEN" \\
  -H "Content-Type: application/json" \\
  -H "x-api-key: YOUR_API_KEY"${endpoint.method !== 'GET' ? ` \\
  -d '${requestBody}'` : ''}`;

      case 'python':
        return `import requests

url = "${baseUrl}${endpoint.path}"
headers = {
    "Authorization": "Bearer YOUR_ACCESS_TOKEN",
    "Content-Type": "application/json",
    "x-api-key": "YOUR_API_KEY"
}${endpoint.method !== 'GET' ? `
payload = ${requestBody}

response = requests.${endpoint.method.toLowerCase()}(url, json=payload, headers=headers)` : `

response = requests.${endpoint.method.toLowerCase()}(url, headers=headers)`}
print(response.json())`;

      case 'javascript':
        return `const response = await fetch('${baseUrl}${endpoint.path}', {
  method: '${endpoint.method}',
  headers: {
    'Authorization': 'Bearer YOUR_ACCESS_TOKEN',
    'Content-Type': 'application/json',
    'x-api-key': 'YOUR_API_KEY'
  }${endpoint.method !== 'GET' ? `,
  body: JSON.stringify(${requestBody})` : ''}
});

const data = await response.json();
console.log(data);`;

      case 'java':
        return `HttpClient client = HttpClient.newHttpClient();
HttpRequest request = HttpRequest.newBuilder()
    .uri(URI.create("${baseUrl}${endpoint.path}"))
    .header("Authorization", "Bearer YOUR_ACCESS_TOKEN")
    .header("Content-Type", "application/json")
    .header("x-api-key", "YOUR_API_KEY")${endpoint.method !== 'GET' ? `
    .${endpoint.method}(HttpRequest.BodyPublishers.ofString("""
        ${requestBody}
        """))` : `
    .GET()`}
    .build();

HttpResponse<String> response = client.send(request,
    HttpResponse.BodyHandlers.ofString());
System.out.println(response.body());`;

      default:
        return '';
    }
  };

  const scrollToSection = (sectionId: string) => {
    const element = document.getElementById(sectionId);
    if (element) {
      const headerHeight = 64; // Main header height
      const extraPadding = 20; // Additional padding
      const offset = headerHeight + extraPadding;
      const elementPosition = element.getBoundingClientRect().top;
      const offsetPosition = elementPosition + window.pageYOffset - offset;
      window.scrollTo({ top: offsetPosition, behavior: 'smooth' });
    }
  };

  return (
    <div className="w-full">
      {/* 3-Column Layout */}
      <div className="flex w-full">
        {/* Left Sidebar - Navigation */}
        <aside className="w-64 border-r bg-muted/20 sticky top-16 h-[calc(100vh-64px)] overflow-y-auto flex-shrink-0">
          <div className="p-6">
            <div className="mb-6">
              <div className="flex items-center gap-3 mb-2">
                <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-primary/20 to-accent/20 flex items-center justify-center">
                  <Code2 className="h-5 w-5 text-primary" />
                </div>
                <div>
                  <h3 className="font-semibold text-sm">{api.name}</h3>
                  <p className="text-xs text-muted-foreground">v{api.version}</p>
                </div>
              </div>
            </div>

            <nav className="space-y-1">
              {navSections.map((section) => (
                <button
                  key={section.id}
                  onClick={() => scrollToSection(section.id)}
                  className={`w-full text-left px-3 py-2 text-sm rounded-md transition-colors flex items-center justify-between ${
                    activeSection === section.id
                      ? 'bg-primary/10 text-primary font-medium'
                      : 'text-muted-foreground hover:bg-muted hover:text-foreground'
                  }`}
                >
                  {section.label}
                  {activeSection === section.id && <ChevronRight className="h-4 w-4" />}
                </button>
              ))}
            </nav>
          </div>
        </aside>

        {/* Center Content Area */}
        <main className="flex-1 overflow-y-auto">
          <div className="max-w-3xl mx-auto px-8 py-12">
            {/* Hero Section */}
            <section id="overview" data-section className="mb-16">
              <div className="mb-8">
                <div className="flex items-center justify-between mb-4">
                  <h1 className="text-4xl font-bold">{api.name}</h1>
                  <div className="flex gap-2">
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <Button variant="outline" size="sm" className="gap-2">
                          Copy page as MD
                          <ChevronDown className="h-4 w-4" />
                        </Button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent align="end">
                        <DropdownMenuItem onClick={() => {
                          // Copy markdown to clipboard
                          navigator.clipboard.writeText('# ' + api.name + '\n\nMarkdown content here...');
                        }}>
                          <Copy className="h-4 w-4 mr-2" />
                          Copy as Markdown
                        </DropdownMenuItem>
                        <DropdownMenuItem asChild>
                          <a href={`/api-docs/${api.slug}.md`} target="_blank" rel="noopener noreferrer">
                            <FileText className="h-4 w-4 mr-2" />
                            Get .md link
                          </a>
                        </DropdownMenuItem>
                      </DropdownMenuContent>
                    </DropdownMenu>
                    <Button variant="outline" size="sm" asChild>
                      <a href={`/api-docs/${api.slug}/swagger.json`} download={`${api.slug}-swagger.json`}>
                        <Code2 className="h-4 w-4 mr-2" />
                        Swagger Spec
                      </a>
                    </Button>
                  </div>
                </div>
                <p className="text-lg text-muted-foreground mb-6">{api.description}</p>

                <div className="flex flex-wrap gap-2 mb-6">
                  <Badge variant={api.status === 'Generally Available' ? 'default' : 'secondary'} className="gap-1">
                    {api.status === 'Generally Available' ? 'GA' : 'Upcoming'}
                  </Badge>
                  <Badge variant="outline">v{api.version}</Badge>
                  <Badge variant="outline" className="gap-1.5">
                    <Globe className="h-3 w-3" />
                    {api.region}
                  </Badge>
                  <Badge variant="outline" className="gap-1.5">
                    <Zap className="h-3 w-3" />
                    {api.rateLimit}
                  </Badge>
                </div>
              </div>

              {/* ACH Overview Details */}
              {api.name === 'ACH Payments' && (
                <div className="mb-8">
                  <div className="grid gap-6 md:grid-cols-2 mb-6">
                    <Card>
                      <CardHeader>
                        <CardTitle className="text-base">Limits</CardTitle>
                      </CardHeader>
                      <CardContent className="space-y-2 text-sm">
                        <div className="flex justify-between">
                          <span className="text-muted-foreground">Per Payment</span>
                          <span className="font-medium">$99,999,999</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-muted-foreground">Per Call</span>
                          <span className="font-medium">200 payments (same type)</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-muted-foreground">Scheduling</span>
                          <span className="font-medium">Up to 60 days in advance</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-muted-foreground">API Calls</span>
                          <span className="font-medium">Unlimited</span>
                        </div>
                      </CardContent>
                    </Card>

                    <Card>
                      <CardHeader>
                        <CardTitle className="text-base">Countries & Speed</CardTitle>
                      </CardHeader>
                      <CardContent className="space-y-2 text-sm">
                        <div className="flex justify-between">
                          <span className="text-muted-foreground">Countries</span>
                          <span className="font-medium">U.S., Mexico, Panama</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-muted-foreground">Currency</span>
                          <span className="font-medium">USD only</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-muted-foreground">Same Day</span>
                          <span className="font-medium">Until 2 p.m. CT (U.S.)</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-muted-foreground">Standard</span>
                          <span className="font-medium">2 business days</span>
                        </div>
                      </CardContent>
                    </Card>
                  </div>

                  <Card>
                    <CardHeader>
                      <CardTitle className="text-base">Cut-off Times (Business Days)</CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-3 text-sm">
                      <div>
                        <div className="font-medium mb-1">Same-day ACH payments</div>
                        <div className="text-muted-foreground">2:00 p.m. CT</div>
                      </div>
                      <div className="border-t pt-3">
                        <div className="font-medium mb-1">Standard ACH and IAT payments</div>
                        <div className="text-muted-foreground">8:00 p.m. CT</div>
                      </div>
                    </CardContent>
                  </Card>

                  {/* Key Features for ACH - Merged from A Closer Look */}
                  <div className="mt-8">
                    <h2 className="text-2xl font-bold mb-4 flex items-center gap-2">
                      <CheckCircle2 className="h-6 w-6 text-primary" />
                      Key Features
                    </h2>
                    <div className="space-y-3">
                      <div className="flex items-start gap-3 p-3 rounded-lg bg-muted/50">
                        <CheckCircle2 className="h-5 w-5 text-primary mt-0.5 shrink-0" />
                        <div>
                          <h3 className="font-semibold mb-1">Cost-efficient bulk payments</h3>
                          <p className="text-sm text-muted-foreground">
                            You can bundle up to 200 payments in a single call and save. Batched payments must be of the same type.
                          </p>
                        </div>
                      </div>

                      <div className="flex items-start gap-3 p-3 rounded-lg bg-muted/50">
                        <CheckCircle2 className="h-5 w-5 text-primary mt-0.5 shrink-0" />
                        <div>
                          <h3 className="font-semibold mb-1">Send now or later</h3>
                          <p className="text-sm text-muted-foreground">
                            You can send same-day payments or schedule them up to 60 days in advance. Bulk payments can have a mix of processing dates.
                          </p>
                        </div>
                      </div>

                      <div className="flex items-start gap-3 p-3 rounded-lg bg-muted/50">
                        <CheckCircle2 className="h-5 w-5 text-primary mt-0.5 shrink-0" />
                        <div>
                          <h3 className="font-semibold mb-1">Separate processing</h3>
                          <p className="text-sm text-muted-foreground">
                            Payments sent or collected don't appear in Online Banking for Business and cannot be modified once submitted. However, deletions and reversals are available in ACH Fraud Control.
                          </p>
                        </div>
                      </div>

                      <div className="flex items-start gap-3 p-3 rounded-lg bg-muted/50">
                        <CheckCircle2 className="h-5 w-5 text-primary mt-0.5 shrink-0" />
                        <div>
                          <h3 className="font-semibold mb-1">Real-time tracking</h3>
                          <p className="text-sm text-muted-foreground">
                            Request on-demand status updates for your created payments or get automatic alerts by API, email or text message using our Push Notifications API. Payments are tracked up until the time they leave BNI, but potential issues at the other bank are also covered.
                          </p>
                        </div>
                      </div>

                      <div className="flex items-start gap-3 p-3 rounded-lg bg-muted/50">
                        <CheckCircle2 className="h-5 w-5 text-primary mt-0.5 shrink-0" />
                        <div>
                          <h3 className="font-semibold mb-1">Easy reconciliation</h3>
                          <p className="text-sm text-muted-foreground">
                            You can subscribe to an automatic end-of-day report showing individual transactions that were offset by a consolidated PEP+ Generated settlement entry. This allows you to easily reconcile ACH settlements with their individual ACH entries.
                          </p>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              )}

              {/* Key Features - Only for non-ACH APIs */}
              {api.name !== 'ACH Payments' && (
                <div>
                  <h2 className="text-2xl font-bold mb-4 flex items-center gap-2">
                    <CheckCircle2 className="h-6 w-6 text-primary" />
                    Key Features
                  </h2>
                  <div className="space-y-3">
                    {api.features.map((feature, idx) => (
                      <div key={idx} className="flex items-start gap-3 p-3 rounded-lg bg-muted/50">
                        <CheckCircle2 className="h-5 w-5 text-primary mt-0.5 shrink-0" />
                        <p className="text-sm">{feature}</p>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </section>

            {/* Authentication & Security Section */}
            <section id="authentication-security" data-section className="mb-16">
              <h2 className="text-2xl font-bold mb-4 flex items-center gap-2">
                <Lock className="h-6 w-6 text-primary" />
                Authentication & Security
              </h2>

              {/* Authentication */}
              <div className="prose prose-sm max-w-none mb-8">
                <h3 className="text-lg font-semibold mb-3">Authentication</h3>
                <p className="text-muted-foreground mb-4">
                  This API uses <strong>{api.authentication}</strong> for authentication.
                  All requests must include valid credentials in the request headers.
                </p>
                <div className="bg-muted/50 border-l-4 border-primary p-4 rounded-r-lg">
                  <h4 className="font-semibold mb-2">Required Headers</h4>
                  <ul className="space-y-2 text-sm">
                    <li><code className="px-2 py-1 bg-muted rounded">Authorization: Bearer YOUR_ACCESS_TOKEN</code></li>
                    <li><code className="px-2 py-1 bg-muted rounded">x-api-key: YOUR_API_KEY</code></li>
                    <li><code className="px-2 py-1 bg-muted rounded">Content-Type: application/json</code></li>
                  </ul>
                </div>
              </div>

              {/* Payload Encryption - Only for ACH Payments */}
              {api.name === 'ACH Payments' && (
                <div className="prose prose-sm max-w-none">
                  <h3 className="text-lg font-semibold mb-3">Payload Encryption</h3>
                  <div className="bg-yellow-500/10 border-l-4 border-yellow-500 p-6 rounded-r-lg">
                    <p className="text-sm mb-3">
                      For security reasons, all requests to and responses from our Payments APIs need to be encrypted. For detailed instructions, have a look at our encryption process.
                    </p>
                    <Button variant="outline" size="sm" asChild>
                      <a href="/apis/encryption-key">
                        View Encryption Documentation
                        <ExternalLink className="h-3 w-3 ml-2" />
                      </a>
                    </Button>
                  </div>
                </div>
              )}
            </section>

            {/* ACH Payments Specific Sections */}
            {api.name === 'ACH Payments' && (
              <>
                {/* API Functions Section - Parent */}
                <section id="api-functions" data-section className="mb-16">
                  <h2 className="text-2xl font-bold mb-6">API Functions</h2>
                  <p className="text-muted-foreground mb-6">
                    The ACH Payments API provides three core functions to manage payment workflows: sending payments, collecting payments, and checking payment status. Each function supports bulk operations and encryption for secure processing.
                  </p>
                  <div className="grid gap-4">
                    {sampleEndpoints.map((endpoint, idx) => (
                      <button
                        key={idx}
                        onClick={() => scrollToSection(idx === 0 ? 'send-payments' : idx === 1 ? 'collect-payments' : 'payment-status')}
                        className="flex items-center justify-between p-4 border rounded-lg hover:border-primary/50 hover:bg-muted/30 transition-colors text-left"
                      >
                        <div className="flex items-center gap-3">
                          <Badge
                            variant={endpoint.method === 'GET' ? 'secondary' : 'default'}
                            className="font-mono"
                          >
                            {endpoint.method}
                          </Badge>
                          <div>
                            <code className="text-sm font-mono block mb-1">{endpoint.path}</code>
                            <p className="text-xs text-muted-foreground">{endpoint.description}</p>
                          </div>
                        </div>
                        <ChevronRight className="h-5 w-5 text-muted-foreground" />
                      </button>
                    ))}
                  </div>
                </section>

                {/* Send Payments Section with Endpoint Details */}
                <section id="send-payments" data-section className="mb-16">
                  <h2 className="text-2xl font-bold mb-4">Send Payments</h2>

                  {/* Guide Content */}
                  <div className="prose prose-sm max-w-none mb-8">
                    <p className="text-muted-foreground mb-4">
                      To reduce the number of necessary calls, you can submit a batch of up to 200 payments within the same call. They must be of the same type (ACH credits or IAT credits), but you can mix current and scheduled payments (up to 60 days in the future).
                    </p>
                    <p className="text-muted-foreground mb-4">
                      Create your payments (Pain.001) by providing the type and all mandatory details as outlined in the Specifications document at the top. As a best practice, we recommend first sending a $0 prenote transaction and confirming a successful payment status before sending the actual amount. Our API supports both $0 prenotes and microdeposits of less than $1, but they need to be submitted as independent transactions. For added certainty, we also recommend the use of our Account Validation API.
                    </p>
                    <p className="text-muted-foreground mb-4">
                      Once submitted, we'll validate your payments and respond with the results (Pain.002). If there are no issues, we'll process your payments. No approvals are required.
                    </p>
                    <div className="bg-muted/50 border-l-4 border-primary p-4 rounded-r-lg">
                      <p className="text-sm">
                        <strong>Note:</strong> Payments don't appear in Online Banking for Business and cannot be modified once submitted. However, deletions and reversals are available in ACH Fraud Control.
                      </p>
                    </div>
                  </div>

                  {/* Endpoint Technical Details */}
                  <div className="space-y-6">
                    <div>
                      <div className="flex items-center gap-3 mb-4">
                        <Badge variant="default" className="font-mono text-base px-3 py-1">POST</Badge>
                        <code className="text-base font-mono font-semibold">{sampleEndpoints[0].path}</code>
                      </div>
                      <h4 className="font-semibold mb-2">Description</h4>
                      <p className="text-sm text-muted-foreground">{sampleEndpoints[0].fullDescription}</p>
                    </div>

                      <div>
                        <h4 className="font-semibold mb-3">Request Headers</h4>
                        <div className="border rounded-lg overflow-hidden">
                          <table className="w-full text-sm">
                            <thead className="bg-muted">
                              <tr>
                                <th className="text-left p-3 font-semibold">Header Name</th>
                                <th className="text-left p-3 font-semibold">Type</th>
                                <th className="text-left p-3 font-semibold">Required</th>
                                <th className="text-left p-3 font-semibold">Description</th>
                              </tr>
                            </thead>
                            <tbody className="divide-y">
                              <tr>
                                <td className="p-3"><code className="text-xs">x-fapi-interaction-id</code></td>
                                <td className="p-3"><code className="text-xs">string</code></td>
                                <td className="p-3"><Badge variant="destructive" className="text-xs">Required</Badge></td>
                                <td className="p-3 text-muted-foreground">Unique interaction ID to track the request</td>
                              </tr>
                              <tr>
                                <td className="p-3"><code className="text-xs">x-request-id</code></td>
                                <td className="p-3"><code className="text-xs">string</code></td>
                                <td className="p-3"><Badge variant="destructive" className="text-xs">Required</Badge></td>
                                <td className="p-3 text-muted-foreground">Correlates HTTP requests between client and server</td>
                              </tr>
                              <tr>
                                <td className="p-3"><code className="text-xs">x-crypto-key</code></td>
                                <td className="p-3"><code className="text-xs">string</code></td>
                                <td className="p-3"><Badge variant="outline" className="text-xs">Optional</Badge></td>
                                <td className="p-3 text-muted-foreground">Crypto key for payload decryption</td>
                              </tr>
                              <tr>
                                <td className="p-3"><code className="text-xs">x-fapi-financial-id</code></td>
                                <td className="p-3"><code className="text-xs">string</code></td>
                                <td className="p-3"><Badge variant="outline" className="text-xs">Optional</Badge></td>
                                <td className="p-3 text-muted-foreground">Unique ID of the financial institution (001 for BNI)</td>
                              </tr>
                              <tr>
                                <td className="p-3"><code className="text-xs">x-api-key</code></td>
                                <td className="p-3"><code className="text-xs">string</code></td>
                                <td className="p-3"><Badge variant="outline" className="text-xs">Optional</Badge></td>
                                <td className="p-3 text-muted-foreground">Unique ID used to identify caller of the API</td>
                              </tr>
                            </tbody>
                          </table>
                        </div>
                      </div>

                      <div>
                        <h4 className="font-semibold mb-3">Request Body</h4>
                        <div className="bg-muted/50 border-l-4 border-primary p-4 rounded-r-lg">
                          <p className="text-sm text-muted-foreground mb-3">
                            <strong>SECURE</strong> object containing encrypted ISO message:
                          </p>
                          <ul className="space-y-2 text-sm">
                            <li className="flex items-start gap-2">
                              <code className="px-2 py-1 bg-muted rounded text-xs">encrypted</code>
                              <span className="text-muted-foreground">(boolean) - Set to true when dealing with data encryption</span>
                            </li>
                            <li className="flex items-start gap-2">
                              <code className="px-2 py-1 bg-muted rounded text-xs">data</code>
                              <span className="text-muted-foreground">(string) - Base64url encoded cipher-text containing encrypted PAIN.001 payload</span>
                            </li>
                          </ul>
                        </div>
                      </div>

                      <div>
                        <h4 className="font-semibold mb-3">Response</h4>
                        <div className="space-y-3">
                          <div className="border-l-4 border-green-500 bg-green-500/10 p-4 rounded-r-lg">
                            <div className="flex items-center justify-between mb-2">
                              <code className="font-semibold">200 OK</code>
                              <Badge variant="outline" className="text-xs">Success</Badge>
                            </div>
                            <p className="text-sm text-muted-foreground">Payment successfully submitted (PAIN.002)</p>
                          </div>
                          <div className="border-l-4 border-yellow-500 bg-yellow-500/10 p-4 rounded-r-lg">
                            <div className="flex items-center justify-between mb-2">
                              <code className="font-semibold">400 Bad Request</code>
                              <Badge variant="outline" className="text-xs">Error</Badge>
                            </div>
                            <p className="text-sm text-muted-foreground">Invalid request parameters or payload</p>
                          </div>
                          <div className="border-l-4 border-red-500 bg-red-500/10 p-4 rounded-r-lg">
                            <div className="flex items-center justify-between mb-2">
                              <code className="font-semibold">401 Unauthorized</code>
                              <Badge variant="outline" className="text-xs">Error</Badge>
                            </div>
                            <p className="text-sm text-muted-foreground">Authentication failed or missing credentials</p>
                          </div>
                        </div>
                      </div>
                    </div>
                </section>

                {/* Collect Payments Section with Endpoint Details */}
                <section id="collect-payments" data-section className="mb-16">
                  <h2 className="text-2xl font-bold mb-4">Collect Payments</h2>

                  {/* Guide Content */}
                  <div className="prose prose-sm max-w-none mb-8">
                    <p className="text-muted-foreground mb-4">
                      You can also collect payments in bulk to reduce the number of necessary calls. You can bundle up to 200 payments in a single batch as long as they are of the same type (ACH debits or IAT debits), but you can mix current and scheduled payments (up to 60 days in the future).
                    </p>
                    <p className="text-muted-foreground mb-4">
                      Create your payments (Pain.008) by providing the type and all mandatory details as outlined in the Specifications document at the top. It's required to first submitting a $0 prenote transaction and confirming a successful payment status before collecting the actual amount. Our API supports both $0 prenotes and microdeposits of less than $1, but they need to be submitted as independent transactions. For added certainty, we also recommend the use of our Account Validation API.
                    </p>
                    <p className="text-muted-foreground mb-4">
                      Once submitted, we'll validate your payments and respond with the results (Pain.002). If there are no issues, we'll process your payments. No approvals are required.
                    </p>
                    <div className="bg-muted/50 border-l-4 border-primary p-4 rounded-r-lg">
                      <p className="text-sm">
                        <strong>Note:</strong> Payments don't appear in Online Banking for Business and cannot be modified once submitted. However, deletions and reversals are available in ACH Fraud Control.
                      </p>
                    </div>
                  </div>

                  {/* Endpoint Technical Details */}
                  <div className="space-y-6">
                    <div>
                      <div className="flex items-center gap-3 mb-4">
                        <Badge variant="default" className="font-mono text-base px-3 py-1">POST</Badge>
                        <code className="text-base font-mono font-semibold">{sampleEndpoints[1].path}</code>
                      </div>
                      <h4 className="font-semibold mb-2">Description</h4>
                      <p className="text-sm text-muted-foreground">{sampleEndpoints[1].fullDescription}</p>
                    </div>

                      <div>
                        <h4 className="font-semibold mb-3">Request Headers</h4>
                        <div className="border rounded-lg overflow-hidden">
                          <table className="w-full text-sm">
                            <thead className="bg-muted">
                              <tr>
                                <th className="text-left p-3 font-semibold">Header Name</th>
                                <th className="text-left p-3 font-semibold">Type</th>
                                <th className="text-left p-3 font-semibold">Required</th>
                                <th className="text-left p-3 font-semibold">Description</th>
                              </tr>
                            </thead>
                            <tbody className="divide-y">
                              <tr>
                                <td className="p-3"><code className="text-xs">x-fapi-interaction-id</code></td>
                                <td className="p-3"><code className="text-xs">string</code></td>
                                <td className="p-3"><Badge variant="destructive" className="text-xs">Required</Badge></td>
                                <td className="p-3 text-muted-foreground">Unique interaction ID to track the request</td>
                              </tr>
                              <tr>
                                <td className="p-3"><code className="text-xs">x-request-id</code></td>
                                <td className="p-3"><code className="text-xs">string</code></td>
                                <td className="p-3"><Badge variant="destructive" className="text-xs">Required</Badge></td>
                                <td className="p-3 text-muted-foreground">Correlates HTTP requests between client and server</td>
                              </tr>
                              <tr>
                                <td className="p-3"><code className="text-xs">x-crypto-key</code></td>
                                <td className="p-3"><code className="text-xs">string</code></td>
                                <td className="p-3"><Badge variant="outline" className="text-xs">Optional</Badge></td>
                                <td className="p-3 text-muted-foreground">Crypto key for payload decryption</td>
                              </tr>
                              <tr>
                                <td className="p-3"><code className="text-xs">x-fapi-financial-id</code></td>
                                <td className="p-3"><code className="text-xs">string</code></td>
                                <td className="p-3"><Badge variant="outline" className="text-xs">Optional</Badge></td>
                                <td className="p-3 text-muted-foreground">Unique ID of the financial institution (001 for BNI)</td>
                              </tr>
                              <tr>
                                <td className="p-3"><code className="text-xs">x-api-key</code></td>
                                <td className="p-3"><code className="text-xs">string</code></td>
                                <td className="p-3"><Badge variant="outline" className="text-xs">Optional</Badge></td>
                                <td className="p-3 text-muted-foreground">Unique ID used to identify caller of the API</td>
                              </tr>
                            </tbody>
                          </table>
                        </div>
                      </div>

                      <div>
                        <h4 className="font-semibold mb-3">Request Body</h4>
                        <div className="bg-muted/50 border-l-4 border-primary p-4 rounded-r-lg">
                          <p className="text-sm text-muted-foreground mb-3">
                            <strong>SECURE</strong> object containing encrypted ISO message:
                          </p>
                          <ul className="space-y-2 text-sm">
                            <li className="flex items-start gap-2">
                              <code className="px-2 py-1 bg-muted rounded text-xs">encrypted</code>
                              <span className="text-muted-foreground">(boolean) - Set to true when dealing with data encryption</span>
                            </li>
                            <li className="flex items-start gap-2">
                              <code className="px-2 py-1 bg-muted rounded text-xs">data</code>
                              <span className="text-muted-foreground">(string) - Base64url encoded cipher-text containing encrypted PAIN.008 payload</span>
                            </li>
                          </ul>
                        </div>
                      </div>

                      <div>
                        <h4 className="font-semibold mb-3">Response</h4>
                        <div className="space-y-3">
                          <div className="border-l-4 border-green-500 bg-green-500/10 p-4 rounded-r-lg">
                            <div className="flex items-center justify-between mb-2">
                              <code className="font-semibold">200 OK</code>
                              <Badge variant="outline" className="text-xs">Success</Badge>
                            </div>
                            <p className="text-sm text-muted-foreground">Payment successfully submitted (PAIN.002)</p>
                          </div>
                          <div className="border-l-4 border-yellow-500 bg-yellow-500/10 p-4 rounded-r-lg">
                            <div className="flex items-center justify-between mb-2">
                              <code className="font-semibold">400 Bad Request</code>
                              <Badge variant="outline" className="text-xs">Error</Badge>
                            </div>
                            <p className="text-sm text-muted-foreground">Invalid request parameters or payload</p>
                          </div>
                          <div className="border-l-4 border-red-500 bg-red-500/10 p-4 rounded-r-lg">
                            <div className="flex items-center justify-between mb-2">
                              <code className="font-semibold">401 Unauthorized</code>
                              <Badge variant="outline" className="text-xs">Error</Badge>
                            </div>
                            <p className="text-sm text-muted-foreground">Authentication failed or missing credentials</p>
                          </div>
                        </div>
                      </div>
                    </div>
                </section>

                {/* Get Payment Status Section with Endpoint Details */}
                <section id="payment-status" data-section className="mb-16">
                  <h2 className="text-2xl font-bold mb-4">Get Payment Status</h2>

                  {/* Guide Content */}
                  <div className="prose prose-sm max-w-none mb-8">
                    <p className="text-muted-foreground mb-4">
                      Check the latest status for your sent payments (CAMT.005). This call returns the current status of a particular payment batch (Pain.002) up until it leaves BNI. Please check our table below for more information about the possible statuses that can be returned.
                    </p>
                    <div className="bg-muted/50 border-l-4 border-primary p-4 rounded-r-lg">
                      <p className="text-sm">
                        <strong>Note:</strong> Instead of checking manually, you can also request automatic alerts by API Webhook, email or text message using our Push Notifications API.
                      </p>
                    </div>
                  </div>

                  {/* Endpoint Technical Details */}
                  <div className="space-y-6">
                    <div>
                      <div className="flex items-center gap-3 mb-4">
                        <Badge variant="default" className="font-mono text-base px-3 py-1">POST</Badge>
                        <code className="text-base font-mono font-semibold">{sampleEndpoints[2].path}</code>
                      </div>
                      <h4 className="font-semibold mb-2">Description</h4>
                      <p className="text-sm text-muted-foreground">{sampleEndpoints[2].fullDescription}</p>
                    </div>

                      <div>
                        <h4 className="font-semibold mb-3">Request Headers</h4>
                        <div className="border rounded-lg overflow-hidden">
                          <table className="w-full text-sm">
                            <thead className="bg-muted">
                              <tr>
                                <th className="text-left p-3 font-semibold">Header Name</th>
                                <th className="text-left p-3 font-semibold">Type</th>
                                <th className="text-left p-3 font-semibold">Required</th>
                                <th className="text-left p-3 font-semibold">Description</th>
                              </tr>
                            </thead>
                            <tbody className="divide-y">
                              <tr>
                                <td className="p-3"><code className="text-xs">x-fapi-interaction-id</code></td>
                                <td className="p-3"><code className="text-xs">string</code></td>
                                <td className="p-3"><Badge variant="destructive" className="text-xs">Required</Badge></td>
                                <td className="p-3 text-muted-foreground">Unique interaction ID to track the request</td>
                              </tr>
                              <tr>
                                <td className="p-3"><code className="text-xs">x-request-id</code></td>
                                <td className="p-3"><code className="text-xs">string</code></td>
                                <td className="p-3"><Badge variant="destructive" className="text-xs">Required</Badge></td>
                                <td className="p-3 text-muted-foreground">Correlates HTTP requests between client and server</td>
                              </tr>
                              <tr>
                                <td className="p-3"><code className="text-xs">x-crypto-key</code></td>
                                <td className="p-3"><code className="text-xs">string</code></td>
                                <td className="p-3"><Badge variant="outline" className="text-xs">Optional</Badge></td>
                                <td className="p-3 text-muted-foreground">Crypto key for payload decryption</td>
                              </tr>
                              <tr>
                                <td className="p-3"><code className="text-xs">x-fapi-financial-id</code></td>
                                <td className="p-3"><code className="text-xs">string</code></td>
                                <td className="p-3"><Badge variant="outline" className="text-xs">Optional</Badge></td>
                                <td className="p-3 text-muted-foreground">Unique ID of the financial institution (001 for BNI)</td>
                              </tr>
                              <tr>
                                <td className="p-3"><code className="text-xs">x-api-key</code></td>
                                <td className="p-3"><code className="text-xs">string</code></td>
                                <td className="p-3"><Badge variant="outline" className="text-xs">Optional</Badge></td>
                                <td className="p-3 text-muted-foreground">Unique ID used to identify caller of the API</td>
                              </tr>
                            </tbody>
                          </table>
                        </div>
                      </div>

                      <div>
                        <h4 className="font-semibold mb-3">Request Body</h4>
                        <div className="bg-muted/50 border-l-4 border-primary p-4 rounded-r-lg">
                          <p className="text-sm text-muted-foreground mb-3">
                            <strong>SECURE</strong> object containing encrypted ISO message:
                          </p>
                          <ul className="space-y-2 text-sm">
                            <li className="flex items-start gap-2">
                              <code className="px-2 py-1 bg-muted rounded text-xs">encrypted</code>
                              <span className="text-muted-foreground">(boolean) - Set to true when dealing with data encryption</span>
                            </li>
                            <li className="flex items-start gap-2">
                              <code className="px-2 py-1 bg-muted rounded text-xs">data</code>
                              <span className="text-muted-foreground">(string) - Base64url encoded cipher-text containing encrypted CAMT.005 payload</span>
                            </li>
                          </ul>
                        </div>
                      </div>

                      <div>
                        <h4 className="font-semibold mb-3">Response</h4>
                        <div className="space-y-3">
                          <div className="border-l-4 border-green-500 bg-green-500/10 p-4 rounded-r-lg">
                            <div className="flex items-center justify-between mb-2">
                              <code className="font-semibold">200 OK</code>
                              <Badge variant="outline" className="text-xs">Success</Badge>
                            </div>
                            <p className="text-sm text-muted-foreground">Status inquiry successful (PAIN.002)</p>
                          </div>
                          <div className="border-l-4 border-yellow-500 bg-yellow-500/10 p-4 rounded-r-lg">
                            <div className="flex items-center justify-between mb-2">
                              <code className="font-semibold">400 Bad Request</code>
                              <Badge variant="outline" className="text-xs">Error</Badge>
                            </div>
                            <p className="text-sm text-muted-foreground">Invalid request parameters or payload</p>
                          </div>
                          <div className="border-l-4 border-red-500 bg-red-500/10 p-4 rounded-r-lg">
                            <div className="flex items-center justify-between mb-2">
                              <code className="font-semibold">401 Unauthorized</code>
                              <Badge variant="outline" className="text-xs">Error</Badge>
                            </div>
                            <p className="text-sm text-muted-foreground">Authentication failed or missing credentials</p>
                          </div>
                        </div>
                      </div>
                    </div>
                </section>

                {/* Common Use Cases Section for ACH */}
                <section id="use-cases" data-section className="mb-16">
                  <h2 className="text-2xl font-bold mb-6">Common Use Cases</h2>
                  <p className="text-muted-foreground mb-6">
                    The ACH Payments API powers multiple business solutions across various industries. Explore these complete implementations to see how organizations leverage ACH payments for their workflows.
                  </p>
                  <div className="space-y-4">
                    <a
                      href="/solutions/automated-north-american-payables"
                      className="block transition-all hover:scale-[1.02]"
                    >
                      <Card className="cursor-pointer border-2 hover:border-primary/50 hover:shadow-lg transition-all">
                        <CardHeader>
                          <CardTitle className="text-lg flex items-center gap-3">
                            <div className="p-2 rounded-lg bg-primary/10">
                              <Wallet className="h-5 w-5 text-primary" />
                            </div>
                            Automated North American Payables (US & Canada)
                          </CardTitle>
                        </CardHeader>
                        <CardContent>
                          <p className="text-sm text-muted-foreground">
                            Build a unified payables workflow that validates beneficiaries, initiates ACH/EFT/wire payments, and receives real-time payment status notifications across US and Canadian markets.
                          </p>
                        </CardContent>
                      </Card>
                    </a>

                    <a
                      href="/solutions/vendor-onboarding-validation"
                      className="block transition-all hover:scale-[1.02]"
                    >
                      <Card className="cursor-pointer border-2 hover:border-primary/50 hover:shadow-lg transition-all">
                        <CardHeader>
                          <CardTitle className="text-lg flex items-center gap-3">
                            <div className="p-2 rounded-lg bg-primary/10">
                              <Shield className="h-5 w-5 text-primary" />
                            </div>
                            Vendor Onboarding & Compliance-First Account Validation
                          </CardTitle>
                        </CardHeader>
                        <CardContent>
                          <p className="text-sm text-muted-foreground">
                            Validate vendor account ownership and assess risk before initiating the first payment, reducing fraud, returns, and compliance issues.
                          </p>
                        </CardContent>
                      </Card>
                    </a>

                    <a
                      href="/solutions/embedded-erp-banking"
                      className="block transition-all hover:scale-[1.02]"
                    >
                      <Card className="cursor-pointer border-2 hover:border-primary/50 hover:shadow-lg transition-all">
                        <CardHeader>
                          <CardTitle className="text-lg flex items-center gap-3">
                            <div className="p-2 rounded-lg bg-primary/10">
                              <Layers className="h-5 w-5 text-primary" />
                            </div>
                            Embedded Banking in ERP Systems
                          </CardTitle>
                        </CardHeader>
                        <CardContent>
                          <p className="text-sm text-muted-foreground">
                            Integrate payment initiation, reconciliation, and balance visibility directly into ERP workflows, eliminating portal switching and manual data entry.
                          </p>
                        </CardContent>
                      </Card>
                    </a>

                    <a
                      href="/solutions/cross-border-payments"
                      className="block transition-all hover:scale-[1.02]"
                    >
                      <Card className="cursor-pointer border-2 hover:border-primary/50 hover:shadow-lg transition-all">
                        <CardHeader>
                          <CardTitle className="text-lg flex items-center gap-3">
                            <div className="p-2 rounded-lg bg-primary/10">
                              <Plane className="h-5 w-5 text-primary" />
                            </div>
                            Cross-Border Supplier Payments (ACH + Wire)
                          </CardTitle>
                        </CardHeader>
                        <CardContent>
                          <p className="text-sm text-muted-foreground">
                            Provide a unified cross-border payment pipeline with trackable status for international supplier payments, combining ACH and wire transfer capabilities.
                          </p>
                        </CardContent>
                      </Card>
                    </a>

                    <a
                      href="/solutions/oauth-corporate-data-access"
                      className="block transition-all hover:scale-[1.02]"
                    >
                      <Card className="cursor-pointer border-2 hover:border-primary/50 hover:shadow-lg transition-all">
                        <CardHeader>
                          <CardTitle className="text-lg flex items-center gap-3">
                            <div className="p-2 rounded-lg bg-primary/10">
                              <Key className="h-5 w-5 text-primary" />
                            </div>
                            OAuth-Based Corporate Data Access (Open Banking Style)
                          </CardTitle>
                        </CardHeader>
                        <CardContent>
                          <p className="text-sm text-muted-foreground">
                            Enable third-party platforms or internal systems to access corporate accounts securely via delegated OAuth authorization, reducing credential sharing risks.
                          </p>
                        </CardContent>
                      </Card>
                    </a>
                  </div>
                </section>
              </>
            )}

            {/* API Functions Section - Only for non-ACH APIs */}
            {api.name !== 'ACH Payments' && (
              <>
                <section id="api-functions" data-section className="mb-16">
                  <h2 className="text-2xl font-bold mb-6">API Functions</h2>
                  <p className="text-muted-foreground mb-6">
                    This API provides the following endpoints for integration. Click on any endpoint below to view detailed information, request/response schemas, and interactive examples.
                  </p>
                  <div className="grid gap-4">
                    {sampleEndpoints.map((endpoint, idx) => (
                      <button
                        key={idx}
                        onClick={() => scrollToSection(`endpoint-${idx}`)}
                        className="flex items-center justify-between p-4 border rounded-lg hover:border-primary/50 hover:bg-muted/30 transition-colors text-left"
                      >
                        <div className="flex items-center gap-3">
                          <Badge
                            variant={endpoint.method === 'GET' ? 'secondary' : 'default'}
                            className="font-mono"
                          >
                            {endpoint.method}
                          </Badge>
                          <div>
                            <code className="text-sm font-mono block mb-1">{endpoint.path}</code>
                            <p className="text-xs text-muted-foreground">{endpoint.description}</p>
                          </div>
                        </div>
                        <ChevronRight className="h-5 w-5 text-muted-foreground" />
                      </button>
                    ))}
                  </div>
                </section>

                {/* Individual Endpoint Sections */}
                {sampleEndpoints.map((endpoint, idx) => (
                  <section key={idx} id={`endpoint-${idx}`} data-section className="mb-16">
                    <div className="flex items-start justify-between mb-6">
                      <div>
                        <div className="flex items-center gap-3 mb-3">
                          <Badge
                            variant={endpoint.method === 'GET' ? 'secondary' : 'default'}
                            className="font-mono text-base px-3 py-1"
                          >
                            {endpoint.method}
                          </Badge>
                          <code className="text-lg font-mono">{endpoint.path}</code>
                        </div>
                        <h3 className="text-2xl font-bold">{endpoint.description}</h3>
                      </div>
                      <Button
                        onClick={() => {
                          setSelectedEndpoint(idx);
                          window.scrollTo({ top: 0, behavior: 'smooth' });
                        }}
                        className="gap-2"
                      >
                        <Play className="h-4 w-4" />
                        Try It
                      </Button>
                    </div>

                    <div className="space-y-6">
                      {/* Description */}
                      <div>
                        <h4 className="font-semibold mb-2">Description</h4>
                        <p className="text-sm text-muted-foreground">
                          {endpoint.fullDescription || `${endpoint.description}. Use this endpoint to interact with the API and retrieve or modify data as needed.`}
                        </p>
                        {endpoint.summary && (
                          <p className="text-sm text-muted-foreground mt-2 italic">
                            {endpoint.summary}
                          </p>
                        )}
                      </div>

                      {/* Parameters */}
                      {endpoint.method !== 'DELETE' && (
                        <div>
                          <h4 className="font-semibold mb-3">Request Headers</h4>
                          <div className="border rounded-lg overflow-hidden">
                            <table className="w-full text-sm">
                              <thead className="bg-muted">
                                <tr>
                                  <th className="text-left p-3 font-semibold">Header Name</th>
                                  <th className="text-left p-3 font-semibold">Type</th>
                                  <th className="text-left p-3 font-semibold">Required</th>
                                  <th className="text-left p-3 font-semibold">Description</th>
                                </tr>
                              </thead>
                              <tbody className="divide-y">
                                {endpoint.method === 'GET' ? (
                                  <>
                                    <tr>
                                      <td className="p-3"><code className="text-xs">limit</code></td>
                                      <td className="p-3"><code className="text-xs">integer</code></td>
                                      <td className="p-3"><Badge variant="outline" className="text-xs">Optional</Badge></td>
                                      <td className="p-3 text-muted-foreground">Maximum number of results to return</td>
                                    </tr>
                                    <tr>
                                      <td className="p-3"><code className="text-xs">offset</code></td>
                                      <td className="p-3"><code className="text-xs">integer</code></td>
                                      <td className="p-3"><Badge variant="outline" className="text-xs">Optional</Badge></td>
                                      <td className="p-3 text-muted-foreground">Number of results to skip</td>
                                    </tr>
                                  </>
                                ) : (
                                  <>
                                    <tr>
                                      <td className="p-3"><code className="text-xs">data</code></td>
                                      <td className="p-3"><code className="text-xs">object</code></td>
                                      <td className="p-3"><Badge variant="destructive" className="text-xs">Required</Badge></td>
                                      <td className="p-3 text-muted-foreground">Request payload containing transaction details</td>
                                    </tr>
                                    <tr>
                                      <td className="p-3"><code className="text-xs">idempotencyKey</code></td>
                                      <td className="p-3"><code className="text-xs">string</code></td>
                                      <td className="p-3"><Badge variant="outline" className="text-xs">Optional</Badge></td>
                                      <td className="p-3 text-muted-foreground">Unique key to prevent duplicate requests</td>
                                    </tr>
                                  </>
                                )}
                              </tbody>
                            </table>
                          </div>
                        </div>
                      )}

                      {/* Response */}
                      <div>
                        <h4 className="font-semibold mb-3">Response</h4>
                        <div className="space-y-3">
                          <div className="border-l-4 border-green-500 bg-green-500/10 p-4 rounded-r-lg">
                            <div className="flex items-center justify-between mb-2">
                              <code className="font-semibold">200 OK</code>
                              <Badge variant="outline" className="text-xs">Success</Badge>
                            </div>
                            <p className="text-sm text-muted-foreground">Request completed successfully</p>
                          </div>
                          <div className="border-l-4 border-yellow-500 bg-yellow-500/10 p-4 rounded-r-lg">
                            <div className="flex items-center justify-between mb-2">
                              <code className="font-semibold">400 Bad Request</code>
                              <Badge variant="outline" className="text-xs">Error</Badge>
                            </div>
                            <p className="text-sm text-muted-foreground">Invalid request parameters or payload</p>
                          </div>
                          <div className="border-l-4 border-red-500 bg-red-500/10 p-4 rounded-r-lg">
                            <div className="flex items-center justify-between mb-2">
                              <code className="font-semibold">401 Unauthorized</code>
                              <Badge variant="outline" className="text-xs">Error</Badge>
                            </div>
                            <p className="text-sm text-muted-foreground">Authentication failed or missing credentials</p>
                          </div>
                        </div>
                      </div>
                    </div>
                  </section>
                ))}
              </>
            )}

            {/* Quick Start Section - Only for non-ACH APIs */}
            {api.name !== 'ACH Payments' && (
              <section id="quickstart" data-section className="mb-16">
                <h2 className="text-2xl font-bold mb-4 flex items-center gap-2">
                  <Book className="h-6 w-6 text-primary" />
                  Quick Start Guide
                </h2>
                <div className="space-y-6">
                  <div className="flex gap-4">
                    <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-primary text-sm font-bold text-primary-foreground">
                      1
                    </div>
                    <div className="flex-1">
                      <h3 className="font-semibold mb-2">Get API Credentials</h3>
                      <p className="text-sm text-muted-foreground">
                        Sign up for a developer account and generate your API key and OAuth credentials from the dashboard.
                      </p>
                    </div>
                  </div>

                  <div className="flex gap-4">
                    <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-primary text-sm font-bold text-primary-foreground">
                      2
                    </div>
                    <div className="flex-1">
                      <h3 className="font-semibold mb-2">Configure Authentication</h3>
                      <p className="text-sm text-muted-foreground">
                        Use {api.authentication} to secure your API calls. Include the required headers in every request.
                      </p>
                    </div>
                  </div>

                  <div className="flex gap-4">
                    <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-primary text-sm font-bold text-primary-foreground">
                      3
                    </div>
                    <div className="flex-1">
                      <h3 className="font-semibold mb-2">Make Your First Request</h3>
                      <p className="text-sm text-muted-foreground">
                        Use the code examples in the right panel to make your first API call. Try the interactive request builder to test endpoints.
                      </p>
                    </div>
                  </div>
                </div>
              </section>
            )}

            {/* Use Cases Section - Only for non-ACH APIs */}
            {api.name !== 'ACH Payments' && (
              <section id="use-cases" data-section className="mb-16">
                <h2 className="text-2xl font-bold mb-6">Common Use Cases</h2>
                <div className="space-y-4">
                  {api.useCases.map((useCase, idx) => (
                    <Card key={idx}>
                      <CardHeader>
                        <CardTitle className="text-lg flex items-center gap-2">
                          <CheckCircle2 className="h-5 w-5 text-primary" />
                          {useCase}
                        </CardTitle>
                      </CardHeader>
                      <CardContent>
                        <p className="text-sm text-muted-foreground mb-3">
                          This API is commonly used for {useCase.toLowerCase()} scenarios. Integrate it into your workflow to streamline operations.
                        </p>
                        <Button variant="link" className="px-0" asChild>
                          <a href="/solutions" className="gap-1">
                            See Solutions Using This API
                            <ExternalLink className="h-3 w-3" />
                          </a>
                        </Button>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </section>
            )}

            {/* Error Handling Section */}
            <section id="errors" data-section className="mb-16">
              <h2 className="text-2xl font-bold mb-4">Error Handling</h2>
              <div className="prose prose-sm max-w-none">
                <p className="text-muted-foreground mb-4">
                  The API uses standard HTTP response codes to indicate success or failure. Error responses include detailed information to help debug issues.
                </p>
                <div className="space-y-3">
                  <div className="border-l-4 border-green-500 bg-green-500/10 p-4 rounded-r-lg">
                    <code className="font-semibold">200 OK</code>
                    <p className="text-sm mt-1">Request succeeded</p>
                  </div>
                  <div className="border-l-4 border-yellow-500 bg-yellow-500/10 p-4 rounded-r-lg">
                    <code className="font-semibold">400 Bad Request</code>
                    <p className="text-sm mt-1">Invalid request parameters</p>
                  </div>
                  <div className="border-l-4 border-red-500 bg-red-500/10 p-4 rounded-r-lg">
                    <code className="font-semibold">401 Unauthorized</code>
                    <p className="text-sm mt-1">Authentication failed or missing</p>
                  </div>
                  <div className="border-l-4 border-red-500 bg-red-500/10 p-4 rounded-r-lg">
                    <code className="font-semibold">429 Too Many Requests</code>
                    <p className="text-sm mt-1">Rate limit exceeded</p>
                  </div>
                </div>
              </div>
            </section>
          </div>
        </main>

        {/* Right Sidebar - API Explorer with Endpoint Blocks */}
        <aside className="w-[480px] border-l bg-slate-950 text-slate-50 flex-shrink-0 relative">
          <div className="p-6">
            {/* Endpoint Blocks with spacing to align with content sections */}
            {sampleEndpoints.map((endpoint, idx) => (
              <Card
                key={idx}
                ref={(el) => blockRefs.current[idx] = el}
                className={`border-2 transition-all ${
                  activeSection === endpoint.id
                    ? 'border-primary bg-primary/5'
                    : 'border-slate-800 bg-slate-900'
                }`}
                style={{
                  marginTop: endpointPositions[idx] ? `${endpointPositions[idx]}px` : '0px'
                }}
                data-endpoint-id={endpoint.id}
              >
                <CardHeader className="pb-3">
                  <div className="flex items-center gap-2 mb-2">
                    <Badge variant="default" className="font-mono text-xs">
                      {endpoint.method}
                    </Badge>
                    <code className="text-xs text-slate-300">{endpoint.path}</code>
                  </div>
                  <p className="text-xs text-slate-400">{endpoint.description}</p>
                </CardHeader>
                <CardContent className="space-y-6">
                  {/* Code Samples Section */}
                  <div className="space-y-3">
                    <div className="flex items-center gap-2 pb-2 border-b border-slate-800">
                      <Code2 className="h-4 w-4 text-primary" />
                      <h3 className="text-sm font-semibold">Code Samples</h3>
                    </div>

                    {/* Language Selector */}
                    <Tabs value={selectedLanguage} onValueChange={setSelectedLanguage}>
                      <TabsList className="w-full bg-slate-900">
                        <TabsTrigger value="curl" className="flex-1 text-xs">cURL</TabsTrigger>
                        <TabsTrigger value="python" className="flex-1 text-xs">Python</TabsTrigger>
                        <TabsTrigger value="javascript" className="flex-1 text-xs">Node.js</TabsTrigger>
                        <TabsTrigger value="java" className="flex-1 text-xs">Java</TabsTrigger>
                      </TabsList>
                    </Tabs>

                    <div>
                      <div className="flex items-center justify-between mb-2">
                        <h4 className="text-xs font-semibold text-slate-400">Example Request</h4>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => copyToClipboard(getCodeSample(selectedLanguage, idx), `code-${idx}`)}
                          className="h-6 text-slate-400 hover:text-slate-50"
                        >
                          {copiedEndpoint === `code-${idx}` ? (
                            <Check className="h-3 w-3" />
                          ) : (
                            <Copy className="h-3 w-3" />
                          )}
                        </Button>
                      </div>
                      <pre className="text-xs bg-slate-950 p-3 rounded-lg overflow-x-auto border border-slate-800">
                        <code className="text-slate-300">{getCodeSample(selectedLanguage, idx)}</code>
                      </pre>
                    </div>
                  </div>

                  {/* Request & Response Section */}
                  <div className="space-y-3">
                    <div className="flex items-center gap-2 pb-2 border-b border-slate-800">
                      <Play className="h-4 w-4 text-primary" />
                      <h3 className="text-sm font-semibold">Request & Response</h3>
                    </div>

                    {/* Request Body Editor */}
                    {endpoint.method !== 'GET' && (
                      <div>
                        <h4 className="text-xs font-semibold mb-2 text-slate-400">Request Body</h4>
                        <Textarea
                          value={requestBody}
                          onChange={(e) => setRequestBody(e.target.value)}
                          className="font-mono text-xs bg-slate-950 border-slate-800 text-slate-300 min-h-[100px]"
                          placeholder="Enter JSON payload"
                        />
                      </div>
                    )}

                    {/* Try It Button */}
                    <Button
                      onClick={() => {
                        setSelectedEndpoint(idx);
                        handleTryRequest();
                      }}
                      disabled={isLoading}
                      className="w-full gap-2"
                      size="sm"
                    >
                      {isLoading && selectedEndpoint === idx ? (
                        <>Processing...</>
                      ) : (
                        <>
                          <Play className="h-3 w-3" />
                          Try {endpoint.description}
                        </>
                      )}
                    </Button>

                    {/* Response Display */}
                    {response && selectedEndpoint === idx && (
                      <div>
                        <div className="flex items-center justify-between mb-2">
                          <h4 className="text-xs font-semibold text-slate-400">Response</h4>
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => copyToClipboard(response, `response-${idx}`)}
                            className="h-6 text-slate-400 hover:text-slate-50"
                          >
                            {copiedEndpoint === `response-${idx}` ? (
                              <Check className="h-3 w-3" />
                            ) : (
                              <Copy className="h-3 w-3" />
                            )}
                          </Button>
                        </div>
                        <pre className="text-xs bg-green-950/30 border border-green-800/50 p-3 rounded-lg overflow-x-auto">
                          <code className="text-green-300">{response}</code>
                        </pre>
                      </div>
                    )}
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </aside>
      </div>
    </div>
  );
}
