import { useParams, useNavigate } from 'react-router-dom';
import { ArrowLeft, BookOpen, CheckCircle2, Code2, Database, Globe, AlertCircle, ExternalLink, Zap, Layers, Target, TrendingUp } from 'lucide-react';
import { Button } from '../ui/button';
import { Badge } from '../ui/badge';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../ui/card';
import { Separator } from '../ui/separator';

// Import solution data
import solution1 from '@/data/solution-1-automated-north-american-payables.json';
import solution2 from '@/data/solution-2-real-time-treasury-visibility.json';
import solution3 from '@/data/solution-3-instant-payouts-interac.json';
import solution4 from '@/data/solution-4-vendor-onboarding-validation.json';
import solution5 from '@/data/solution-5-embedded-erp-banking.json';
import solution6 from '@/data/solution-6-cross-border-payments.json';
import solution7 from '@/data/solution-7-cheque-image-access.json';
import solution8 from '@/data/solution-8-oauth-corporate-data-access.json';

const allSolutions = [
  solution1,
  solution2,
  solution3,
  solution4,
  solution5,
  solution6,
  solution7,
  solution8,
];

export function SolutionDetailPage() {
  const { slug } = useParams<{ slug: string }>();
  const navigate = useNavigate();

  const solution = allSolutions.find((s) => s.slug === slug);

  if (!solution) {
    return (
      <div className="w-full py-16">
        <div className="container px-4">
          <div className="max-w-3xl mx-auto text-center">
            <h1 className="text-3xl font-bold mb-4">Solution Not Found</h1>
            <p className="text-muted-foreground mb-8">
              The solution you're looking for doesn't exist.
            </p>
            <Button onClick={() => navigate('/solutions')}>
              Back to Solutions
            </Button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="w-full">
      {/* Hero Section - Compact */}
      <section className="w-full py-8 bg-gradient-to-br from-blue-600/5 via-cyan-500/5 to-background border-b">
        <div className="container px-4">
          <div className="max-w-5xl mx-auto">
            <button
              onClick={() => navigate('/solutions')}
              className="inline-flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground transition-colors -ml-2 mb-4"
            >
              <ArrowLeft className="h-4 w-4" />
              Back to Solutions
            </button>
            <h1 className="text-3xl md:text-4xl font-bold mb-3">
              {solution.title}
            </h1>
            <p className="text-lg text-muted-foreground mb-4">
              {solution.summary}
            </p>
            <div className="flex flex-wrap gap-2 items-center">
              <Badge variant="outline" className="gap-1.5 bg-primary/10 border-primary text-primary font-medium">
                <Globe className="h-3.5 w-3.5" />
                {solution.region}
              </Badge>
              <Badge variant="outline" className="gap-1.5 bg-primary/10 border-primary text-primary font-medium">
                <Zap className="h-3.5 w-3.5" />
                {solution.complexity} Complexity
              </Badge>
              <Badge variant="outline" className="gap-1.5 bg-primary/10 border-primary text-primary font-medium">
                <Layers className="h-3.5 w-3.5" />
                {solution.apis.length} APIs
              </Badge>
            </div>
          </div>
        </div>
      </section>

      <div className="container px-4 py-10">
        <div className="max-w-5xl mx-auto space-y-10">
          {/* Business Challenge & Outcomes - Side by side */}
          <section className="grid md:grid-cols-2 gap-8">
            {/* Business Challenge */}
            <div>
              <div className="flex items-center gap-2 mb-3">
                <Target className="h-5 w-5 text-primary" />
                <h2 className="text-xl font-bold">Business Challenge</h2>
              </div>
              <p className="text-muted-foreground leading-relaxed">
                {solution.businessProblem}
              </p>
            </div>

            {/* Business Outcomes */}
            <div>
              <div className="flex items-center gap-2 mb-3">
                <TrendingUp className="h-5 w-5 text-primary" />
                <h2 className="text-xl font-bold">Business Outcomes</h2>
              </div>
              <ul className="space-y-3">
                {solution.businessOutcomes.map((outcome, index) => {
                  const [title, description] = outcome.split(':');
                  return (
                    <li key={index} className="flex gap-3">
                      <CheckCircle2 className="h-5 w-5 text-primary shrink-0 mt-0.5" />
                      <div>
                        <div className="font-semibold text-sm mb-1">{title}</div>
                        <div className="text-sm text-muted-foreground">{description}</div>
                      </div>
                    </li>
                  );
                })}
              </ul>
            </div>
          </section>

          {/* Implementation Workflow - Linear Timeline */}
          <section>
            <h2 className="text-xl font-bold mb-6">Implementation Workflow</h2>
            <div className="space-y-6">
              {solution.workflow.map((step, index) => (
                <div key={step.step} className="flex gap-5">
                  <div className="flex flex-col items-center">
                    <div className="w-10 h-10 rounded-full bg-primary text-primary-foreground flex items-center justify-center text-sm font-bold shrink-0">
                      {step.step}
                    </div>
                    {index < solution.workflow.length - 1 && (
                      <div className="w-0.5 h-full bg-border mt-3" />
                    )}
                  </div>
                  <div className="flex-1 pb-4">
                    <h3 className="font-semibold text-base mb-3">{step.title}</h3>
                    <p className="text-sm text-foreground leading-relaxed max-w-3xl">
                      {step.description}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          </section>

          {/* APIs Used - Simplified */}
          <section>
            <h2 className="text-xl font-bold mb-4">APIs Used</h2>
            <div className="space-y-3">
              {solution.apis.map((api, index) => (
                <div key={index} className="flex items-start gap-3 p-4 border rounded-lg hover:bg-muted/50 transition-colors">
                  <Database className="h-5 w-5 text-primary shrink-0 mt-0.5" />
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 mb-1">
                      <a
                        href={api.documentation_url}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="font-semibold hover:text-primary transition-colors"
                      >
                        {api.name}
                      </a>
                      <span className="text-xs text-muted-foreground">v{api.version}</span>
                      <span className="text-xs text-muted-foreground">• {api.region}</span>
                    </div>
                    <p className="text-sm text-muted-foreground">{api.purpose}</p>
                  </div>
                  <ExternalLink className="h-4 w-4 text-muted-foreground shrink-0 mt-0.5" />
                </div>
              ))}
            </div>
          </section>

          {/* Technical Specifications */}
          <section>
            <h2 className="text-xl font-bold mb-4">Technical Specifications</h2>
            <Card>
              <CardContent className="pt-6 space-y-4">
                <div>
                  <h3 className="font-semibold mb-2">Authentication</h3>
                  <p className="text-sm text-muted-foreground">
                    {solution.technicalSpecifications.authentication}
                  </p>
                </div>

                {solution.technicalSpecifications.messageStandards && (
                  <div>
                    <h3 className="font-semibold mb-2">Message Standards</h3>
                    <div className="flex flex-wrap gap-2">
                      {solution.technicalSpecifications.messageStandards.map((standard, index) => (
                        <Badge key={index} variant="secondary">
                          {standard}
                        </Badge>
                      ))}
                    </div>
                  </div>
                )}

                {solution.technicalSpecifications.encryption && (
                  <div>
                    <h3 className="font-semibold mb-2">Security</h3>
                    <p className="text-sm text-muted-foreground mb-2">
                      {solution.technicalSpecifications.encryption.type}
                    </p>
                    <p className="text-xs text-muted-foreground">
                      {solution.technicalSpecifications.encryption.encoding}
                    </p>
                  </div>
                )}

                {solution.technicalSpecifications.rateLimiting && (
                  <div>
                    <h3 className="font-semibold mb-2">Rate Limiting</h3>
                    <p className="text-sm text-muted-foreground">
                      {solution.technicalSpecifications.rateLimiting.description}
                    </p>
                  </div>
                )}
              </CardContent>
            </Card>
          </section>

          {/* Industries & Personas - Side by side */}
          <section className="grid md:grid-cols-2 gap-8">
            <div>
              <h3 className="font-semibold mb-3">Target Industries</h3>
              <div className="flex flex-wrap gap-2">
                {solution.industries.map((industry, index) => (
                  <Badge key={index} variant="outline">
                    {industry}
                  </Badge>
                ))}
              </div>
            </div>

            <div>
              <h3 className="font-semibold mb-3">Key Personas</h3>
              <div className="flex flex-wrap gap-2">
                {solution.personas.map((persona, index) => (
                  <Badge key={index} variant="outline">
                    {persona}
                  </Badge>
                ))}
              </div>
            </div>
          </section>

          {/* CTA Section */}
          <section className="border-t pt-8">
            <div className="text-center space-y-4">
              <h3 className="text-2xl font-bold">Ready to Get Started?</h3>
              <p className="text-muted-foreground">
                Explore our APIs and start building this solution today.
              </p>
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <Button size="lg" asChild>
                  <a href="/apis">Browse API Catalog</a>
                </Button>
                <Button size="lg" variant="outline" asChild>
                  <a href="/contact">Contact Solutions Team</a>
                </Button>
              </div>
            </div>
          </section>
        </div>
      </div>
    </div>
  );
}
