import { useState } from 'react';
import { Code2, Filter, ChevronDown, Check } from 'lucide-react';
import { Button } from '../ui/button';
import {
  DropdownMenu,
  DropdownMenuTrigger,
  DropdownMenuContent,
} from '../ui/dropdown-menu';
import { Command, CommandInput, CommandList, CommandEmpty, CommandGroup, CommandItem } from '../ui/command';

// Import recipe data
import recipe1 from '@/data/recipe-1-vendor-payment-ach-validation.json';
import recipe2 from '@/data/recipe-2-canadian-eft-batch.json';
import recipe3 from '@/data/recipe-3-instant-payout-interac.json';
import recipe4 from '@/data/recipe-4-treasury-dashboard.json';
import recipe5 from '@/data/recipe-5-cheque-image-access.json';
import recipe6 from '@/data/recipe-6-erp-pay-now-button.json';
import recipe7 from '@/data/recipe-7-oauth-authorization-flow.json';
import recipe8 from '@/data/recipe-8-payment-status-wallboard.json';
import recipe9 from '@/data/recipe-9-sandbox-qa-automation.json';
import recipe10 from '@/data/recipe-10-automated-reconciliation.json';

const allRecipes = [
  recipe1,
  recipe2,
  recipe3,
  recipe4,
  recipe5,
  recipe6,
  recipe7,
  recipe8,
  recipe9,
  recipe10,
];

export function RecipesGalleryPage() {
  const [selectedIndustry, setSelectedIndustry] = useState<string>('all');
  const [filterOpen, setFilterOpen] = useState(false);

  // Get all unique industries
  const allIndustries = Array.from(
    new Set(allRecipes.flatMap((recipe) => recipe.industries))
  ).sort();

  // Filter recipes by industry only
  const filteredRecipes = allRecipes.filter((recipe) => {
    return selectedIndustry === 'all' || recipe.industries.includes(selectedIndustry);
  });

  return (
    <div className="w-full">
      {/* Hero Section with Futuristic Blue Gradient */}
      <section className="relative w-full overflow-hidden py-16 pb-8">
        {/* Futuristic blue gradient background */}
        <div className="absolute inset-0 bg-gradient-to-br from-blue-600/20 via-cyan-500/10 to-blue-900/20" />
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-blue-400/20 via-transparent to-transparent" />
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_bottom_right,_var(--tw-gradient-stops))] from-cyan-400/15 via-transparent to-transparent" />

        <div className="container px-4 relative z-10">
          <div className="max-w-3xl mx-auto text-center">
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold mb-6">
              Technical Recipes
            </h1>
            <p className="text-lg md:text-xl text-muted-foreground">
              Step-by-step technical implementation guides for common workflows.
              Each recipe combines multiple APIs to solve real-world integration challenges.
            </p>
          </div>
        </div>
      </section>

      {/* Recipes Grid with Filter */}
      <section className="w-full pt-8 pb-16">
        <div className="container px-4">
          {/* Searchable Industry Filter - Aligned Left */}
          <div className="mb-8">
            <DropdownMenu open={filterOpen} onOpenChange={setFilterOpen}>
              <DropdownMenuTrigger asChild>
                <Button variant="outline" size="default" className="gap-2 min-w-[240px]">
                  <Filter className="h-4 w-4" />
                  <span className="flex-1 text-left truncate">
                    {selectedIndustry === 'all' ? 'Filter by Industry' : selectedIndustry}
                  </span>
                  <ChevronDown className="h-4 w-4" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="start" className="w-[300px] p-0">
                <Command>
                  <CommandInput placeholder="Search industries..." />
                  <CommandList>
                    <CommandEmpty>No industry found.</CommandEmpty>
                    <CommandGroup>
                      <CommandItem
                        onSelect={() => {
                          setSelectedIndustry('all');
                          setFilterOpen(false);
                        }}
                      >
                        <Check
                          className={`mr-2 h-4 w-4 ${
                            selectedIndustry === 'all' ? 'opacity-100' : 'opacity-0'
                          }`}
                        />
                        All Industries
                      </CommandItem>
                      {allIndustries.map((industry) => (
                        <CommandItem
                          key={industry}
                          onSelect={() => {
                            setSelectedIndustry(industry);
                            setFilterOpen(false);
                          }}
                        >
                          <Check
                            className={`mr-2 h-4 w-4 ${
                              selectedIndustry === industry ? 'opacity-100' : 'opacity-0'
                            }`}
                          />
                          {industry}
                        </CommandItem>
                      ))}
                    </CommandGroup>
                  </CommandList>
                </Command>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>

          {/* Grid */}
          <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
            {filteredRecipes.map((recipe) => {
              return (
                <a
                  key={recipe.id}
                  href={`/recipes/${recipe.slug}`}
                  className="group relative border rounded-xl p-6 hover:shadow-2xl transition-all duration-300 hover:border-primary/50 bg-background overflow-hidden hover:-translate-y-1"
                >
                  {/* Subtle gradient background on hover */}
                  <div className="absolute inset-0 bg-gradient-to-br from-primary/5 to-accent/5 opacity-0 group-hover:opacity-100 transition-opacity duration-300" />

                  {/* Content */}
                  <div className="relative z-10">
                    {/* Icon with gradient */}
                    <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-primary/20 to-accent/20 flex items-center justify-center mb-4 group-hover:scale-110 transition-transform duration-300">
                      <Code2 className="h-6 w-6 text-primary" />
                    </div>

                    {/* Title */}
                    <h3 className="text-lg font-semibold mb-2 group-hover:text-primary transition-colors">
                      {recipe.title}
                    </h3>

                    {/* Overview */}
                    <p className="text-sm text-muted-foreground mb-4 line-clamp-3">
                      {recipe.overview}
                    </p>

                    {/* Industries */}
                    <div className="flex flex-wrap gap-2 mb-4">
                      {recipe.industries.slice(0, 2).map((industry) => (
                        <span
                          key={industry}
                          className="text-xs px-2 py-1 rounded-full bg-primary/10 text-primary border border-primary/20"
                        >
                          {industry}
                        </span>
                      ))}
                      {recipe.industries.length > 2 && (
                        <span className="text-xs px-2 py-1 rounded-full bg-muted text-muted-foreground border">
                          +{recipe.industries.length - 2}
                        </span>
                      )}
                    </div>

                    {/* APIs Used */}
                    <div className="text-xs font-medium text-muted-foreground mb-2">
                      {recipe.apis.length} API{recipe.apis.length !== 1 ? 's' : ''} used
                    </div>

                    {/* Hover Arrow */}
                    <div className="text-primary text-sm font-medium opacity-0 group-hover:opacity-100 transition-opacity flex items-center gap-1">
                      View Recipe
                      <svg
                        className="w-4 h-4 group-hover:translate-x-1 transition-transform"
                        fill="none"
                        stroke="currentColor"
                        viewBox="0 0 24 24"
                      >
                        <path
                          strokeLinecap="round"
                          strokeLinejoin="round"
                          strokeWidth={2}
                          d="M9 5l7 7-7 7"
                        />
                      </svg>
                    </div>
                  </div>
                </a>
              );
            })}
          </div>

          {/* No Results */}
          {filteredRecipes.length === 0 && (
            <div className="text-center py-16">
              <p className="text-muted-foreground mb-4">
                No recipes found for {selectedIndustry}
              </p>
              <Button
                variant="outline"
                onClick={() => setSelectedIndustry('all')}
              >
                Clear Filter
              </Button>
            </div>
          )}
        </div>
      </section>

      {/* CTA Section */}
      <section className="w-full py-16 bg-muted/30">
        <div className="container px-4">
          <div className="max-w-3xl mx-auto text-center">
            <h2 className="text-3xl font-bold mb-4">
              Need implementation help?
            </h2>
            <p className="text-lg text-muted-foreground mb-8">
              Our developer support team can help you implement any recipe or create custom workflows for your specific integration needs.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button asChild size="lg">
                <a href="/contact">
                  Contact Developer Support
                </a>
              </Button>
              <Button asChild variant="outline" size="lg">
                <a href="/apis">
                  Browse All APIs
                </a>
              </Button>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
