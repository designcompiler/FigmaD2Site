import { useState } from 'react';
import { Search, Filter, ChevronDown, Code2, CheckCircle2, FlaskConical, Globe, Layers } from 'lucide-react';
import { Button } from '../ui/button';
import { Input } from '../ui/input';
import { Badge } from '../ui/badge';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../ui/card';
import {
  DropdownMenu,
  DropdownMenuTrigger,
  DropdownMenuContent,
  DropdownMenuRadioGroup,
  DropdownMenuRadioItem,
} from '../ui/dropdown-menu';

import apisData from '@/data/apis.json';

interface API {
  id: string;
  name: string;
  slug: string;
  category: string;
  status: string;
  version: string;
  description: string;
  region: string;
  authentication: string;
  rateLimit: string;
  features: string[];
  useCases: string[];
}

const allAPIs: API[] = apisData;

export function APICatalogPage() {
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [selectedStatus, setSelectedStatus] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState<string>('');

  // Get unique categories and statuses
  const allCategories = Array.from(new Set(allAPIs.map((api) => api.category))).sort();
  const allStatuses = Array.from(new Set(allAPIs.map((api) => api.status))).sort();

  // Filter APIs
  const filteredAPIs = allAPIs.filter((api) => {
    const matchesCategory = selectedCategory === 'all' || api.category === selectedCategory;
    const matchesStatus = selectedStatus === 'all' || api.status === selectedStatus;
    const matchesSearch =
      searchQuery === '' ||
      api.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      api.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
      api.category.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCategory && matchesStatus && matchesSearch;
  });

  // Group APIs by category for display
  const apisByCategory = filteredAPIs.reduce((acc, api) => {
    if (!acc[api.category]) {
      acc[api.category] = [];
    }
    acc[api.category].push(api);
    return acc;
  }, {} as Record<string, API[]>);

  const getStatusIcon = (status: string) => {
    if (status === 'Generally Available') {
      return <CheckCircle2 className="h-4 w-4" />;
    }
    return <FlaskConical className="h-4 w-4" />;
  };

  const getStatusVariant = (status: string): 'default' | 'secondary' => {
    return status === 'Generally Available' ? 'default' : 'secondary';
  };

  const getRegionFlag = (region: string): string => {
    if (region.includes('US') && region.includes('Canada')) return '🇺🇸 🇨🇦';
    if (region.includes('US')) return '🇺🇸';
    if (region.includes('Canada')) return '🇨🇦';
    return '🌍';
  };

  return (
    <div className="w-full">
      {/* Hero Section */}
      <section className="relative w-full overflow-hidden py-16 pb-8">
        {/* Futuristic blue gradient background */}
        <div className="absolute inset-0 bg-gradient-to-br from-blue-600/20 via-cyan-500/10 to-blue-900/20" />
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-blue-400/20 via-transparent to-transparent" />
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_bottom_right,_var(--tw-gradient-stops))] from-cyan-400/15 via-transparent to-transparent" />

        <div className="container px-4 relative z-10">
          <div className="max-w-3xl mx-auto text-center">
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold mb-6">
              API Catalog
            </h1>
            <p className="text-lg md:text-xl text-muted-foreground">
              Explore our comprehensive suite of banking APIs. Build payment solutions, access account data, and integrate secure authentication.
            </p>
          </div>
        </div>
      </section>

      {/* Compact Filter & Category Bar */}
      <section className="w-full border-b bg-background/95 backdrop-blur">
        <div className="container px-4 py-6">
          <div className="max-w-6xl mx-auto space-y-4">
            {/* Search and Status Filter Row */}
            <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-3">
              {/* Search Input */}
              <div className="relative flex-1">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <Input
                  type="text"
                  placeholder="Search APIs..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-9"
                />
              </div>

              {/* Status Filter */}
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="outline" size="default" className="gap-2 min-w-[160px]">
                    <span className="flex-1 text-left truncate">
                      {selectedStatus === 'all' ? 'All Statuses' : selectedStatus}
                    </span>
                    <ChevronDown className="h-4 w-4" />
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end" className="w-56">
                  <DropdownMenuRadioGroup value={selectedStatus} onValueChange={setSelectedStatus}>
                    <DropdownMenuRadioItem value="all">All Statuses</DropdownMenuRadioItem>
                    {allStatuses.map((status) => (
                      <DropdownMenuRadioItem key={status} value={status}>
                        {status}
                      </DropdownMenuRadioItem>
                    ))}
                  </DropdownMenuRadioGroup>
                </DropdownMenuContent>
              </DropdownMenu>
            </div>

            {/* Category Navigation Row */}
            <div className="flex flex-wrap gap-2">
              <Badge
                variant={selectedCategory === 'all' ? 'default' : 'outline'}
                className="cursor-pointer hover:bg-primary/10 transition-colors px-3 py-1.5"
                onClick={() => setSelectedCategory('all')}
              >
                <Layers className="h-3 w-3 mr-1.5" />
                All
              </Badge>
              {allCategories.map((category) => (
                <Badge
                  key={category}
                  variant={selectedCategory === category ? 'default' : 'outline'}
                  className="cursor-pointer hover:bg-primary/10 transition-colors px-3 py-1.5"
                  onClick={() => setSelectedCategory(category)}
                >
                  {category}
                </Badge>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* APIs Grid - Grouped by Category */}
      <section className="w-full py-16">
        <div className="container px-4">
          {Object.keys(apisByCategory).length === 0 ? (
            <div className="text-center py-16">
              <p className="text-muted-foreground mb-4">No APIs found matching your filters</p>
              <Button
                variant="outline"
                onClick={() => {
                  setSelectedCategory('all');
                  setSelectedStatus('all');
                  setSearchQuery('');
                }}
              >
                Clear All Filters
              </Button>
            </div>
          ) : (
            <div className="space-y-12">
              {Object.entries(apisByCategory).map(([category, apis]) => (
                <div key={category}>
                  <h2 className="text-2xl font-bold mb-6 flex items-center gap-3">
                    <Code2 className="h-6 w-6 text-primary" />
                    {category}
                  </h2>
                  <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
                    {apis.map((api) => (
                      <a
                        key={api.id}
                        href={`/apis/${api.slug}`}
                        className="group relative border rounded-xl p-6 hover:shadow-2xl transition-all duration-300 hover:border-primary/50 bg-background overflow-hidden hover:-translate-y-1 block"
                      >
                        {/* Subtle gradient background on hover */}
                        <div className="absolute inset-0 bg-gradient-to-br from-primary/5 to-accent/5 opacity-0 group-hover:opacity-100 transition-opacity duration-300" />

                        {/* Content */}
                        <div className="relative z-10">
                          <div className="flex items-start justify-between gap-2 mb-3">
                            <h3 className="text-xl font-semibold group-hover:text-primary transition-colors">
                              {api.name}
                            </h3>
                            <Badge
                              variant={getStatusVariant(api.status)}
                              className="gap-1 shrink-0 bg-primary/10 border-primary text-primary font-medium"
                            >
                              {getStatusIcon(api.status)}
                              <span className="text-xs">{api.status === 'Generally Available' ? 'GA' : 'Upcoming'}</span>
                            </Badge>
                          </div>
                          <div className="flex items-center gap-2 mb-3">
                            <Badge variant="outline" className="gap-1.5 text-xs">
                              <span>{getRegionFlag(api.region)}</span>
                              {api.region}
                            </Badge>
                            <Badge variant="outline" className="gap-1 text-xs">
                              v{api.version}
                            </Badge>
                          </div>
                          <p className="text-sm text-muted-foreground mb-4">{api.description}</p>

                          {/* Technical Info */}
                          <div className="space-y-2">
                            <div className="flex justify-between text-xs">
                              <span className="text-muted-foreground">Authentication</span>
                              <span className="font-medium">{api.authentication}</span>
                            </div>
                            <div className="flex justify-between text-xs">
                              <span className="text-muted-foreground">Rate Limit</span>
                              <span className="font-medium">{api.rateLimit}</span>
                            </div>
                          </div>
                        </div>
                      </a>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </section>

      {/* CTA Section */}
      <section className="w-full py-16 bg-muted/30">
        <div className="container px-4">
          <div className="max-w-3xl mx-auto text-center">
            <h2 className="text-3xl font-bold mb-4">Need Help Getting Started?</h2>
            <p className="text-lg text-muted-foreground mb-8">
              Our developer support team is here to help you integrate our APIs into your applications.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button asChild size="lg">
                <a href="/get-started">Get Started Guide</a>
              </Button>
              <Button asChild variant="outline" size="lg">
                <a href="/contact">Contact Support</a>
              </Button>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
