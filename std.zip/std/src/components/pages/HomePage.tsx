import { HeroSection } from '../features/HeroSection';
import { UseCaseTabs } from '../features/UseCaseTabs';
import { Button } from '../ui/button';
import { ArrowRight, Code, Zap, Lock, BookOpen, FileCode } from 'lucide-react';

export function HomePage() {
  const useCases = [
    {
      id: 'embedded-payments',
      title: 'Embedded payments',
      description:
        'Automate vendor payments, optimize cash flow and gain real-time visibility—right from your ERP or TMS.',
      href: '/use-cases/embedded-payments',
      image: 'placeholder',
    },
    {
      id: 'real-time-financial',
      title: 'Real-time financial intelligence',
      description:
        'Gain instant cash insights, improve liquidity, and make faster financial decisions.',
      href: '/use-cases/real-time-financial',
      image: 'placeholder',
    },
    {
      id: 'compliance-first',
      title: 'Compliance-first automation',
      description:
        'Automate reconciliation, enhance reporting accuracy, and support regulatory compliance — without compromising control.',
      href: '/use-cases/compliance-first-automation',
      image: 'placeholder',
    },
    {
      id: 'account-validation',
      title: 'Account validation',
      description:
        'Instantly verify bank account ownership to reduce risk, stay compliant, and prevent costly payment errors — so every transaction hits the mark. U.S. accounts only.',
      href: '/use-cases/account-validation',
      image: 'placeholder',
    },
  ];

  // Featured solutions (first 3)
  const featuredSolutions = [
    {
      id: 'solution-1',
      title: 'Automated North American Payables',
      summary: 'Unified payables workflow with validation, multi-rail payments (ACH/EFT/Wire), and real-time status tracking across US and Canada.',
      href: '/solutions/automated-north-american-payables',
    },
    {
      id: 'solution-2',
      title: 'Real-Time Treasury Visibility',
      summary: 'Embed real-time account balances, transactions, and reconciliation directly into treasury dashboards and ERPs.',
      href: '/solutions/real-time-treasury-visibility',
    },
    {
      id: 'solution-3',
      title: 'Instant Payouts via Interac',
      summary: 'Enable instant consumer payouts in Canada using Interac e-Transfer for refunds, gig payments, and disbursements.',
      href: '/solutions/instant-payouts-interac',
    },
  ];

  // Featured recipes (first 3)
  const featuredRecipes = [
    {
      id: 'recipe-1',
      title: 'Vendor Payment with Account Validation + ACH',
      overview: 'Validate vendor accounts, initiate ACH payment, and track status—complete end-to-end workflow with fraud prevention.',
      href: '/recipes/vendor-payment-ach-validation',
    },
    {
      id: 'recipe-2',
      title: 'Canadian EFT Batch Processing',
      overview: 'Submit batch EFT payments in Canada with debit/credit mixing, instant status checks, and error handling.',
      href: '/recipes/canadian-eft-batch',
    },
    {
      id: 'recipe-3',
      title: 'Instant Payout via Interac',
      overview: 'Send instant payouts to Canadian consumers using Interac Request Money with automatic acceptance.',
      href: '/recipes/instant-payout-interac',
    },
  ];

  return (
    <>
      {/* Hero Section */}
      <HeroSection
        preHeader="Developer Portal"
        headline="Banking,"
        highlightedText="rewired."
        description="Whether you're expanding into new markets or embedding finance into your platform, our APIs give you the freedom to innovate without limits."
        primaryCTA={{
          text: 'Get Started',
          href: '/getting-started',
        }}
        secondaryCTA={{
          text: 'View APIs',
          href: '/apis',
        }}
      />

      {/* Solutions Preview */}
      <section className="w-full py-16">
        <div className="container px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">
              Business Solutions for <span className="text-primary">Every Industry</span>
            </h2>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              Discover outcome-driven solutions designed for your specific business needs, from treasury management to instant payouts.
            </p>
          </div>

          <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
            {featuredSolutions.map((solution) => (
              <div key={solution.id} className="border rounded-lg p-6 hover:shadow-lg transition-shadow">
                <div className="flex items-start gap-3 mb-3">
                  <BookOpen className="h-6 w-6 text-primary flex-shrink-0 mt-1" />
                  <h3 className="text-xl font-semibold">{solution.title}</h3>
                </div>
                <p className="text-sm text-muted-foreground mb-4">
                  {solution.summary}
                </p>
                <a href={solution.href} className="text-primary hover:underline text-sm font-medium">
                  Learn More →
                </a>
              </div>
            ))}
          </div>

          <div className="text-center mt-8">
            <Button asChild variant="outline">
              <a href="/solutions">
                View All Solutions
              </a>
            </Button>
          </div>
        </div>
      </section>

      {/* API Catalog Preview */}
      <section className="w-full py-16 bg-muted/30">
        <div className="container px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">
              Our APIs help your business{' '}
              <span className="text-primary">move as fast as your ambition.</span>
            </h2>
          </div>

          <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
            <div className="border bg-background rounded-lg p-6 hover:shadow-lg transition-shadow">
              <h3 className="text-xl font-semibold mb-3">Payment APIs</h3>
              <p className="text-sm text-muted-foreground mb-4">
                Send, collect and track domestic or international payments directly from
                your in-house system or platform — plus verify U.S. recipient accounts with
                precision.
              </p>
              <a href="/apis/payments" className="text-primary hover:underline text-sm font-medium">
                Explore Payment APIs →
              </a>
            </div>
            <div className="border bg-background rounded-lg p-6 hover:shadow-lg transition-shadow">
              <h3 className="text-xl font-semibold mb-3">Account Reporting APIs</h3>
              <p className="text-sm text-muted-foreground mb-4">
                Access real-time account data, transaction history and cheque images. Designed
                for seamless integration and day-to-day control over your financial operations.
              </p>
              <a href="/apis/account-reporting" className="text-primary hover:underline text-sm font-medium">
                Explore Account Reporting APIs →
              </a>
            </div>
            <div className="border bg-background rounded-lg p-6 hover:shadow-lg transition-shadow">
              <h3 className="text-xl font-semibold mb-3">Pre-built Connectors</h3>
              <p className="text-sm text-muted-foreground mb-4">
                Seamlessly embed banking into your ERP system with our pre-built connectors.
                Automate your payments, reconciliation, and reporting — no custom code required.
              </p>
              <a href="/connectors" className="text-primary hover:underline text-sm font-medium">
                Explore Pre-built Connectors →
              </a>
            </div>
          </div>

          <div className="text-center mt-8">
            <Button asChild variant="outline">
              <a href="/apis">
                View All APIs
              </a>
            </Button>
          </div>
        </div>
      </section>

      {/* Recipes Preview */}
      <section className="w-full py-16">
        <div className="container px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">
              Technical Recipes for <span className="text-primary">Fast Integration</span>
            </h2>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              Step-by-step implementation guides with code samples, error handling, and best practices for common integration scenarios.
            </p>
          </div>

          <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
            {featuredRecipes.map((recipe) => (
              <div key={recipe.id} className="border rounded-lg p-6 hover:shadow-lg transition-shadow">
                <div className="flex items-start gap-3 mb-3">
                  <FileCode className="h-6 w-6 text-accent flex-shrink-0 mt-1" />
                  <h3 className="text-xl font-semibold">{recipe.title}</h3>
                </div>
                <p className="text-sm text-muted-foreground mb-4">
                  {recipe.overview}
                </p>
                <a href={recipe.href} className="text-primary hover:underline text-sm font-medium">
                  View Recipe →
                </a>
              </div>
            ))}
          </div>

          <div className="text-center mt-8">
            <Button asChild variant="outline">
              <a href="/recipes">
                View All Recipes
              </a>
            </Button>
          </div>
        </div>
      </section>

      {/* How It Works - 3 Step Process */}
      <section className="w-full py-16 bg-muted/30">
        <div className="container px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">
              Get started in <span className="text-primary">three simple steps</span>
            </h2>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              From sandbox to production, we've streamlined the integration process to get you up and running fast.
            </p>
          </div>

          <div className="grid gap-8 md:grid-cols-3 max-w-5xl mx-auto">
            {/* Step 1 */}
            <div className="flex flex-col items-center text-center">
              <div className="w-16 h-16 rounded-full bg-primary/10 flex items-center justify-center mb-4">
                <div className="w-12 h-12 rounded-full bg-primary flex items-center justify-center text-primary-foreground font-bold text-xl">
                  1
                </div>
              </div>
              <h3 className="text-xl font-semibold mb-3">Create Your Account</h3>
              <p className="text-sm text-muted-foreground">
                Sign up for free and get instant access to our sandbox environment. No credit card required.
              </p>
            </div>

            {/* Step 2 */}
            <div className="flex flex-col items-center text-center">
              <div className="w-16 h-16 rounded-full bg-primary/10 flex items-center justify-center mb-4">
                <div className="w-12 h-12 rounded-full bg-primary flex items-center justify-center text-primary-foreground font-bold text-xl">
                  2
                </div>
              </div>
              <h3 className="text-xl font-semibold mb-3">Get Your API Keys</h3>
              <p className="text-sm text-muted-foreground">
                Generate your API credentials from the dashboard and explore our comprehensive documentation.
              </p>
            </div>

            {/* Step 3 */}
            <div className="flex flex-col items-center text-center">
              <div className="w-16 h-16 rounded-full bg-primary/10 flex items-center justify-center mb-4">
                <div className="w-12 h-12 rounded-full bg-primary flex items-center justify-center text-primary-foreground font-bold text-xl">
                  3
                </div>
              </div>
              <h3 className="text-xl font-semibold mb-3">Start Building</h3>
              <p className="text-sm text-muted-foreground">
                Make your first API call, test in sandbox, and go live when you're ready. We're here to help.
              </p>
            </div>
          </div>

          <div className="text-center mt-12">
            <Button asChild size="lg">
              <a href="/getting-started">
                Get Started Now <ArrowRight className="ml-2 h-4 w-4" />
              </a>
            </Button>
          </div>
        </div>
      </section>

      {/* Use Cases Tabs */}
      <UseCaseTabs useCases={useCases} autoRotate={true} rotateInterval={5000} />

      {/* Built by Developers for Developers */}
      <section className="w-full py-16 bg-muted/30">
        <div className="container px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">
              Built by developers, <span className="text-primary">for developers</span>
            </h2>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              We understand what it takes to build great products. That's why we've designed our APIs with developer experience at the core.
            </p>
          </div>

          <div className="grid gap-8 md:grid-cols-3 max-w-5xl mx-auto">
            {/* Feature 1 */}
            <div className="flex flex-col items-center text-center">
              <div className="w-16 h-16 rounded-full bg-accent/10 flex items-center justify-center mb-4">
                <Code className="h-8 w-8 text-accent" />
              </div>
              <h3 className="text-xl font-semibold mb-3">RESTful & Modern</h3>
              <p className="text-sm text-muted-foreground">
                Clean, intuitive API design following REST principles. JSON request and response formats. Comprehensive OpenAPI specs.
              </p>
            </div>

            {/* Feature 2 */}
            <div className="flex flex-col items-center text-center">
              <div className="w-16 h-16 rounded-full bg-accent/10 flex items-center justify-center mb-4">
                <Zap className="h-8 w-8 text-accent" />
              </div>
              <h3 className="text-xl font-semibold mb-3">Fast & Reliable</h3>
              <p className="text-sm text-muted-foreground">
                High-performance infrastructure with 99.9% uptime SLA. Low latency responses. Real-time webhooks for instant updates.
              </p>
            </div>

            {/* Feature 3 */}
            <div className="flex flex-col items-center text-center">
              <div className="w-16 h-16 rounded-full bg-accent/10 flex items-center justify-center mb-4">
                <Lock className="h-8 w-8 text-accent" />
              </div>
              <h3 className="text-xl font-semibold mb-3">Secure by Design</h3>
              <p className="text-sm text-muted-foreground">
                OAuth 2.0 authentication. End-to-end encryption. PCI DSS compliant. Regular security audits and penetration testing.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Footer CTA */}
      <section className="w-full py-16 bg-gradient-to-br from-primary/10 via-background to-accent/10">
        <div className="container px-4">
          <div className="max-w-3xl mx-auto text-center">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">
              Ready to transform your financial operations?
            </h2>
            <p className="text-lg text-muted-foreground mb-8">
              Join thousands of developers building the future of finance with our APIs.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button asChild size="lg">
                <a href="/getting-started">
                  Get Started Free <ArrowRight className="ml-2 h-4 w-4" />
                </a>
              </Button>
              <Button asChild variant="outline" size="lg">
                <a href="/apis">
                  Explore APIs
                </a>
              </Button>
            </div>
            <p className="text-sm text-muted-foreground mt-6">
              No credit card required. Sandbox access included.
            </p>
          </div>
        </div>
      </section>
    </>
  );
}
