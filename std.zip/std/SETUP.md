# Developer Portal - Standalone Setup

This is a **standalone version** of the Developer Portal containing only the essential files needed to run the application.

---

## ✅ What's Included

This package contains:
- ✅ Complete React application
- ✅ All 7 pages (Home, APIs, Solutions, Recipes)
- ✅ All 48+ UI components (shadcn/ui)
- ✅ 8 Solutions with full details
- ✅ 10 Recipes with implementation guides
- ✅ Complete design system (Tailwind CSS v4)
- ✅ All configuration files

---

## 📋 Prerequisites

Before you start, install:
- **Node.js v18+** - [Download](https://nodejs.org/)
- **npm** (comes with Node.js)

Check if installed:
```bash
node --version   # Should show v18 or higher
npm --version    # Should show v9 or higher
```

---

## 🚀 Quick Start

### 1. Install Dependencies
```bash
npm install
```

This installs all required packages (~250 MB of node_modules).

### 2. Run Development Server
```bash
npm run dev
```

You should see:
```
VITE v6.3.5  ready in 193 ms
➜  Local:   http://localhost:3000/
```

### 3. Open in Browser
Navigate to: **http://localhost:3000/**

---

## 📦 Available Commands

```bash
# Development server (with hot reload)
npm run dev

# Build for production
npm run build

# Preview production build
npm run preview

# Type checking
npm run type-check
```

---

## 🌐 Available Pages

| Page | URL | Description |
|------|-----|-------------|
| **Homepage** | `/` | Landing page with API catalog preview |
| **API Catalog** | `/apis` | Browse all APIs with categories |
| **API Detail** | `/apis/:slug` | Individual API documentation with Explorer |
| **Solutions Gallery** | `/solutions` | Browse 8 business solutions |
| **Solution Detail** | `/solutions/:slug` | Detailed solution workflow |
| **Recipes Gallery** | `/recipes` | Browse 10 technical recipes |
| **Recipe Detail** | `/recipes/:slug` | Step-by-step implementation guide |

---

## 📂 Project Structure

```
dev-portal-standalone/
├── index.html              # Entry HTML file
├── package.json            # Dependencies
├── vite.config.ts          # Vite configuration
├── tsconfig.json           # TypeScript config
├── eslint.config.js        # ESLint config
├── public/                 # Static assets
└── src/
    ├── main.tsx            # App entry point
    ├── components/
    │   ├── layout/         # Header, Footer, Layout
    │   ├── pages/          # 7 page components
    │   ├── ui/             # 48+ shadcn/ui components
    │   └── features/       # Feature components
    ├── data/               # JSON data files
    │   ├── solution-*.json # 8 solutions
    │   └── recipe-*.json   # 10 recipes
    ├── styles/
    │   └── globals.css     # Design tokens & Tailwind
    └── types/              # TypeScript types
```

---

## 🎨 Tech Stack

- **React 18.3.1** - UI library
- **TypeScript 5.6.2** - Type safety
- **Vite 6.3.5** - Build tool & dev server
- **Tailwind CSS v4** - Styling
- **Radix UI** - Accessible UI primitives
- **React Router DOM** - Routing
- **Lucide React** - Icons

---

## 🔧 Troubleshooting

### Port Already in Use
Vite will auto-detect and use the next available port (3001, 3002, etc.)

### Installation Errors
```bash
# Clear cache and reinstall
rm -rf node_modules package-lock.json
npm cache clean --force
npm install
```

### TypeScript Errors
```bash
# Check for type errors
npx tsc --noEmit
```

### Build Errors
```bash
# Clear Vite cache
rm -rf node_modules/.vite
npm run dev
```

---

## 📊 Package Size

- **Before npm install**: ~1.1 MB
- **After npm install**: ~251 MB (includes node_modules)
- **Production build**: ~500 KB (gzipped)

---

## 🌍 Browser Support

- Chrome/Edge (latest 2 versions)
- Firefox (latest 2 versions)
- Safari (latest 2 versions)

---

## 🚢 Production Build

To create a production build:

```bash
# Build for production
npm run build

# Output will be in: build/
```

To preview the production build locally:

```bash
npm run preview
```

---

## 📝 Environment

- No environment variables required
- No database needed
- No backend required
- Pure frontend application

---

## 💡 Features

✅ **7 Pages** - Complete developer portal
✅ **Responsive Design** - Mobile, tablet, desktop
✅ **Dark Mode** - Toggle between light/dark themes
✅ **Search** - Global search (Cmd/Ctrl + K)
✅ **API Explorer** - Interactive API testing sidebar
✅ **Code Samples** - Copy-to-clipboard functionality
✅ **Filtering** - Industry-based filtering for Solutions/Recipes
✅ **Routing** - Client-side routing with React Router

---

## 🎯 Next Steps

After installation, you can:
1. Customize the design system in `src/styles/globals.css`
2. Add more pages in `src/components/pages/`
3. Modify data files in `src/data/`
4. Update routes in `src/main.tsx`
5. Add new components in `src/components/`

---

## 📞 Support

For issues or questions:
- Check the browser console for errors
- Verify Node.js version (v18+)
- Check `npm install` completed successfully
- Make sure you're in the `dev-portal-standalone` directory

---

## 🎉 You're Ready!

The Developer Portal is now set up and ready to use. Happy coding! 🚀
