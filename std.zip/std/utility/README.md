# Developer Portal - Feature Evaluator

A clean, intuitive web application for evaluating 37 developer portal features across 5 journey phases with real-world reference examples.

## Quick Start

1. **Open the application**
   - Simply open `index.html` in any modern web browser
   - No server or installation required
   - Works completely offline

2. **Evaluation Flow**
   ```
   Journey Map → Features Reference → Site IA
   ```

## Features

### Three Main Views

#### 1. 📍 Journey Map
- Visualize the 5-phase developer journey
- Click **"🎨 View Journey Map in Figma"** to see the visual design
- Discuss each phase and its proposed items
- **Phases:**
  - Phase 1: DISCOVER (Orange)
  - Phase 2: EVALUATE (Purple)
  - Phase 3: ONBOARD & INTEGRATION PLANNING (Blue)
  - Phase 4: INTEGRATE (Indigo)
  - Phase 5: OPERATE & SCALE (Brown)

#### 2. 📋 Features Reference
- Quick reference of all 37 features
- Navigate through 5 categories using tabs
- Feature count displayed in brackets on each tab
- Shows phase mappings for each feature with clear labels
- **Phase tags** display phase names (Discover, Evaluate, Onboard, Integrate, Operate)
- **Use this for:** Quick lookups during discussion
- **Categories:**
  - Navigation, Discovery & IA (7)
  - API Docs & Evaluation Experience (8)
  - Onboarding Workflow (4)
  - Developer Tools / Integration Experience (8)
  - Operate & Scale (10)

#### 3. ⚡ Site IA
- Detailed feature-by-feature evaluation workspace
- Features organized by Information Architecture
- **Click any feature card** to expand and evaluate
- Two main sections:
  - **Public Portal** (7 sections)
  - **Developer Console/Workspace** (4 sections)

### Evaluation Framework

For each feature, evaluate:

| Criterion | Options |
|-----------|---------|
| ✅ **Implement** | Yes / No / Partial |
| ⭐ **UX Recommended** | High / Medium / Low |
| 🔧 **Tech Feasibility** | Easy / Medium / Complex |
| 💰 **Cost** | Low / Medium / High |
| 📈 **Business Value** | Low / Medium / High |
| 🎯 **Priority** | P0 / P1 / P2 / P3 |
| 📝 **Next Steps** | Free text |
| 🚧 **Blockers** | Free text |
| 💬 **Notes** | Free text |

### Reference Examples

25 real-world examples from leading developer portals:
- Mastercard, Shopify, Stripe, Square
- FactSet, Wells Fargo, VTEX, Plaid
- Miro, Slack, Adyen, and more

**Images Available:** Square API Explorer, Miro App Settings, Adyen Cancel Payment API

## Usage Tips

### Recommended Flow

1. **Start with Journey Map** (15 min)
   - Review all 5 phases
   - Discuss the developer journey
   - Get alignment on the overall vision

2. **Quick Features Review** (10 min)
   - Browse the 37 features
   - Note any questions or concerns
   - Reference only - don't evaluate yet

3. **Deep Dive: Site IA** (Main Session)
   - Go section by section
   - Click cards to expand and evaluate each feature
   - Evaluate as a group
   - Check reference examples for inspiration
   - Capture decisions, next steps, and blockers

### Using Filters

Speed up your evaluation with filters:
- **Phase Filter:** Focus on specific journey phases
- **Category Filter:** Review by feature category
- **Status Filter:** See evaluated vs. pending features
- **Search:** Find specific features quickly

### Making Decisions

**Click Cards to Evaluate**
- Click anywhere on a feature card to expand it
- Evaluation form appears inside the card
- Click again to collapse
- Look for "▼ Click to evaluate" indicator

**Green cards = Evaluated**
- Cards turn green when you've made evaluation inputs
- Use this visual feedback to track progress

**Decision Matrix**
- All evaluation criteria in one place
- Quick dropdowns for fast decision-making
- Text fields for capturing context

**Reference Links**
- Click to open examples in new tabs
- 🖼️ icon = screenshot available
- Use these to inform your decisions

## Data Management

### Auto-Save
- **Every change is automatically saved** to browser localStorage
- Close and reopen anytime - your work is preserved
- No manual save needed

### Export
- Click **💾 Export JSON** to download all evaluations
- File name includes date: `portal-evaluations-2024-01-15.json`
- Share with team or keep as backup

### Import
- Click **📂 Import JSON** to load previous session
- Upload exported JSON file
- Useful for:
  - Continuing work from another browser
  - Merging team inputs
  - Restoring backups

### Reset
- Click **⚙️ Advanced** to reveal danger zone
- Follow 3-layer protection to reset all evaluations
- Confirmation required (irreversible)
- Use at start of new evaluation session

## Progress Tracking

### Progress Bar (Top of Page)
- Shows how many features are evaluated
- Updates in real-time as you work
- Visual motivation to complete all 37

### Summary Dashboard (Bottom Right)
- Live statistics:
  - Total features evaluated
  - Implementation decisions breakdown
  - UX recommendations
  - Priority distribution
- Updates automatically with each change

## Keyboard Shortcuts

- **Tab** - Navigate between form fields
- **Enter** (in dropdowns) - Select option
- **Ctrl/Cmd + F** - Focus search box (in most browsers)

## Browser Compatibility

Tested and works in:
- ✅ Chrome/Edge (recommended)
- ✅ Safari
- ✅ Firefox
- ✅ Any modern browser

## Print Support

Need a printout?
- Use browser's print function (Ctrl/Cmd + P)
- Evaluation forms automatically expand
- Clean, print-friendly formatting

## Troubleshooting

**Data not saving?**
- Check browser allows localStorage
- Try a different browser
- Export JSON as backup

**Feature cards not showing?**
- Check active filters (reset to "All")
- Clear search box
- Refresh page

**Can't see reference links?**
- Some features don't have references yet
- Only relevant examples are shown

**Lost your data?**
- Check if you exported a JSON backup
- Data only persists in same browser

## File Structure

```
workshop-utility/
├── index.html      # Main application
├── styles.css      # All styling
├── app.js          # Application logic
├── data.js         # All 37 features + references
└── README.md       # This file
```

## Customization

### Update Figma Link

To update the Figma journey map link:

1. Open `index.html` in a text editor
2. Find line with `id="figmaLink"`
3. Replace `https://figma.com/PLACEHOLDER_URL` with your actual Figma URL
4. Save the file

Example:
```html
<a href="https://figma.com/file/YOUR_FILE_ID/Journey-Map" target="_blank" class="figma-link" id="figmaLink">
    🎨 View Journey Map in Figma
</a>
```

## Support

Questions during evaluation?
- Check the reference examples for guidance
- Use the search to find specific features
- Export your work frequently as backup

---

**Ready to start? Just open `index.html` and go! 🚀**
