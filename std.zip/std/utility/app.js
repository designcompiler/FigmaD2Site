// Application State
let evaluations = {};
let activeFilters = {
    phase: '',
    category: '',
    status: '',
    search: ''
};
let cardListenersAttached = false;

// Initialize application
document.addEventListener('DOMContentLoaded', () => {
    loadEvaluations();
    setupEventListeners();
    renderAllViews();
    updateProgress();
    updateSummary();
});

// Load evaluations from localStorage
function loadEvaluations() {
    const stored = localStorage.getItem('portalEvaluations');
    if (stored) {
        evaluations = JSON.parse(stored);
        console.log('Loaded evaluations from localStorage:', evaluations);
    } else {
        evaluations = initializeEvaluations();
        console.log('Initialized new evaluations');
    }
}

// Save evaluations to localStorage
function saveEvaluations() {
    localStorage.setItem('portalEvaluations', JSON.stringify(evaluations));
    updateProgress();
    updateSummary();
}

// Setup event listeners
function setupEventListeners() {
    // Tab navigation
    document.querySelectorAll('.tab-button').forEach(button => {
        button.addEventListener('click', () => {
            const view = button.dataset.view;
            switchView(view);
        });
    });

    // Filters
    document.getElementById('phaseFilter').addEventListener('change', (e) => {
        activeFilters.phase = e.target.value;
        renderEvaluationView();
    });

    document.getElementById('categoryFilter').addEventListener('change', (e) => {
        activeFilters.category = e.target.value;
        renderEvaluationView();
    });

    document.getElementById('statusFilter').addEventListener('change', (e) => {
        activeFilters.status = e.target.value;
        renderEvaluationView();
    });

    document.getElementById('searchInput').addEventListener('input', (e) => {
        activeFilters.search = e.target.value.toLowerCase();
        renderEvaluationView();
    });

    // Action buttons
    document.getElementById('exportBtn').addEventListener('click', exportData);
    document.getElementById('importBtn').addEventListener('click', () => {
        document.getElementById('fileInput').click();
    });
    document.getElementById('fileInput').addEventListener('change', importData);

    // 3-layer reset protection
    document.getElementById('showDangerZoneBtn').addEventListener('click', showDangerZone);
    document.getElementById('unlockResetBtn').addEventListener('click', unlockReset);
    document.getElementById('cancelResetBtn').addEventListener('click', hideDangerZone);
    document.getElementById('resetConfirmInput').addEventListener('input', checkResetInput);
    document.getElementById('finalResetBtn').addEventListener('click', resetAll);
}

// Switch between views
function switchView(viewName) {
    // Update tabs
    document.querySelectorAll('.tab-button').forEach(btn => {
        btn.classList.remove('active');
        if (btn.dataset.view === viewName) {
            btn.classList.add('active');
        }
    });

    // Update views
    document.querySelectorAll('.view').forEach(view => {
        view.classList.remove('active');
    });
    document.getElementById(`${viewName}View`).classList.add('active');
}

// Render all views
function renderAllViews() {
    renderJourneyView();
    renderFeaturesView();
    renderEvaluationView();
}

// Render Journey Map View
function renderJourneyView() {
    const container = document.getElementById('journeyContent');
    container.innerHTML = '';

    // Create phase tabs
    const tabsContainer = document.createElement('div');
    tabsContainer.className = 'phase-tabs';

    PHASES.forEach((phase, index) => {
        const tab = document.createElement('button');
        tab.className = `phase-tab phase-${phase.id}`;
        if (index === 0) tab.classList.add('active');
        tab.innerHTML = `
            <div style="font-size: 0.75rem; opacity: 0.8;">Phase ${phase.id}</div>
            <div>${phase.name}</div>
        `;
        tab.addEventListener('click', () => switchPhase(phase.id));
        tabsContainer.appendChild(tab);
    });

    container.appendChild(tabsContainer);

    // Create phase content sections
    PHASES.forEach((phase, index) => {
        const phaseSection = document.createElement('div');
        phaseSection.className = 'journey-phase';
        phaseSection.id = `phase-${phase.id}`;
        if (index === 0) phaseSection.classList.add('active');

        const phaseCard = document.createElement('div');
        phaseCard.className = 'phase-card';
        phaseCard.style.borderLeftColor = phase.color;

        phaseCard.innerHTML = `
            <div class="phase-header">
                <div>
                    <div class="phase-number">Phase ${phase.id}</div>
                    <h3 class="phase-name" style="color: ${phase.color};">${phase.name}</h3>
                </div>
            </div>
            <p class="phase-description">${phase.description}</p>
            <ul class="phase-items">
                ${phase.items.map(item => `<li>${item}</li>`).join('')}
            </ul>
        `;

        phaseSection.appendChild(phaseCard);
        container.appendChild(phaseSection);
    });
}

// Switch between journey phases
function switchPhase(phaseId) {
    // Update tabs
    document.querySelectorAll('.phase-tab').forEach(tab => {
        tab.classList.remove('active');
        if (tab.classList.contains(`phase-${phaseId}`)) {
            tab.classList.add('active');
        }
    });

    // Update content
    document.querySelectorAll('.journey-phase').forEach(section => {
        section.classList.remove('active');
    });
    document.getElementById(`phase-${phaseId}`).classList.add('active');
}

// Render Features Reference View
function renderFeaturesView() {
    const container = document.getElementById('featuresContent');
    container.innerHTML = '';

    // Create category tabs
    const tabsContainer = document.createElement('div');
    tabsContainer.className = 'category-tabs';

    Object.keys(CATEGORIES).forEach((catKey, index) => {
        const category = CATEGORIES[catKey];
        const categoryFeatures = FEATURES.filter(f => f.category === catKey);

        const tab = document.createElement('button');
        tab.className = `category-tab category-${catKey}`;
        if (index === 0) tab.classList.add('active');
        tab.textContent = `${category.name} (${categoryFeatures.length})`;
        tab.addEventListener('click', () => switchCategory(catKey));
        tabsContainer.appendChild(tab);
    });

    container.appendChild(tabsContainer);

    // Create category content sections
    Object.keys(CATEGORIES).forEach((catKey, index) => {
        const category = CATEGORIES[catKey];
        const categoryFeatures = FEATURES.filter(f => f.category === catKey);

        const categorySection = document.createElement('div');
        categorySection.className = 'features-category';
        categorySection.id = `category-${catKey}`;
        if (index === 0) categorySection.classList.add('active');

        const section = document.createElement('div');
        section.className = 'category-section';

        section.innerHTML = `
            <div class="category-header">
                <div class="category-badge" style="background-color: ${category.color};">
                    ${catKey}
                </div>
                <h3 class="category-name">${category.name}</h3>
            </div>
            <ul class="feature-list">
                ${categoryFeatures.map(feature => `
                    <li class="feature-item">
                        <div class="feature-item-id">#${feature.id}</div>
                        <div class="feature-item-name">${feature.name}</div>
                        <div class="feature-item-phases">
                            ${feature.phases.map(phaseId => {
                                return `<span class="phase-tag phase-${phaseId}">${getPhaseNameShort(phaseId)}</span>`;
                            }).join('')}
                        </div>
                    </li>
                `).join('')}
            </ul>
        `;

        categorySection.appendChild(section);
        container.appendChild(categorySection);
    });
}

// Switch between feature categories
function switchCategory(catKey) {
    // Update tabs
    document.querySelectorAll('.category-tab').forEach(tab => {
        tab.classList.remove('active');
        if (tab.classList.contains(`category-${catKey}`)) {
            tab.classList.add('active');
        }
    });

    // Update content
    document.querySelectorAll('.features-category').forEach(section => {
        section.classList.remove('active');
    });
    document.getElementById(`category-${catKey}`).classList.add('active');
}

// Render Evaluation View
function renderEvaluationView() {
    renderPublicPortal();
    renderDeveloperConsole();
    attachCardEventListeners();
}

function renderPublicPortal() {
    const container = document.getElementById('publicPortalContent');
    container.innerHTML = '';

    SITE_IA.publicPortal.sections.forEach(section => {
        const sectionDiv = document.createElement('div');
        sectionDiv.className = 'ia-subsection';

        const featureCards = section.features
            .map(fid => FEATURES.find(f => f.id === fid))
            .filter(feature => feature && matchesFilters(feature))
            .map(feature => createFeatureCard(feature))
            .join('');

        if (section.features.length === 0 || featureCards) {
            sectionDiv.innerHTML = `
                <h4 class="ia-subsection-name">${section.name}</h4>
                <p class="ia-subsection-description">${section.description}</p>
                <div class="feature-cards-grid">
                    ${featureCards || '<p style="color: var(--color-gray-500); font-size: 0.875rem;">No features match current filters</p>'}
                </div>
            `;
            container.appendChild(sectionDiv);
        }
    });
}

function renderDeveloperConsole() {
    const container = document.getElementById('developerConsoleContent');
    container.innerHTML = '';

    SITE_IA.developerConsole.sections.forEach(section => {
        const sectionDiv = document.createElement('div');
        sectionDiv.className = 'ia-subsection';

        const featureCards = section.features
            .map(fid => FEATURES.find(f => f.id === fid))
            .filter(feature => feature && matchesFilters(feature))
            .map(feature => createFeatureCard(feature))
            .join('');

        if (section.features.length === 0 || featureCards) {
            sectionDiv.innerHTML = `
                <h4 class="ia-subsection-name">${section.name}</h4>
                <p class="ia-subsection-description">${section.description}</p>
                <div class="feature-cards-grid">
                    ${featureCards || '<p style="color: var(--color-gray-500); font-size: 0.875rem;">No features match current filters</p>'}
                </div>
            `;
            container.appendChild(sectionDiv);
        }
    });
}

// Check if feature matches active filters
function matchesFilters(feature) {
    // Phase filter
    if (activeFilters.phase && !feature.phases.includes(parseInt(activeFilters.phase))) {
        return false;
    }

    // Category filter
    if (activeFilters.category && feature.category !== activeFilters.category) {
        return false;
    }

    // Status filter
    if (activeFilters.status) {
        const isEvaluated = isFeatureEvaluated(feature.id);
        if (activeFilters.status === 'evaluated' && !isEvaluated) return false;
        if (activeFilters.status === 'pending' && isEvaluated) return false;
    }

    // Search filter
    if (activeFilters.search && !feature.name.toLowerCase().includes(activeFilters.search)) {
        return false;
    }

    return true;
}

// Helper function to set select value and mark option as selected
function setSelectValue(selectElement, value) {
    if (!selectElement || !value) return;

    selectElement.value = value;
    const options = selectElement.querySelectorAll('option');
    options.forEach(option => {
        if (option.value === value) {
            option.setAttribute('selected', 'selected');
        } else {
            option.removeAttribute('selected');
        }
    });
}

// Create feature card HTML
function createFeatureCard(feature) {
    const category = CATEGORIES[feature.category];
    const eval_data = evaluations[feature.id] || {};
    const isEvaluated = isFeatureEvaluated(feature.id);

    const references = REFERENCES.filter(ref => ref.relevantTo.includes(feature.id));

    const template = document.getElementById('featureCardTemplate');
    const clone = template.content.cloneNode(true);

    const card = clone.querySelector('.feature-card');
    card.dataset.featureId = feature.id;
    if (isEvaluated) {
        card.classList.add('evaluated');
    }

    // Feature ID
    const featureId = clone.querySelector('.feature-id');
    featureId.textContent = `#${feature.id}`;
    featureId.style.backgroundColor = category.color;

    // Feature name
    clone.querySelector('.feature-name').textContent = feature.name;

    // Category badge
    const categoryBadge = clone.querySelector('.category-badge');
    categoryBadge.textContent = feature.category;
    categoryBadge.style.backgroundColor = category.color;

    // Phase tags
    const phaseTags = clone.querySelector('.phase-tags');
    feature.phases.forEach(phaseId => {
        const tag = document.createElement('span');
        tag.className = `phase-tag phase-${phaseId}`;
        tag.textContent = getPhaseNameShort(phaseId);
        phaseTags.appendChild(tag);
    });

    // IA Locations
    const locationsDiv = clone.querySelector('.feature-locations');
    if (feature.iaLocations.length > 0) {
        locationsDiv.innerHTML = `
            ${feature.iaLocations.map(loc =>
                `<span class="location-tag">📍 ${loc}</span>`
            ).join('')}
        `;
    }

    // References
    const referencesDiv = clone.querySelector('.feature-references');
    if (references.length > 0) {
        referencesDiv.innerHTML = `
            <div style="font-size: 0.75rem; font-weight: 600; color: var(--color-gray-600); margin-bottom: 6px;">
                🔗 Reference Examples
            </div>
            <div class="reference-links">
                ${references.map(ref => `
                    <a href="${ref.url}" target="_blank" class="reference-link ${ref.hasImage ? 'has-image' : ''}">
                        ${ref.name}
                    </a>
                `).join('')}
            </div>
        `;
    } else {
        referencesDiv.style.display = 'none';
    }

    // Populate form with saved values
    if (Object.keys(eval_data).length > 0) {
        console.log(`Populating feature ${feature.id} with data:`, eval_data);
    }

    // For select elements, we need to set the selected attribute on options
    setSelectValue(clone.querySelector('.eval-implement'), eval_data.implement || '');
    setSelectValue(clone.querySelector('.eval-ux'), eval_data.uxRecommended || '');
    setSelectValue(clone.querySelector('.eval-tech'), eval_data.techFeasibility || '');
    setSelectValue(clone.querySelector('.eval-cost'), eval_data.cost || '');
    setSelectValue(clone.querySelector('.eval-value'), eval_data.businessValue || '');
    setSelectValue(clone.querySelector('.eval-priority'), eval_data.priority || '');

    // For textareas, we can set textContent
    clone.querySelector('.eval-nextsteps').textContent = eval_data.nextSteps || '';
    clone.querySelector('.eval-blockers').textContent = eval_data.blockers || '';
    clone.querySelector('.eval-notes').textContent = eval_data.notes || '';

    const container = document.createElement('div');
    container.appendChild(clone);
    return container.innerHTML;
}

// Attach event listeners to feature cards using event delegation
function attachCardEventListeners() {
    // Only attach listeners once
    if (cardListenersAttached) return;

    // Handle toggle button clicks
    document.getElementById('publicPortalContent').addEventListener('click', handleToggleClick);
    document.getElementById('developerConsoleContent').addEventListener('click', handleToggleClick);

    // Handle form input changes
    document.getElementById('publicPortalContent').addEventListener('change', handleFormChange);
    document.getElementById('developerConsoleContent').addEventListener('change', handleFormChange);
    document.getElementById('publicPortalContent').addEventListener('input', handleFormInput);
    document.getElementById('developerConsoleContent').addEventListener('input', handleFormInput);

    cardListenersAttached = true;
}

function handleToggleClick(e) {
    // Check if click is on the clickable header or the card itself
    const clickedHeader = e.target.closest('.feature-card-header-clickable');
    const clickedCard = e.target.closest('.feature-card.clickable');

    // Don't toggle if clicking inside the form, on links, or form elements
    if (e.target.closest('.evaluation-form') ||
        e.target.tagName === 'A' ||
        e.target.tagName === 'SELECT' ||
        e.target.tagName === 'TEXTAREA' ||
        e.target.tagName === 'INPUT') {
        return;
    }

    if (clickedHeader || clickedCard) {
        const card = clickedCard || clickedHeader.closest('.feature-card');
        const form = card.querySelector('.evaluation-form');
        const indicator = card.querySelector('.expand-indicator');
        const isVisible = form.style.display !== 'none';

        form.style.display = isVisible ? 'none' : 'block';
        card.classList.toggle('expanded', !isVisible);

        if (indicator) {
            indicator.textContent = isVisible ? '▼ Click to evaluate' : '▲ Click to collapse';
        }
    }
}

function handleFormChange(e) {
    if (e.target.matches('.evaluation-form select')) {
        const card = e.target.closest('.feature-card');
        const featureId = parseInt(card.dataset.featureId);
        const form = card.querySelector('.evaluation-form');
        saveFormData(featureId, form);
    }
}

function handleFormInput(e) {
    if (e.target.matches('.evaluation-form textarea')) {
        const card = e.target.closest('.feature-card');
        const featureId = parseInt(card.dataset.featureId);
        const form = card.querySelector('.evaluation-form');
        saveFormData(featureId, form);
    }
}

// Save form data
function saveFormData(featureId, form) {
    evaluations[featureId] = {
        implement: form.querySelector('.eval-implement').value,
        uxRecommended: form.querySelector('.eval-ux').value,
        techFeasibility: form.querySelector('.eval-tech').value,
        cost: form.querySelector('.eval-cost').value,
        businessValue: form.querySelector('.eval-value').value,
        priority: form.querySelector('.eval-priority').value,
        nextSteps: form.querySelector('.eval-nextsteps').value,
        blockers: form.querySelector('.eval-blockers').value,
        notes: form.querySelector('.eval-notes').value
    };
    console.log(`Saved evaluation for feature ${featureId}:`, evaluations[featureId]);
    saveEvaluations();

    // Update card appearance
    const card = form.closest('.feature-card');
    if (isFeatureEvaluated(featureId)) {
        card.classList.add('evaluated');
    } else {
        card.classList.remove('evaluated');
    }
}

// Check if feature is evaluated
function isFeatureEvaluated(featureId) {
    const eval_data = evaluations[featureId];
    if (!eval_data) return false;

    return (
        (eval_data.implement && eval_data.implement !== '') ||
        (eval_data.uxRecommended && eval_data.uxRecommended !== '') ||
        (eval_data.techFeasibility && eval_data.techFeasibility !== '') ||
        (eval_data.cost && eval_data.cost !== '') ||
        (eval_data.businessValue && eval_data.businessValue !== '') ||
        (eval_data.priority && eval_data.priority !== '')
    );
}

// Update progress bar
function updateProgress() {
    const total = FEATURES.length;
    const evaluated = FEATURES.filter(f => isFeatureEvaluated(f.id)).length;
    const percentage = (evaluated / total) * 100;

    document.getElementById('progressFill').style.width = `${percentage}%`;
    document.getElementById('progressText').textContent = `${evaluated} of ${total} features evaluated`;
}

// Update summary dashboard
function updateSummary() {
    const stats = calculateStats();
    const container = document.getElementById('summaryStats');

    container.innerHTML = `
        <div class="stat-row">
            <span class="stat-label">Total Features</span>
            <span class="stat-value">${stats.total}</span>
        </div>
        <div class="stat-row">
            <span class="stat-label">Evaluated</span>
            <span class="stat-value">${stats.evaluated}</span>
        </div>
        <div class="stat-row">
            <span class="stat-label">Implement: Yes</span>
            <span class="stat-value">${stats.implementYes}</span>
        </div>
        <div class="stat-row">
            <span class="stat-label">Implement: Partial</span>
            <span class="stat-value">${stats.implementPartial}</span>
        </div>
        <div class="stat-row">
            <span class="stat-label">Implement: No</span>
            <span class="stat-value">${stats.implementNo}</span>
        </div>
        <div class="stat-row">
            <span class="stat-label">UX High Priority</span>
            <span class="stat-value">${stats.uxHigh}</span>
        </div>
        <div class="stat-row">
            <span class="stat-label">P0 Priority</span>
            <span class="stat-value">${stats.p0}</span>
        </div>
        <div class="stat-row">
            <span class="stat-label">P1 Priority</span>
            <span class="stat-value">${stats.p1}</span>
        </div>
    `;
}

// Calculate statistics
function calculateStats() {
    const stats = {
        total: FEATURES.length,
        evaluated: 0,
        implementYes: 0,
        implementPartial: 0,
        implementNo: 0,
        uxHigh: 0,
        p0: 0,
        p1: 0
    };

    FEATURES.forEach(feature => {
        const eval_data = evaluations[feature.id];
        if (isFeatureEvaluated(feature.id)) {
            stats.evaluated++;
        }
        if (eval_data.implement === 'yes') stats.implementYes++;
        if (eval_data.implement === 'partial') stats.implementPartial++;
        if (eval_data.implement === 'no') stats.implementNo++;
        if (eval_data.uxRecommended === 'high') stats.uxHigh++;
        if (eval_data.priority === 'p0') stats.p0++;
        if (eval_data.priority === 'p1') stats.p1++;
    });

    return stats;
}

// Export data
function exportData() {
    const exportObj = {
        exportDate: new Date().toISOString(),
        evaluations: evaluations,
        summary: calculateStats()
    };

    const dataStr = JSON.stringify(exportObj, null, 2);
    const blob = new Blob([dataStr], { type: 'application/json' });
    const url = URL.createObjectURL(blob);

    const a = document.createElement('a');
    a.href = url;
    a.download = `portal-evaluations-${new Date().toISOString().split('T')[0]}.json`;
    a.click();

    URL.revokeObjectURL(url);
}

// Import data
function importData(event) {
    const file = event.target.files[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (e) => {
        try {
            const imported = JSON.parse(e.target.result);
            if (imported.evaluations) {
                evaluations = imported.evaluations;
                saveEvaluations();
                renderAllViews();
                alert('✅ Data imported successfully!');
            } else {
                alert('❌ Invalid file format');
            }
        } catch (error) {
            alert('❌ Error importing file: ' + error.message);
        }
    };
    reader.readAsText(file);

    // Reset file input
    event.target.value = '';
}

// Layer 1: Show danger zone
function showDangerZone() {
    document.getElementById('dangerZone').style.display = 'block';
    document.getElementById('showDangerZoneBtn').textContent = '⚙️ Hide Advanced';
    document.getElementById('showDangerZoneBtn').onclick = hideDangerZone;
}

// Hide danger zone
function hideDangerZone() {
    document.getElementById('dangerZone').style.display = 'none';
    document.getElementById('resetConfirmation').style.display = 'none';
    document.getElementById('resetConfirmInput').value = '';
    document.getElementById('finalResetBtn').disabled = true;
    document.getElementById('showDangerZoneBtn').textContent = '⚙️ Advanced';
    document.getElementById('showDangerZoneBtn').onclick = showDangerZone;
}

// Layer 2: Unlock reset confirmation
function unlockReset() {
    document.getElementById('resetConfirmation').style.display = 'block';
}

// Layer 3: Check if user typed "RESET"
function checkResetInput(e) {
    const input = e.target.value;
    const button = document.getElementById('finalResetBtn');
    if (input === 'RESET') {
        button.disabled = false;
    } else {
        button.disabled = true;
    }
}

// Final: Reset all evaluations
function resetAll() {
    evaluations = initializeEvaluations();
    localStorage.removeItem('portalEvaluations');
    renderAllViews();
    updateProgress();
    updateSummary();
    hideDangerZone();
    alert('✅ All evaluations have been reset');
}
