// Developer Portal Workshop Data
// All features, phases, and reference examples

const PHASES = [
  {
    id: 1,
    name: 'DISCOVER',
    description: 'Help developers find the right APIs and solutions',
    color: '#E08327',
    items: [
      'Outcome-led landing page',
      'Solutions Catalog (use-case driven)',
      'Unified API Catalog (filters, tags, statuses)',
      'Global semantic search',
      'Marketplace ↔ Developer Portal integration',
      'EN/FR localization'
    ]
  },
  {
    id: 2,
    name: 'EVALUATE',
    description: 'Enable hands-on testing and exploration',
    color: '#A853C0',
    items: [
      'Standardized API product pages',
      'Solutions pages + Recipes (fully linked)',
      'Improved sandbox onboarding',
      'Download Center (sample apps, specs, Postman)',
      'Self-serve support center',
      'Evaluation analytics (TTFC, activation, engagement)'
    ]
  },
  {
    id: 3,
    name: 'ONBOARD & INTEGRATION PLANNING',
    description: 'Guide developers through setup and planning',
    color: '#3275C8',
    items: [
      'Guided onboarding wizard',
      'Interactive API Explorer (scenario data)',
      'Enrollment & IR visibility',
      'Integration templates (test plan, go-live, compliance)',
      'Onboarding status tracker'
    ]
  },
  {
    id: 4,
    name: 'INTEGRATE',
    description: 'Provide tools and support for implementation',
    color: '#4442DA',
    items: [
      'Multi-language Quickstarts',
      'End-to-end integration recipes',
      'Environment management (apps, keys, secrets, redirects, webhooks)',
      'Testing tools (mock data, replay, inspector)',
      'Developer support (tickets, chat, office hours)',
      'AI documentation helpers (embedded into docs)'
    ]
  },
  {
    id: 5,
    name: 'OPERATE & SCALE',
    description: 'Support production operations and growth',
    color: '#8B4513',
    items: [
      'Organization Workspace Dashboard',
      'Usage dashboards & error dashboards',
      'Webhook health & limit usage',
      'Partner / ERP Connector Hub',
      'Proactive updates (changelog, release notes, deprecations, what\'s new)'
    ]
  }
];

const CATEGORIES = {
  A: { name: 'Navigation, Discovery & IA', color: '#E08327' },
  B: { name: 'API Docs & Evaluation Experience', color: '#A853C0' },
  C: { name: 'Onboarding Workflow', color: '#3275C8' },
  D: { name: 'Developer Tools / Integration Experience', color: '#4442DA' },
  E: { name: 'Operate & Scale', color: '#8B4513' }
};

const FEATURES = [
  // Category A: Navigation, Discovery & IA
  { id: 1, name: 'Outcome-led landing experience', category: 'A', phases: [1], iaLocations: ['Public Portal > Home'], references: ['bni-homepage'] },
  { id: 2, name: 'Solutions Catalog', category: 'A', phases: [1, 2], iaLocations: ['Public Portal > Home', 'Public Portal > Solutions'], references: ['factset-solutions'] },
  { id: 3, name: 'Recipes Library', category: 'A', phases: [2, 4], iaLocations: ['Public Portal > Home', 'Public Portal > Recipes'], references: ['factset-recipes-catalog', 'factset-recipe-example'] },
  { id: 4, name: 'Unified API Catalog', category: 'A', phases: [1], iaLocations: ['Public Portal > Home', 'Public Portal > API Catalog'], references: ['bni-api-products', 'factset-api-catalog'] },
  { id: 5, name: 'Global semantic search', category: 'A', phases: [1], iaLocations: ['Public Portal > Home'], references: [] },
  { id: 6, name: 'Marketplace ↔ Portal integration', category: 'A', phases: [1], iaLocations: ['Public Portal > Home'], references: [] },
  { id: 7, name: 'Localization', category: 'A', phases: [1], iaLocations: ['Public Portal > All Pages'], references: [] },

  // Category B: API Docs & Evaluation Experience
  { id: 8, name: 'Standardized API Product Page template', category: 'B', phases: [2], iaLocations: ['Public Portal > API Catalog'], references: ['mastercard-use-cases', 'stripe-api', 'vtex-guides'] },
  { id: 9, name: 'Quickstarts', category: 'B', phases: [2, 4], iaLocations: ['Public Portal > API Catalog', 'Public Portal > Get Started'], references: ['wellsfargo-getting-started'] },
  { id: 10, name: 'Authentication guide (OAuth, keys)', category: 'B', phases: [2], iaLocations: ['Public Portal > API Catalog'], references: ['shopify-customer-accounts'] },
  { id: 11, name: 'Sandbox onboarding', category: 'B', phases: [2], iaLocations: ['Public Portal > API Catalog'], references: [] },
  { id: 12, name: 'API Explorer with scenario data', category: 'B', phases: [3], iaLocations: ['Developer Console > Workspace'], references: ['square-api-explorer', 'wellsfargo-api-reference'] },
  { id: 13, name: 'Download Center', category: 'B', phases: [2], iaLocations: ['Developer Console > Workspace'], references: [] },
  { id: 14, name: 'Support center', category: 'B', phases: [2], iaLocations: ['Public Portal > Support'], references: [] },
  { id: 15, name: 'Evaluation analytics', category: 'B', phases: [2], iaLocations: ['Developer Console > Usage & Monitoring'], references: [] },

  // Category C: Onboarding Workflow
  { id: 16, name: 'Guided onboarding wizard', category: 'C', phases: [3], iaLocations: ['Public Portal > Get Started', 'Developer Console > Workspace'], references: ['wellsfargo-getting-started'] },
  { id: 17, name: 'Enrollment & IR visibility', category: 'C', phases: [3], iaLocations: ['Developer Console > Workspace'], references: [] },
  { id: 18, name: 'Integration templates', category: 'C', phases: [3], iaLocations: ['Developer Console > Workspace'], references: [] },
  { id: 19, name: 'Onboarding status tracker', category: 'C', phases: [3], iaLocations: ['Developer Console > Workspace'], references: [] },

  // Category D: Developer Tools / Integration Experience
  { id: 20, name: 'Environment management (keys, apps, secrets)', category: 'D', phases: [4], iaLocations: ['Developer Console > Workspace'], references: ['miro-app-settings'] },
  { id: 21, name: 'Testing utilities', category: 'D', phases: [4], iaLocations: ['Developer Console > Workspace'], references: [] },
  { id: 22, name: 'cURL/Postman auto-generation', category: 'D', phases: [4], iaLocations: ['Public Portal > API Catalog'], references: [] },
  { id: 23, name: 'Integration recipes', category: 'D', phases: [2, 4], iaLocations: ['Public Portal > Recipes'], references: ['factset-recipes-catalog', 'factset-recipe-example'] },
  { id: 24, name: 'Developer support', category: 'D', phases: [4], iaLocations: ['Public Portal > Support'], references: [] },
  { id: 25, name: 'Error-linked FAQs', category: 'D', phases: [4], iaLocations: ['Public Portal > Support'], references: [] },
  { id: 26, name: 'SDK/code helpers', category: 'D', phases: [4], iaLocations: ['Public Portal > API Catalog'], references: [] },
  { id: 27, name: 'AI documentation tools (embedded)', category: 'D', phases: [4], iaLocations: ['Public Portal > All Pages'], references: [] },

  // Category E: Operate & Scale
  { id: 28, name: 'Org Workspace Dashboard', category: 'E', phases: [5], iaLocations: ['Developer Console > Workspace'], references: ['miro-developer-hub'] },
  { id: 29, name: 'Usage analytics', category: 'E', phases: [5], iaLocations: ['Developer Console > Usage & Monitoring'], references: [] },
  { id: 30, name: 'Error dashboards', category: 'E', phases: [5], iaLocations: ['Developer Console > Usage & Monitoring'], references: [] },
  { id: 31, name: 'Webhook health', category: 'E', phases: [5], iaLocations: ['Developer Console > Usage & Monitoring'], references: ['square-webhooks', 'plaid-webhooks'] },
  { id: 32, name: 'Rate/limit consumption', category: 'E', phases: [5], iaLocations: ['Developer Console > Usage & Monitoring'], references: [] },
  { id: 33, name: 'Status page', category: 'E', phases: [5], iaLocations: ['Developer Console > Status & Updates'], references: [] },
  { id: 34, name: 'What\'s New feed', category: 'E', phases: [5], iaLocations: ['Developer Console > Status & Updates'], references: [] },
  { id: 35, name: 'Changelog', category: 'E', phases: [2, 5], iaLocations: ['Public Portal > API Catalog', 'Developer Console > Status & Updates'], references: [] },
  { id: 36, name: 'Deprecations', category: 'E', phases: [5], iaLocations: ['Developer Console > Status & Updates'], references: [] },
  { id: 37, name: 'Partner / ERP Connector Hub', category: 'E', phases: [5], iaLocations: ['Developer Console > Workspace'], references: [] }
];

const REFERENCES = [
  { id: 'mastercard-use-cases', name: 'Mastercard BIN Lookup', url: 'https://developer.mastercard.com/bin-lookup/documentation/use-cases/bin-lookup/', description: 'BIN lookup use cases', hasImage: false, relevantTo: [8] },
  { id: 'shopify-customer-accounts', name: 'Shopify Customer Accounts', url: 'https://shopify.dev/docs/apps/build/customer-accounts', description: 'Customer account apps', hasImage: false, relevantTo: [10] },
  { id: 'rootstock-rbtc', name: 'Rootstock RBTC Conversion', url: 'https://dev.rootstock.io/concepts/rbtc/conversion-with-trezor/', description: 'RBTC conversion guide', hasImage: false, relevantTo: [] },
  { id: 'bni-homepage', name: 'BNI Digital Services Homepage', url: 'https://digitalservices.bni.co.id/', description: 'Homepage reference', hasImage: false, relevantTo: [1] },
  { id: 'bni-api-products', name: 'BNI API Products', url: 'https://digitalservices.bni.co.id/api-products', description: 'API product listings', hasImage: false, relevantTo: [4] },
  { id: 'factset-recipe-example', name: 'FactSet Analytics Workstation Recipe', url: 'https://developer.factset.com/recipe-catalog/decouple-analytics-workstation', description: 'Recipe example', hasImage: false, relevantTo: [3, 23] },
  { id: 'factset-solutions', name: 'FactSet Portfolio Analytics', url: 'https://developer.factset.com/solutions/portfolio-analytics', description: 'Solution reference', hasImage: false, relevantTo: [2] },
  { id: 'factset-recipes-catalog', name: 'FactSet Recipe Catalog', url: 'https://developer.factset.com/recipe-catalog', description: 'Recipe catalog', hasImage: false, relevantTo: [3, 23] },
  { id: 'factset-api-catalog', name: 'FactSet API Catalog', url: 'https://developer.factset.com/api-catalog', description: 'API listings', hasImage: false, relevantTo: [4] },
  { id: 'stripe-api', name: 'Stripe API Docs', url: 'https://docs.stripe.com/api', description: 'Main API reference', hasImage: false, relevantTo: [8] },
  { id: 'slack-api', name: 'Slack API', url: 'https://api.slack.com', description: 'Main Slack API hub', hasImage: false, relevantTo: [] },
  { id: 'vtex-interest-rate', name: 'VTEX Interest Rate Guide', url: 'https://developers.vtex.com/docs/guides/setting-up-the-type-of-interest-rate', description: 'Guide page', hasImage: false, relevantTo: [] },
  { id: 'vtex-antifraud', name: 'VTEX Antifraud API', url: 'https://developers.vtex.com/docs/api-reference/antifraud-provider-protocol#post-/authorization/token?endpoint=post-/authorization/token', description: 'Token API', hasImage: false, relevantTo: [] },
  { id: 'vtex-audience', name: 'VTEX Audience API', url: 'https://developers.vtex.com/docs/api-reference/audience-api#post-/api/audience-manager/pvt/audience?endpoint=post-/api/audience-manager/pvt/audience', description: 'Audience creation API', hasImage: false, relevantTo: [] },
  { id: 'vtex-guides', name: 'VTEX Guides', url: 'https://developers.vtex.com/docs/guides', description: 'Development guides', hasImage: false, relevantTo: [8] },
  { id: 'wellsfargo-api-reference', name: 'Wells Fargo Hello API Reference', url: 'https://developer.wellsfargo.com/developertools/api-references/hello-wellsfargo/v1/hello-wellsfargo-api-ref-v1', description: 'API reference', hasImage: false, relevantTo: [12] },
  { id: 'wellsfargo-getting-started', name: 'Wells Fargo Getting Started', url: 'https://developer.wellsfargo.com/guides/user-guides/getting-started/getting-started', description: 'User onboarding guide', hasImage: false, relevantTo: [9, 16] },
  { id: 'miro-developer-hub', name: 'Miro Developer Hub', url: 'https://developers.miro.com/page/developer-hub?utm_source=your_apps', description: 'Developer documentation', hasImage: false, relevantTo: [28] },
  { id: 'square-api-explorer', name: 'Square API Explorer', url: 'https://developer.squareup.com/explorer/square', description: 'API Explorer UI', hasImage: true, relevantTo: [12] },
  { id: 'square-devices-list', name: 'Square Devices API - List Device Codes', url: 'https://developer.squareup.com/reference/square/devices-api/list-device-codes', description: 'Device listing endpoint', hasImage: false, relevantTo: [] },
  { id: 'square-webhooks', name: 'Square Devices API - Webhooks', url: 'https://developer.squareup.com/reference/square/devices-api/webhooks', description: 'Webhooks reference', hasImage: false, relevantTo: [31] },
  { id: 'plaid-webhooks', name: 'Plaid Transactions Removed', url: 'https://plaid.com/docs/api/products/transactions/#transactions_removed', description: 'Transactions removed event', hasImage: false, relevantTo: [31] },
  { id: 'miro-app-settings', name: 'Miro App Settings', url: 'https://miro.com/app/settings/company/3458764648747575407/user-profile/apps?devTeamDialog=1#3458764648750781022', description: 'App settings screen', hasImage: true, relevantTo: [20] },
  { id: 'shopify-mcp', name: 'Shopify MCP Docs', url: 'https://shopify.dev/docs/apps/build/devmcp', description: 'Developer MCP docs', hasImage: false, relevantTo: [] },
  { id: 'adyen-cancel', name: 'Adyen Cancel Payment API', url: 'https://docs.adyen.com/api-explorer/Checkout/71/post/cancels', description: 'Cancel authorised payment', hasImage: true, relevantTo: [] }
];

const SITE_IA = {
  publicPortal: {
    name: 'PUBLIC PORTAL',
    sections: [
      {
        name: 'Home',
        features: [1, 2, 3, 4, 5, 6, 7],
        description: 'Outcome narrative, search, solutions preview, API catalog preview, recipes preview, marketplace integration, EN/FR'
      },
      {
        name: 'Solutions',
        features: [2],
        description: 'Solutions Gallery, Solution Detail Page'
      },
      {
        name: 'API Catalog',
        features: [4, 8, 9, 11, 35],
        description: 'API List w/ filters, API Product Page (overview, use cases, quickstarts, sandbox, errors, changelog)'
      },
      {
        name: 'Recipes',
        features: [3, 23],
        description: 'Recipes Gallery, Recipe Detail Page'
      },
      {
        name: 'Get Started',
        features: [16, 9],
        description: 'Guided onboarding introduction, full end-to-end process explanation, first API call walkthrough'
      },
      {
        name: 'Support',
        features: [14, 25],
        description: 'FAQs, contact, demo request, troubleshooting'
      },
      {
        name: 'Login → Workspace',
        features: [],
        description: 'Authentication and transition to Developer Console'
      }
    ]
  },
  developerConsole: {
    name: 'DEVELOPER CONSOLE (WORKSPACE)',
    sections: [
      {
        name: 'Workspace / Dashboard',
        features: [28, 20, 13, 16],
        description: 'Org overview, apps/keys/secrets, environments & promotion, download center, guided onboarding flow'
      },
      {
        name: 'Usage & Monitoring',
        features: [29, 30, 32, 31],
        description: 'Usage, errors, rate limits, webhooks health'
      },
      {
        name: 'Status & Updates',
        features: [33, 34, 35, 36],
        description: 'Status page, incidents, changelog, deprecations, release notes'
      },
      {
        name: 'Settings',
        features: [],
        description: 'User and organization settings'
      }
    ]
  }
};

// Helper to get phase name
const getPhaseNameShort = (phaseId) => {
  const names = {
    1: 'Discover',
    2: 'Evaluate',
    3: 'Onboard',
    4: 'Integrate',
    5: 'Operate'
  };
  return names[phaseId] || `P${phaseId}`;
};

// Initialize empty evaluations for all features
const initializeEvaluations = () => {
  const evaluations = {};
  FEATURES.forEach(feature => {
    evaluations[feature.id] = {
      implement: '',
      uxRecommended: '',
      techFeasibility: '',
      cost: '',
      businessValue: '',
      priority: '',
      nextSteps: '',
      blockers: '',
      notes: ''
    };
  });
  return evaluations;
};
